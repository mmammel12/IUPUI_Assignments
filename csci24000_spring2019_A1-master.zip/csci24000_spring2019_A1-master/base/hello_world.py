# Hello world program
# Marty Mammel

print("Hello world!")
