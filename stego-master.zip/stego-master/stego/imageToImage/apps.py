from django.apps import AppConfig


class ImagetoimageConfig(AppConfig):
    name = "imageToImage"
