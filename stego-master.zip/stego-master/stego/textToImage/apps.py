from django.apps import AppConfig


class TextToImageConfig(AppConfig):
    name = "textToImage"
