#include <stdio.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>

#define MAX_LINE 80 /* The maximum length command */

int main(void)
{
	char *args[MAX_LINE / 2 + 1];	  /* command line arguments */
	char *pipe_args[MAX_LINE / 2 + 1]; /* command line arguments used with pipe operator */
	int should_run = 1;				   /* flag to determine when to exit program */
	char input[MAX_LINE];
	char prevInput[MAX_LINE];
	char temp[MAX_LINE];
	int i, j;

	while (should_run)
	{
		printf("osh>");
		fflush(stdout);

		fgets(input, MAX_LINE, stdin); // read in user input
		strncpy(temp, input, MAX_LINE);

		args[0] = strtok(input, " \n"); // place input before space into args

		// history feature
		if (strcmp(args[0], "!!") == 0)
		{
			if (!prevInput[0])
			{
				printf("No commands in history\n");
				fflush(stdout);
				continue;
			}

			printf("%s", prevInput);
			fflush(stdout);
			strncpy(input, prevInput, MAX_LINE);
			args[0] = strtok(input, " \n");
		}
		else
		{
			strncpy(prevInput, temp, MAX_LINE);
		}

		i = 0;
		bool ampersand_not_included = true;
		bool write_to_file = false;
		bool read_from_file = false;
		bool pipe_exists = false;
		int fd;
		int std_out = dup(STDOUT_FILENO);
		char file_input[MAX_LINE];
		while (args[i] != NULL)
		{
			i++;
			args[i] = strtok(NULL, " \n");

			if (args[i] != NULL)
			{
				if (*args[i] == '&')
				{
					ampersand_not_included = false;
					i--;
				}
				else if (*args[i] == '>')
				{
					// write output to file
					// get the file name
					write_to_file = true;
					i++;
					args[i] = strtok(NULL, " \n");
					fd = open(args[i], O_WRONLY | O_APPEND | O_CREAT, 0644);
					// duplicate stdout to fd
					dup2(fd, STDOUT_FILENO);
					close(fd);
					args[i] = NULL;
					i--;
					args[i] = NULL;
					continue;
				}
				else if (*args[i] == '<')
				{
					// pass test of file to command
					read_from_file = true;
					i++;
					args[i] = strtok(NULL, " \n");
					FILE *fd = fopen(args[i], "r");
					args[i] = NULL;
					i--;
					fgets(file_input, MAX_LINE, fd);
					fclose(fd);
					break;
				}
				else if (*args[i] == '|')
				{
					pipe_exists = true;
					args[i] = NULL;
					break;
				}
			}
		}

		if (read_from_file)
		{
			args[i] = strtok(file_input, " \n");
			while (args[i] != NULL)
			{
				i++;
				args[i] = strtok(NULL, " \n");

				if (args[i] != NULL && *args[i] == '&')
				{
					ampersand_not_included = false;
					i--;
				}
			}
		}

		if (pipe_exists)
		{
			j = 0;
			pipe_args[j] = strtok(NULL, " \n");

			while (pipe_args[j] != NULL)
			{
				j++;
				pipe_args[j] = strtok(NULL, " \n");

				if (pipe_args[j] != NULL && *pipe_args[j] == '&')
				{
					ampersand_not_included = false;
					i--;
				}
			}
		}

		/**
		 * After reading user input, the steps are:
		 * (1) fork a child process using fork()
		 * (2) the process will invoke execvp()
		 * (3) parent will invoke wait() unless command included &
		 */

		// (1) fork a child process using fork()
		pid_t pid = fork();

		if (pid < 0)
		{
			// fork failed
			printf("fork failed\n");
			fflush(stdout);
		}
		else if (pid == 0)
		{
			// child process
			// (2) the process will invoke execvp()
			if (!pipe_exists)
			{
				execvp(args[0], args);
				should_run = 0;
			}
			else
			{
				int p[2];

				if (pipe(p) < 0)
				{
					// pipe failed
					printf("pipe failed\n");
					fflush(stdout);
				}
				else
				{
					pid_t pipe_pid = fork();

					if (pipe_pid < 0)
					{
						// fork failed
						printf("fork failed\n");
						fflush(stdout);
					}
					else if (pipe_pid == 0)
					{
						// child process
						// close read end of pipe
						close(p[0]);
						// duplicate pipe to stdout
						dup2(p[1], STDOUT_FILENO);
						close(p[1]);
						// execute command before pipe
						execvp(args[0], args);
					}
					else
					{
						// parent process
						// close write end of pipe
						close(p[1]);
						// wait for child to send message through pipe
						wait(NULL);
						// duplicate stdout back to stdout
						dup2(std_out, STDOUT_FILENO);
						close(std_out);
						// read in message from pipe to file
						char file_name[] = "pipe.txt";
						FILE *pipe_fd = fopen(file_name, "w");
						char pipe_read[1000];
						read(p[0], pipe_read, 1000);
						fputs(pipe_read, pipe_fd);
						fclose(pipe_fd);
						// add file name to pipe_args
						pipe_args[j] = file_name;
						// execute command after pipe
						execvp(pipe_args[0], pipe_args);
					}
				}

				should_run = 0;
			}
		}
		else
		{
			// pid > 0 means parent process
			// (3) parent will invoke wait() unless command included &

			if (ampersand_not_included)
			{
				pid_t return_pid = wait(NULL);
			}
		}

		if (!ampersand_not_included)
		{
			should_run = 0;
		}

		if (write_to_file)
		{
			dup2(std_out, STDOUT_FILENO);
			close(std_out);
		}
	}

	return 0;
}
