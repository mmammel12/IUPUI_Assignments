// Selection Sort
// Author: Marty Mammel
// CSCI 362 Assignment 2

#include <iostream>
#include <fstream>

#define MAX_VALUE 1000

void swap(int *nums, int small, int large)
{
  int temp = nums[small];
  nums[small] = nums[large];
  nums[large] = temp;
}

void SelectionSort(int *unsorted, int size)
{
  if (size != 1)
  {
    for (int i = 0; i < size - 1; i++)
    {
      int smallest = i;

      for (int j = i + 1; j < size; j++)
      {
        if (unsorted[j] < unsorted[smallest])
        {
          smallest = j;
        }
      }
      swap(unsorted, smallest, i);
    }
  }
}

bool fileExists()
{
  std::fstream inputFile;
  inputFile.open("array.csv");
  bool exists = inputFile.good();
  inputFile.close();

  return exists;
}

int main(int argc, char const *argv[])
{
  bool valid = false;
  int size;
  int *unsorted;

  if (fileExists())
  {
    std::string temp;
    int *tempArr = new int[1000];
    size = 0;
    std::fstream inputFile;
    inputFile.open("array.csv");
    while (std::getline(inputFile, temp, ','))
    {
      tempArr[size] = std::stoi(temp);
      size += 1;
    }
    unsorted = new int[size];
    for (int i = 0; i < size; i++)
    {
      unsorted[i] = tempArr[i];
    }
    delete[] tempArr;
    tempArr = nullptr;
  }
  else
  {
    while (!valid)
    {
      std::cout << "Enter array size between 1 and 1000:\n";
      try
      {
        std::cin >> size;
        if (size < 1 || size > 1000)
        {
          std::cout << "Array size must be between 1 and 1000\n\n";
        }
        else
        {
          valid = true;
        }
      }
      catch (const std::exception &e)
      {
        std::cout << "Please only enter a number\n\n";
      }
    }
    unsorted = new int[size];

    std::cout << std::endl;

    for (int i = 0; i < size; i++)
    {
      valid = false;
      while (!valid)
      {
        try
        {
          std::cout << "Enter a number for element " << i << ":\n";
          std::cin >> unsorted[i];
          valid = true;
        }
        catch (const std::exception &e)
        {
          std::cout << "Please only enter a number\n\n";
        }
      }
    }
  }

  std::cout << "\nSorting Array\n";

  SelectionSort(unsorted, size);

  std::cout << "Array sorted:\n";

  for (int i = 0; i < size; i++)
  {
    std::cout << unsorted[i] << " ";
  }
  std::cout << std::endl;

  delete[] unsorted;
  unsorted = nullptr;

  return 0;
}
