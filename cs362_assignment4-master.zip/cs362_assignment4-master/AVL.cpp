#include <iostream>
#include <stdexcept>

#include "AVL.h"

#define MAX_DIFFERENCE 1

AVL::AVL()
    : root_(nullptr)
{
}

bool AVL::isEmpty()
{
  return root_ == nullptr;
}

void AVL::clear()
{
  root_->~Node();
  root_.reset();
}

void AVL::printTree()
{
  std::cout << std::endl;
  inorderPrint(root_);
  std::cout << std::endl;
}

void AVL::insert(int insertKey)
{
  if (!isEmpty())
  {
    insertInternal(insertKey, root_);
  }
  else
  {
    root_ = std::shared_ptr<Node>(new Node(insertKey));
  }
}

void AVL::remove(int removeKey)
{
  removeInternal(removeKey, root_);
}

int AVL::getTreeHeight()
{
  int height = 0;
  if (root_ != nullptr)
  {
    height = root_->getHeight();
  }

  return height;
}

std::shared_ptr<Node> AVL::getRootNode()
{
  return root_;
}

std::shared_ptr<Node> AVL::getMaxNode()
{
  std::shared_ptr<Node> maxNode = root_;
  std::shared_ptr<Node> currentNode = root_;
  while (currentNode != nullptr)
  {
    maxNode = currentNode;
    currentNode = currentNode->getRightChild();
  }

  return maxNode;
}

std::shared_ptr<Node> AVL::getMinNode()
{
  std::shared_ptr<Node> minNode = root_;
  std::shared_ptr<Node> currentNode = root_;
  while (currentNode != nullptr)
  {
    minNode = currentNode;
    currentNode = currentNode->getLeftChild();
  }

  return minNode;
}

int AVL::getRootKey()
{
  if (root_ = nullptr)
  {
    throw std::out_of_range("root is null");
  }
  return root_->getKey();
}

int AVL::getMaxKey()
{
  int maxKey = 0;
  std::shared_ptr<Node> currentNode = root_;
  while (currentNode != nullptr)
  {
    maxKey = currentNode->getKey();
    currentNode = currentNode->getRightChild();
  }

  return maxKey;
}

int AVL::getMinKey()
{
  int minKey = 0;
  std::shared_ptr<Node> currentNode = root_;
  while (currentNode != nullptr)
  {
    minKey = currentNode->getKey();
    currentNode = currentNode->getLeftChild();
  }

  return minKey;
}

void AVL::insertInternal(int insertKey, std::shared_ptr<Node> rootNode)
{
  if (insertKey < rootNode->getKey())
  {
    if (rootNode->getLeftChild() == nullptr)
    {
      rootNode->setLeftChild(std::shared_ptr<Node>(new Node(insertKey)));
    }
    else
    {
      insertInternal(insertKey, rootNode->getLeftChild());
    }
  }
  else
  {
    if (rootNode->getRightChild() == nullptr)
    {
      rootNode->setRightChild(std::shared_ptr<Node>(new Node(insertKey)));
    }
    else
    {
      insertInternal(insertKey, rootNode->getRightChild());
    }
  }

  rootNode->updateHeight();
  balance(rootNode);
}

void AVL::removeInternal(int removeKey, std::shared_ptr<Node> rootNode)
{
  std::shared_ptr<Node> removable = nullptr;
  bool removableLeft = true;
  if (removeKey < rootNode->getKey())
  {
    if (rootNode->getLeftChild() == nullptr)
    {
      throw std::out_of_range("Node does not exist");
    }
    else if (removeKey == rootNode->getLeftChild()->getKey())
    {
      removable = rootNode->getLeftChild();
    }
    else
    {
      removeInternal(removeKey, rootNode->getLeftChild());
    }
  }
  else if (removeKey > rootNode->getKey())
  {
    if (rootNode->getRightChild() == nullptr)
    {
      throw std::out_of_range("Node does not exist");
    }
    else if (removeKey == rootNode->getRightChild()->getKey())
    {
      removable = rootNode->getRightChild();
      removableLeft = false;
    }
    else
    {
      removeInternal(removeKey, rootNode->getRightChild());
    }
  }

  // if correct node found
  if (removable != nullptr)
  {
    // left child of removable is null
    if (removable->getLeftChild() == nullptr)
    {
      rootNode->setLeftChild(removable->getRightChild());
    }
    // right child of removable is null
    else if (removable->getRightChild() == nullptr)
    {
      rootNode->setLeftChild(removable->getLeftChild());
    }
    // neither child is null
    else
    {
      // if node is in the left tree
      if (removableLeft)
      {
        std::shared_ptr<Node> replace = getMaxNodeSubtree(removable);
        rootNode->setLeftChild(std::shared_ptr<Node>(new Node(replace->getKey())));
        rootNode->getLeftChild()->setLeftChild(removable->getLeftChild());
        rootNode->getLeftChild()->setRightChild(removable->getRightChild());
        removeInternal(replace->getKey(), replace->getRightChild());
      }
      else
      {
        std::shared_ptr<Node> replace = getMaxNodeSubtree(removable->getLeftChild());
        rootNode->setLeftChild(std::shared_ptr<Node>(new Node(replace->getKey())));
        rootNode->getLeftChild()->setLeftChild(removable->getLeftChild());
        rootNode->getLeftChild()->setRightChild(removable->getRightChild());
        removeInternal(replace->getKey(), replace->getRightChild());
      }
    }

    removable->setLeftChild(nullptr);
    removable->setRightChild(nullptr);
  }
  rootNode->updateHeight();
  balance(rootNode);
}

std::shared_ptr<Node> AVL::getMinNodeSubtree(std::shared_ptr<Node> root)
{
  std::shared_ptr<Node> minNode = root;
  std::shared_ptr<Node> currentNode = root;

  while (currentNode != nullptr)
  {
    minNode = currentNode;
    currentNode = currentNode->getLeftChild();
  }

  return minNode;
}

std::shared_ptr<Node> AVL::getMaxNodeSubtree(std::shared_ptr<Node> root)
{
  std::shared_ptr<Node> maxNode = root;
  std::shared_ptr<Node> currentNode = root;

  while (currentNode != nullptr)
  {
    maxNode = currentNode;
    currentNode = currentNode->getRightChild();
  }

  return maxNode;
}

void AVL::balance(std::shared_ptr<Node> node)
{
  if (node->getLeftChild() != nullptr)
  {
    if (node->getRightChild() != nullptr)
    {
      // if imabalance on the left tree, case 1 or 2
      if (node->getLeftChild()->getHeight() - node->getRightChild()->getHeight() > MAX_DIFFERENCE)
      {
        checkBalanceCaseLeft(node);
      }
      // else if imbalance on the right tree, case 3 or 4
      else if (node->getRightChild()->getHeight() - node->getLeftChild()->getHeight() > MAX_DIFFERENCE)
      {
        checkBalanceCaseRight(node);
      }
    }
    else
    {
      checkBalanceCaseLeft(node);
    }
  }
  if (node->getRightChild() != nullptr)
  {
    checkBalanceCaseRight(node);
  }

  node->updateHeight();
}

void AVL::checkBalanceCaseLeft(std::shared_ptr<Node> node)
{
  if (node->getLeftChild() != nullptr)
  {
    if (node->getLeftChild()->getLeftChild() != nullptr && node->getLeftChild()->getRightChild() != nullptr)
    {
      // if case 1, single rotation in left
      if (node->getLeftChild()->getLeftChild()->getHeight() > node->getLeftChild()->getRightChild()->getHeight())
      {
        rotateLeftChild(node);
      }
      // case 2, double rotation in left
      else if (node->getLeftChild()->getLeftChild()->getHeight() < node->getLeftChild()->getRightChild()->getHeight())
      {
        doubleRotateLeftChild(node);
      }
    }
    // also case 2
    else if (node->getLeftChild()->getLeftChild() == nullptr && node->getLeftChild()->getRightChild() != nullptr)
    {
      doubleRotateLeftChild(node);
    }
    // also case 1
    else if (node->getLeftChild()->getRightChild() == nullptr && node->getLeftChild()->getLeftChild() != nullptr)
    {
      rotateLeftChild(node);
    }
  }
}

void AVL::checkBalanceCaseRight(std::shared_ptr<Node> node)
{
  if (node->getRightChild() != nullptr)
  {
    if (node->getRightChild()->getLeftChild() != nullptr && node->getRightChild()->getRightChild() != nullptr)
    {
      // if case 3, double rotation in right
      if (node->getRightChild()->getLeftChild()->getHeight() > node->getRightChild()->getRightChild()->getHeight())
      {
        doubleRotateRightChild(node);
      }
      // case 4, single rotation in right
      else
      {
        rotateLeftChild(node);
      }
    }
    // also case 4
    else if (node->getRightChild()->getLeftChild() == nullptr && node->getRightChild()->getRightChild() != nullptr)
    {
      rotateRightChild(node);
    }
    // also case 3
    else if (node->getRightChild()->getRightChild() == nullptr && node->getRightChild()->getLeftChild() != nullptr)
    {
      doubleRotateRightChild(node);
    }
  }
}

void AVL::rotateLeftChild(std::shared_ptr<Node> node)
{
  std::shared_ptr<Node> removeNode = node->getLeftChild();
  std::shared_ptr<Node> rotateNode = std::shared_ptr<Node>(new Node(node->getKey()));

  rotateNode->setLeftChild(removeNode->getRightChild());
  rotateNode->setRightChild(node->getRightChild());

  node->setKey(removeNode->getKey());
  node->setRightChild(rotateNode);
  node->setLeftChild(removeNode->getLeftChild());

  removeNode->setLeftChild(nullptr);
  removeNode->setRightChild(nullptr);

  node->updateHeight();
  rotateNode->updateHeight();
}

void AVL::rotateRightChild(std::shared_ptr<Node> node)
{
  std::shared_ptr<Node> removeNode = node->getRightChild();
  std::shared_ptr<Node> rotateNode = std::shared_ptr<Node>(new Node(node->getKey()));

  rotateNode->setRightChild(removeNode->getLeftChild());
  rotateNode->setLeftChild(node->getLeftChild());

  node->setKey(removeNode->getKey());
  node->setLeftChild(rotateNode);
  node->setRightChild(removeNode->getRightChild());

  removeNode->setLeftChild(nullptr);
  removeNode->setRightChild(nullptr);

  node->updateHeight();
  rotateNode->updateHeight();
}

void AVL::doubleRotateLeftChild(std::shared_ptr<Node> node)
{
  rotateRightChild(node->getLeftChild());
  rotateLeftChild(node);
}

void AVL::doubleRotateRightChild(std::shared_ptr<Node> node)
{
  rotateLeftChild(node->getRightChild());
  rotateRightChild(node);
}

void AVL::inorderPrint(std::shared_ptr<Node> node)
{
  if (node->getLeftChild() != nullptr)
  {
    inorderPrint(node->getLeftChild());
  }

  std::cout << node->getKey() << ", ";

  if (node->getRightChild() != nullptr)
  {
    inorderPrint(node->getRightChild());
  }
}
