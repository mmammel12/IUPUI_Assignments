#include "Node.h"

Node::Node(int key)
    : left_(nullptr),
      right_(nullptr),
      key_(key),
      height_(1)
{
}

Node::~Node()
{
  if (left_ != nullptr)
  {
    left_->~Node();
    left_.reset();
  }
  if (right_ != nullptr)
  {
    right_->~Node();
    right_.reset();
  }
}

const Node &Node::operator=(const Node &rhs)
{
  this->left_ = rhs.left_;
  this->right_ = rhs.right_;
  this->key_ = rhs.key_;
  this->height_ = rhs.height_;
}

std::shared_ptr<Node> Node::getLeftChild()
{
  return left_;
}

std::shared_ptr<Node> Node::getRightChild()
{
  return right_;
}

int Node::getKey()
{
  return key_;
}

int Node::getHeight()
{
  return height_;
}

void Node::setLeftChild(std::shared_ptr<Node> newLeft)
{
  left_ = newLeft;
}

void Node::setRightChild(std::shared_ptr<Node> newRight)
{
  right_ = newRight;
}

void Node::setKey(int newKey)
{
  key_ = newKey;
}

void Node::updateHeight()
{
  if (left_ == nullptr)
  {
    if (right_ == nullptr)
    {
      height_ = 1;
    }
    else
    {
      if (height_ != right_->getHeight() + 1)
      {
        height_ = right_->getHeight() + 1;
      }
    }
  }
  else if (right_ != nullptr)
  {
    if (left_->getHeight() > right_->getHeight())
    {
      if (height_ != left_->getHeight() + 1)
      {
        height_ = left_->getHeight() + 1;
      }
    }
    else
    {
      if (height_ != right_->getHeight() + 1)
      {
        height_ = right_->getHeight() + 1;
      }
    }
  }
  else
  {
    if (height_ != left_->getHeight() + 1)
    {
      height_ = left_->getHeight() + 1;
    }
  }
}
