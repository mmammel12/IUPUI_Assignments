#ifndef NODE_H_EXISTS
#define NODE_H_EXISTS

#include <memory>

class Node
{
public:
  // key constructor
  Node(int key);

  // destructor
  ~Node();

  const Node &operator=(const Node &rhs);

  /*
  / getters
  */
  // get left child node
  std::shared_ptr<Node> getLeftChild();

  // get right child node
  std::shared_ptr<Node> getRightChild();

  // get node key
  int getKey();

  // get node height
  int getHeight();

  /*
  / setters
  */
  // set left child node
  void setLeftChild(std::shared_ptr<Node> newLeft);

  // set right child node
  void setRightChild(std::shared_ptr<Node> newRight);

  void setKey(int newKey);

  // update height
  void updateHeight();

private:
  // left child
  std::shared_ptr<Node> left_;

  // right child
  std::shared_ptr<Node> right_;

  // key
  int key_;

  // height of the node
  int height_;

  // don't need default constructor
  Node() = delete;
};

#endif