#ifndef AVL_H_EXISTS
#define AVL_H_EXISTS

#include "Node.h"
#include <memory>

class AVL
{
public:
  // default constructor
  AVL();

  // destructor
  ~AVL() = default;

  // returns true if root is null
  bool isEmpty();

  // clears the tree
  void clear();

  // prints the tree inorder
  void printTree();

  // insert new node
  void insert(int insertKey);

  // remove node
  void remove(int removeKey);

  // return height of root
  int getTreeHeight();

  /*
  / node getters
  */

  // return the root node
  std::shared_ptr<Node> getRootNode();

  // return the max node of the entire tree
  std::shared_ptr<Node> getMaxNode();

  // return the minimum node of the entire tree
  std::shared_ptr<Node> getMinNode();

  /*
  / key getters
  */

  // return the root key of the entire tree
  int getRootKey();

  // return the max key of the entire tree
  int getMaxKey();

  // return the minimum key of the entire tree
  int getMinKey();

private:
  std::shared_ptr<Node> root_;

  // actual insert method, finds the correct location to insert and balances
  void insertInternal(int insertKey, std::shared_ptr<Node> rootNode);

  // actual remove method, finds the correct node and removes it
  void removeInternal(int removeKey, std::shared_ptr<Node> rootNode);

  // get the minimum node of a subtree
  std::shared_ptr<Node> getMinNodeSubtree(std::shared_ptr<Node> root);

  // get the maximum node of a subtree
  std::shared_ptr<Node> getMaxNodeSubtree(std::shared_ptr<Node> root);

  // balances the node
  void balance(std::shared_ptr<Node> node);

  // checks for balance issues in left subtree
  void checkBalanceCaseLeft(std::shared_ptr<Node> node);

  // checks for balance issues in right subtree
  void checkBalanceCaseRight(std::shared_ptr<Node> node);

  // single rotation with left child
  void rotateLeftChild(std::shared_ptr<Node> node);

  // single rotation with right child
  void rotateRightChild(std::shared_ptr<Node> node);

  // double rotation with left child
  void doubleRotateLeftChild(std::shared_ptr<Node> node);

  // double rotation with right child
  void doubleRotateRightChild(std::shared_ptr<Node> node);

  void inorderPrint(std::shared_ptr<Node> node);
};

#endif