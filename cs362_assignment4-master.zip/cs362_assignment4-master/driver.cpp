#include <iostream>

#include "AVL.h"

int main(int argc, char const *argv[])
{
  bool valid = false;
  int size;
  int *unsorted;

  while (!valid)
  {
    std::cout << "Enter array size between 1 and 1000:\n";
    try
    {
      std::cin >> size;
      if (size < 1 || size > 1000)
      {
        std::cout << "Array size must be between 1 and 1000\n\n";
      }
      else
      {
        valid = true;
      }
    }
    catch (const std::exception &e)
    {
      std::cout << "Please only enter a number\n\n";
    }
  }
  unsorted = new int[size];

  std::cout << std::endl;

  for (int i = 0; i < size; i++)
  {
    valid = false;
    while (!valid)
    {
      try
      {
        std::cout << "Enter a number for element " << i << ":\n";
        std::cin >> unsorted[i];
        valid = true;
      }
      catch (const std::exception &e)
      {
        std::cout << "Please only enter a number\n\n";
      }
    }
  }

  AVL avl;

  for (int i = 0; i < size; i++)
  {
    avl.insert(unsorted[i]);
  }

  delete[] unsorted;
  unsorted = nullptr;

  avl.printTree();

  return 0;
}
