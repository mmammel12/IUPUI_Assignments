public interface Encryptable {
  abstract byte[] encrypt(String pass);
} // end Encryptable