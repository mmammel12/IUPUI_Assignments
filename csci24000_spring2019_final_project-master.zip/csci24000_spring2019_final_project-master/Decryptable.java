public interface Decryptable {
  abstract String decrypt(byte[] encBytes);
} // end Decryptable