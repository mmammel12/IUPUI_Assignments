#include "Parser.h"

#include <fstream>
#include <algorithm>

Hashmap Parser::parse(std::string file_name)
{
  std::string line;

  std::ifstream file(file_name);
  if (file.is_open())
  {
    while (getline(file, line))
    {
      line.erase(std::remove(line.begin(), line.end(), '\n'), line.end());
      line.erase(std::remove(line.begin(), line.end(), '\r'), line.end());
      map_.insertItem(line);
    }
  }

  return map_;
}