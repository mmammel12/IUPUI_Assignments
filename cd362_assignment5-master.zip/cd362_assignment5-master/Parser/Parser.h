#ifndef PARSER_EXISTS
#define PARSER_EXISTS

#include "../Hashmap/Hashmap.h"
#include <string>

class Parser
{
public:
  Parser() = default;
  ~Parser() = default;

  Hashmap parse(std::string file_name);

private:
  Hashmap map_;
};

#endif