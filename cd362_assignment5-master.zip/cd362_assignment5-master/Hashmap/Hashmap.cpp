#include "Hashmap.h"
#include <locale>

#define OFFSET 97
#define NO_CHAR 26

void Hashmap::insertItem(std::string str)
{
  int first = _get_first_char_int(str);

  int second = _get_second_char_int(str);

  map_[first][second].push_back(str);
}

std::list<std::string> Hashmap::find(std::string str)
{
  int first = _get_first_char_int(str);

  int second = _get_second_char_int(str);

  std::list<std::string> list(map_[first][second]);

  if (list.empty())
  {
    list.push_front("False");
  }
  else
  {
    list.sort();
    list.push_front("True");
  }

  return list;
}

int Hashmap::_get_first_char_int(const std::string &str)
{
  int index = int(str.at(0)) - OFFSET;

  // catch for uppercase letters
  if (index < 0)
  {
    index += 32;
  }

  return index;
}

int Hashmap::_get_second_char_int(const std::string &str)
{
  int index;
  if (str.length() > 1)
  {
    index = int(str.at(1)) - OFFSET;
  }
  else
  {
    index = NO_CHAR;
  }

  return index;
}
