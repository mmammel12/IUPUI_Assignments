#ifndef HASHMAP_EXISTS
#define HASHMAP_EXISTS

#include <array>
#include <list>
#include <string>

#define ALPHA_LENGTH 26

class Hashmap
{
public:
  Hashmap() = default;
  ~Hashmap() = default;

  void insertItem(std::string str);

  std::list<std::string> find(std::string str);

private:
  std::array<std::array<std::list<std::string>, ALPHA_LENGTH + 1>, ALPHA_LENGTH> map_;

  int _get_first_char_int(const std::string &str);

  int _get_second_char_int(const std::string &str);
};

#endif