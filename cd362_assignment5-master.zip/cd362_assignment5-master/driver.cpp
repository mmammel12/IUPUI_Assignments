#include "Hashmap/Hashmap.h"
#include "Parser/Parser.h"
#include <string>
#include <iostream>
#include <list>

int main(int argc, char const *argv[])
{
  std::string file_name;

  if (argc == 2)
  {
    file_name = argv[1];
  }
  else
  {
    std::cout << "Enter Dictionary File Name:" << std::endl;

    std::cin >> file_name;
  }

  Parser parser;

  Hashmap hashmap = parser.parse(file_name);

  std::string input;

  while (true)
  {
    std::cout << "Enter word (QUIT to quit):" << std::endl;

    std::cin >> input;

    if (input == "QUIT")
    {
      break;
    }
    else
    {
      std::list<std::string> list = hashmap.find(input);
      std::cout << std::endl;

      int size = list.size();

      for (size_t i = 0; i < size; i++)
      {
        std::cout << list.front() << std::endl;
        list.pop_front();
      }
      std::cout << std::endl;
    }
  }

  return 0;
}
