#include <iostream>
#include <stdlib.h>
#include "horse.h"

Horse::Horse()
{
  // initialize horse at starting position (0)
  Horse::position = 0;
}

void Horse::advance()
{
  // flip a coin to see if the horse moves forward
  if (rand() % 2 == 1)
  {
    Horse::position++;
  }
}

int Horse::getPosition()
{
  return Horse::position;
}