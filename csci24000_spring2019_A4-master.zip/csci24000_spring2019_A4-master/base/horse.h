#ifndef HORSE_H_EXISTS
#define HORSE_H_EXISTS

class Horse
{
  private:
    // current position of the horse
    int position;

  public:
    // constructor
    Horse();

    // coin flip to advance the horse position
    void advance();

    // return the position of the horse
    int getPosition();
};

#endif