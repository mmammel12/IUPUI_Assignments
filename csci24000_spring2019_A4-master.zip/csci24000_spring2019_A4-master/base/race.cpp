#include <iostream>
#include "horse.h"
#include "race.h"

const int NUM_HORSES = 5;
const int DEFAULT_LENGTH = 15;

Race::Race()
{
  // initialize race length to default
  Race::length = DEFAULT_LENGTH;

  // fill h array with Horse objects
  for (int i = 0; i < NUM_HORSES; i++)
  {
    Race::h[i] = Horse();
  }
}

Race::Race(int length)
{
  // initialize race length to passed in value
  Race::length = length;

  // fill h array with horses
  for (int i = 0; i < NUM_HORSES; i++)
  {
    Race::h[i] = Horse();
  }
}


void Race::printLane(int horseNum)
{
  for (int i = 0; i < Race::length; i++)
  {
    if (h[horseNum].getPosition() == i)
    {
      // horse is in this position, print its number
      std::cout << horseNum;
    }
    else
    {
      // horse not here, print a period
      std::cout << ".";
    }
  }
  // end line for next horse
  std::cout << std::endl;
}

bool Race::checkForWinner()
{
  // assume no winner
  bool winner = false;

  for (int i = 0; i < NUM_HORSES; i++)
  {
    if (h[i].getPosition() == Race::length)
    {
      // horse at final position, return true
      winner = true;
    }
  }

  return winner;
}

void Race::start()
{
  // initialize sentry for while loop
  bool keepGoing = true;

  while (keepGoing)
  {
    for (int i = 0; i < NUM_HORSES; i++)
    {
      // print each lane of the race
      Race::printLane(i);
    }
    // for formatting to separate each iteration of the race
    std::cout << std::endl;
    std::cout << "Press enter to continue" << std::endl;
    std::cin.ignore();

    if (Race::checkForWinner())
    {
      // we have a winner, set sentry to false to exit the loop
      keepGoing = false;

      // print the winner
      for (int i = 0; i < NUM_HORSES; i++)
      {
        if (h[i].getPosition() == Race::length)
        {
          std::cout << "Horse " << i << " wins!" << std::endl;
        }
      }
    }
    else
    {
      // no winner, advance each horse (according to their RNG)
      for (int i = 0; i < NUM_HORSES; i++)
      {
        h[i].advance();
      }
    }
  }
}