#ifndef RACE_H_EXISTS
#define RACE_H_EXISTS

#include "horse.h"

class Race
{
  private:
    // horse object
    Horse h[5];

    // length of the track
    int length;

  public:
    // default constructor
    Race();

    // constructor if length has been passed in
    Race(int length);

    // print the lane the horse is in
    void printLane(int horseNum);

    // determine if there is a winner
    bool checkForWinner();

    // start the race
    void start();
};

#endif
