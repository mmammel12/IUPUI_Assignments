#include <iostream>
#include <stdlib.h>
#include "race.h"

int main()
{
  // get seed for RNG
  int seed;
  std::cout << "Please enter a random seed: ";
  std::cin >> seed;
  std::cout << std::endl;

  // need this to flush the cin buffer
  std::cin.ignore();

  // seed rng
  srand(seed);

  Race r;

  r.start();

  return (0);
}