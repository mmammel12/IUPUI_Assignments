# csci24000_spring2019_A4

## Marty Mammel

## Base Algorithm

Goals:

- race horses
- teach horses to flip a coin
- update the status of the race
- print the race status
- repeat until a horse has won

Input:

- Random seed from user

Output:

- status of the race

Classes:

- Horse
- Race

### functions

main()

> Goals:
>
> - seed RNG
> - start the race
>
> Input:
>
> - none
>
> Output:
>
> - none
>
> Steps:
>
> - ask user for random seed
> - seed RNG
> - create new race object
> - call start method of Race object

### Classes

Horse:

> Goals:
>
> - learn to flip a coin
> - know current position
> - advance on coin flip
>
> Input:
>
> - none
>
> Output:
>
> - current position
>
> Properties:
>
> - int position
>
> Methods:
>
> > Horse()
> >
> > Goals:
> >
> > - initialize horse object
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - none
> >
> > Steps:
> >
> > - set position to 0
>
> > advance()
> >
> > Goals:
> >
> > - flip a coin to see if the horse moves
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - none, changes position property
> >
> > Steps:
> >
> > - generate random number, 0 or 1
> > - if the roll is 1, increment position property
> > - do nothing if roll is 0
>
> > getPosition()
> >
> > Goals:
> >
> > - return the current position of the horse
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - current position of the horse
> >
> > Steps:
> >
> > - return the current position of the horse

Race:

> Goals:
>
> - main game loop
> - call horse methods to iterate the race
> - determine when there is a winner and end the game
>
> Input:
>
> - none
>
> Output:
>
> - current status of the race
>
> Properties:
>
> - Horse h
> - int length
>
> Methods:
>
> > Race()
> >
> > Goals:
> >
> > - initialize race object with the default track length
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - none
> >
> > Steps:
> >
> > - create 5 Horse objects in an array
> > - set race length to 15
>
> > Race(int length)
> >
> > Goals:
> >
> > - initialize race object with a specific track length
> >
> > Input:
> >
> > - int length
> >
> > Output:
> >
> > - none
> >
> > Steps:
> >
> > - create 5 Horse objects in an array
> > - set race length to length passed in
>
> > printLane()
> >
> > Goals:
> >
> > - print the lane the horse is in and the horse position
> >
> > Input:
> >
> > - int horseNum
> >
> > Output:
> >
> > - prints the lane
> >
> > Steps:
> >
> > - print length number of periods
> > - if the position of the current period matches the horse position, print horse number instead
>
> > start()
> >
> > Goals:
> >
> > - start the race
> > - determine if there is a winner
> > - print the winner if there is one
> > - call advance method for each horse
> > - call race.printLane() for each horse
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - none
> >
> > Steps:
> >
> > - while keepGoing loop
> > - - loop through the horses and call race.printLane()
> > - - if there is a winner, end the loop and print the winner
> > - - if there is not a winner, call advance method for each horse
>
> > checkForWinner()
> >
> > Goals:
> >
> > - Determine if there is a winner
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - returns a boolean depending on if there is a winner
> >
> > Steps:
> >
> > - loop through horses
> > - if horse position matches race length, return true
> > - if not, return false
