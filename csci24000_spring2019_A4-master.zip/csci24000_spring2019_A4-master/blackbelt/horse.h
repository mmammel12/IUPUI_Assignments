#ifndef HORSE_H_EXISTS
#define HORSE_H_EXISTS

class Horse
{
private:
  // current position of the horse
  int position;

  // possible breeds
  std::string breeds[15] = {
      "Brumby",
      "Danish Warmblood",
      "Freiberger",
      "Novokirghiz",
      "Pintabian",
      "Walkaloosa",
      "Zweibrücker",
      "Maremmano",
      "Orlov trotter",
      "Kiger Mustang",
      "Haflinger",
      "Arenberg-Nordkirchen",
      "Dølahest",
      "Nooitgedachter",
      "Schwarzwälder Kaltblut"};

  // breed of the horse
  std::string breed;

  // odds for betting
  float odds;

  // int for how likely it is to move
  int moveChance;

public:
  // constructor
  Horse();

  // coin flip to advance the horse position
  void advance();

  // return the position of the horse
  int getPosition();

  // breed getter
  std::string getBreed();

  // odds getter
  float getOdds();
};

#endif