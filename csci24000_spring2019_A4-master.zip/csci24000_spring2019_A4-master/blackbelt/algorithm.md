# black belt oop horse race

## Marty Mammel

## Algorithm

Goals:

- race horses
- let player bet on the race
- set odds for the horses and breeds
- teach horses to flip a coin (with odds different than 50/50)
- update the status of the race
- print the race status
- repeat until a horse has won

Input:

- Random seed from user
- bet amount and which horse the user is betting on

Output:

- status of the race

Classes:

- Horse
- Race
- Player

### functions

main()

> Goals:
>
> - seed RNG
> - start the race
>
> Input:
>
> - none
>
> Output:
>
> - none
>
> Steps:
>
> - while keepGoing loop
> - ask user for random seed
> - seed RNG
> - create new race object
> - call start method of Race object
> - ask the user if they want to keep playing
> - if yes, do nothing
> - if no, set keepGoing to false to exit

### Classes

Horse:

> Goals:
>
> - learn to flip a coin (with odds different than 50/50)
> - know current position
> - know breed
> - know odds
> - knows chance to move
> - advance on coin flip
>
> Input:
>
> - none
>
> Output:
>
> - current position
> - breed
> - odds
>
> Properties:
>
> - int position
> - string breed
> - float odds
> - int moveChance
> - const string[] breeds
>
> Methods:
>
> > Horse()
> >
> > Goals:
> >
> > - initialize horse object
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - none
> >
> > Steps:
> >
> > - set position to 0
> > - randomly select breed
> > - randomly set odds
> > - randomly set moveChance
>
> > advance()
> >
> > Goals:
> >
> > - flip a coin (with odds different than 50/50) to see if the horse moves
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - none, changes position property
> >
> > Steps:
> >
> > - generate random number, 0-99
> > - if the roll is less than moveChance, increment position property
> > - do nothing if roll is larger than moveChance
>
> > getBreed():
> >
> > Goals:
> >
> > return the breed
> >
> > Input:
> >
> > none
> >
> > Output:
> >
> > breed string
> >
> > Steps:
> >
> > return the breed
>
> > getodds():
> >
> > Goals:
> >
> > return the odds
> >
> > Input:
> >
> > none
> >
> > Output:
> >
> > odds float
> >
> > Steps:
> >
> > return the odds
>
> > getPosition()
> >
> > Goals:
> >
> > - return the current position of the horse
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - current position of the horse
> >
> > Steps:
> >
> > - return the current position of the horse

Race:

> Goals:
>
> - main game loop
> - allow the player to place a bet
> - call horse methods to iterate the race
> - determine when there is a winner and end the game
>
> Input:
>
> - none
>
> Output:
>
> - current status of the race
>
> Properties:
>
> - Horse h
> - Player p
> - int length
> - float betAmount
> - int betHorse
>
> Methods:
>
> > Race()
> >
> > Goals:
> >
> > - initialize race object with the default track length
> > - initialize the player (1) and Horse (5) objects
> > - initialize the betAmount and betHorse to 0
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - none
> >
> > Steps:
> >
> > - create 1 Player object
> > - create 5 Horse objects in an array
> > - set race length to 15
> > - set betAmount and betHorse to 0
>
> > placeBet()
> >
> > Goals:
> >
> > - let the user place a bet if they have enough money
> >
> > Input:
> >
> > - none passed in
> > - takes in input from the user
> >
> > Output:
> >
> > - none, sets betAmount and betHorse
> >
> > Steps:
> >
> > - print current cash for the player
> > - ask how much they want to bet
> > - validate they have enough cash
> > - if they do, set the betAmount
> > - if they don't ask again until they do or they quit betting
> > - print horse odds
> > - ask which horse they want to bet on
> > - validate
>
> > printLane()
> >
> > Goals:
> >
> > - print the lane the horse is in and the horse position
> >
> > Input:
> >
> > - int horseNum
> >
> > Output:
> >
> > - prints the lane
> >
> > Steps:
> >
> > - print length number of periods
> > - if the position of the current period matches the horse position, print horse number instead
>
> > start()
> >
> > Goals:
> >
> > - start the race
> > - determine if there is a winner
> > - print the winner if there is one
> > - call advance method for each horse
> > - call race.printLane() for each horse
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - none
> >
> > Steps:
> >
> > - while keepGoing loop
> > - - loop through the horses and call race.printLane()
> > - - if there is a winner, end the loop and print the winner
> > - - if there is not a winner, call advance method for each horse
>
> > checkForWinner()
> >
> > Goals:
> >
> > - Determine if there is a winner
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - returns a boolean depending on if there is a winner
> >
> > Steps:
> >
> > - loop through horses
> > - if horse position matches race length, return true
> > - if not, return false
>
> > printWinner()
> >
> > Goals:
> >
> > - print the winner
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - prints the winner to the console
> >
> > Steps:
> >
> > - loop through the h array
> > - if the horse position is the same as the track length, it won
>
> > advanceRace()
> >
> > Goals:
> >
> > - advance the race
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - none
> >
> > Steps:
> >
> > - loop through h array
> > - call advance() method for each horse
>
> > printStats()
> >
> > Goals:
> >
> > - print the stats for each horse (breed and odds)
> >
> > Input:
> >
> > -none
> >
> > Output:
> >
> > -prints the breed and odds for each horse
> >
> > Steps:
> >
> > - loop through h array
> > - print the breed and odds for each horse
>
> > printPayout()
> >
> > Goals:
> >
> > - print the result of the bet for the player
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - prints bet result
> >
> > Steps:
> >
> > - if the user bet more than 0
> > - and if the user won, print "congrats you won \$x"
> > - call winCash on Player object
> > - if the user bet more than 0
> > - and they lost, print "you lost $x, you have \$y remaining"
> > - call loseCash on Player object
> > - if the user bet is 0, do nothing

Player

> Goals:
>
> - store cash value
>
> Input:
>
> - none
>
> Output:
>
> - cash
>
> Properties:
>
> - float cash
>
> Methods:
>
> > Player()
> >
> > Goals:
> >
> > initialize the Player object
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - none
> >
> > Steps:
> >
> > - set cash to 500
> >
> > setCash()
> >
> > Goals:
> >
> > - add cash to the player for winning their bet
> > - or remove if they lost
> >
> > Input:
> >
> > - float betValue
> >
> > Output:
> >
> > - adds/removes from cash property
> >
> > Steps:
> >
> > - add/remove betValue from Player::cash
>
> > getCash()
> >
> > Goals:
> >
> > - return the cash property
> >
> > Input:
> >
> > - none
> >
> > Output:
> >
> > - returns the cash property
> >
> > Steps:
> >
> > return the cash property
