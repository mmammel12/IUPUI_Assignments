#include <iostream>
#include <stdlib.h>
#include "horse.h"

Horse::Horse()
{
  // initialize horse at starting position (0)
  Horse::position = 0;

  // randomly select a breed
  Horse::breed = Horse::breeds[rand() % 15];

  // randomly set the odds
  Horse::odds = 1.0 + static_cast<float>(rand() / (static_cast<float>(RAND_MAX / (5.0))));

  Horse::moveChance = 1 + (rand() % 80);
}

void Horse::advance()
{
  if (rand() % 100 < Horse::moveChance)
  {
    Horse::position++;
  }
}

std::string Horse::getBreed()
{
  return Horse::breed;
}

float Horse::getOdds()
{
  return Horse::odds;
}

int Horse::getPosition()
{
  return Horse::position;
}