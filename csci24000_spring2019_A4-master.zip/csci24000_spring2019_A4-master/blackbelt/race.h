#ifndef RACE_H_EXISTS
#define RACE_H_EXISTS

#include "player.h"
#include "horse.h"

class Race
{
private:
  // horse object
  Horse h[5];

  // player object
  Player p;

  // length of the track
  int length;

  // amount the player bet
  float betAmount;

  // which horse the player bet on
  int betHorse;

  // if the player won their bet or not
  bool playerWon;

public:
  // default constructor
  Race(Player p);

  // let the user place a bet
  void placeBet();

  // print the lane the horse is in
  void printLane(int horseNum);

  // determine if there is a winner
  bool checkForWinner();

  // print the winner
  void printWinner();

  // iterate the race
  void advanceRace();

  // print the horse stats
  void printStats();

  // print what the player won/lost
  void printPayout();

  // start the race
  void start();
};

#endif