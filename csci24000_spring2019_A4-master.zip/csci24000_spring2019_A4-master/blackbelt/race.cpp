#include <iostream>
#include <stdlib.h>
#include "race.h"
#include "horse.h"
#include "player.h"

// constant for number of horses
const int NUM_HORSES = 5;

Race::Race(Player p)
{
  // initialize the horses
  for (int i = 0; i < NUM_HORSES; i++)
  {
    h[i] = Horse();
  }

  // player object
  Race::p = p;

  // track length
  Race::length = 15;

  // which horse the player bet on
  Race::betHorse = 0;

  // how much the player bet
  Race::betAmount = 0;

  // set player to not a winner
  Race::playerWon = false;
}

void Race::placeBet()
{
  float bet;

  std::cout << "Your current cash is $" << p.getCash() << std::endl;
  std::cout << "\nHow much do you want to bet? ";

  std::cin >> bet;

  bool invalidBet = true;

  while (invalidBet)
  {
    if (bet <= p.getCash() && bet > 0)
    {
      invalidBet = false;
      Race::betAmount = bet;
    }
    else if (bet == 0)
    {
      invalidBet = false;
    }
    else
    {
      std::cout << "That is not a valid bet, please enter a valid bet or 0 to not bet ";
      std::cin >> bet;
    }
  }

  int horse;

  std::cout << "\nWhich horse do you want to bet on?" << std::endl;

  Race::printStats();

  std::cout << "Please enter 0-4: ";

  std::cin >> horse;

  bool invalidHorse = true;

  while (invalidHorse)
  {
    if (horse < 5 && horse >= 0)
    {
      invalidHorse = false;
      Race::betHorse = horse;
    }
    else
    {
      std::cout << "that is not a valid horse, please enter 0-4: ";
      std::cin >> horse;
    }
  }
}

void Race::printLane(int horseNum)
{
  for (int i = 0; i < Race::length; i++)
  {
    if (h[horseNum].getPosition() == i)
    {
      // horse is in this position, print its number
      std::cout << horseNum;
    }
    else
    {
      // horse not here, print a period
      std::cout << ".";
    }
  }
  // end line for next horse
  std::cout << std::endl;
}

bool Race::checkForWinner()
{
  // assume no winner
  bool winner = false;

  for (int i = 0; i < NUM_HORSES; i++)
  {
    if (h[i].getPosition() == Race::length)
    {
      // horse at final position, return true
      winner = true;
    }
  }

  return winner;
}

void Race::printWinner()
{
  for (int i = 0; i < NUM_HORSES; i++)
  {
    if (h[i].getPosition() == Race::length)
    {
      std::cout << "Horse " << i << " wins!" << std::endl;
      if (i == Race::betHorse)
      {
        Race::playerWon = true;
        Race::betAmount *= h[i].getOdds();
      }
    }
  }
  Race::printPayout();
}

void Race::advanceRace()
{
  for (int i = 0; i < NUM_HORSES; i++)
  {
    h[i].advance();
  }
}

void Race::printStats()
{
  for (int i = 0; i < NUM_HORSES; i++)
  {
    std::cout << "\nHorse " << i << ":\n";
    std::cout << "\tBreed: " << h[i].getBreed() << std::endl;
    std::cout << "\tOdds: " << h[i].getOdds() << std::endl;
  }
}

void Race::printPayout()
{
  if (Race::betAmount > 0)
  {
    if (Race::playerWon)
    {
      std::cout << "Congrats! You won your bet!" << std::endl;
      std::cout << "You win $" << Race::betAmount << "!";

      p.setCash(Race::betAmount);
    }
    else
    {
      std::cout << "You lost, better luck next time!" << std::endl;
      std::cout << "You lost $" << Race::betAmount;

      p.setCash(0 - Race::betAmount);
    }
  }
}

void Race::start()
{
  Race::placeBet();

  bool keepGoing = true;

  while (keepGoing)
  {
    for (int i = 0; i < NUM_HORSES; i++)
    {
      // print each lane of the race
      Race::printLane(i);
      Race::advanceRace();
    }
    std::cout << std::endl;

    if (Race::checkForWinner())
    {
      keepGoing = false;
    }
  }

  Race::printWinner();
}