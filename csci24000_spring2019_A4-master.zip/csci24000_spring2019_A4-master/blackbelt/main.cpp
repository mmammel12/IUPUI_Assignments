#include <iostream>
#include <stdlib.h>
#include "race.h"

bool wantToKeepPlaying();

int main()
{
  std::cout << "I started this later than I should have\n";
  std::cout << "and ran out of time so it doesn't run quite right. rip.\n";

  bool keepGoing = true;

  Player p = Player();

  while (keepGoing)
  {
    // get seed for RNG
    int seed;
    std::cout << "Please enter a random seed: ";
    std::cin >> seed;
    std::cout << std::endl;

    // need this to flush the cin buffer
    std::cin.ignore();

    // seed rng
    srand(seed);

    Race r = Race(p);

    r.start();

    keepGoing = wantToKeepPlaying();
  }

  return (0);
}

bool wantToKeepPlaying()
{
  bool keepPlaying = false;

  bool invalidResponse = true;

  // variable for the user response to continue playing
  std::string response;

  // get the user input
  std::cout << "\nDo you want to keep playing? (y/n): ";
  std::cin >> response;

  while (invalidResponse)
  {
    // change response to uppercase
    response = std::toupper(response[0]);

    if (response == "Y")
    {
      // continue playing
      keepPlaying = true;
      invalidResponse = false;
    }
    else if (response == "N")
    {
      // stop playing
      keepPlaying = false;
      invalidResponse = false;
    }
    else
    {
      std::cout << "Please reply with either 'y' or 'n'\n";
      std::cout << "Do you want keep playing? (y/n): ";
      std::cin >> response;
    }
  }

  return keepPlaying;
}