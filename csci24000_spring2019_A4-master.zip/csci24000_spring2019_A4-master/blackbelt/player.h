#ifndef PLAYER_H_EXISTS
#define PLAYER_H_EXISTS

class Player
{
private:
  // cash value for the play
  float cash;

public:
  // constructor
  Player();

  // setter for cash
  void setCash(float betValue);

  // getter for cash
  float getCash();
};

#endif