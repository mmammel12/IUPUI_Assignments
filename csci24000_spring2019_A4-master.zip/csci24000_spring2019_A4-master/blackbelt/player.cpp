#include <iostream>
#include "player.h"

Player::Player()
{
  // set player cash to starting value of 500
  Player::cash = 500.0;
}

void Player::setCash(float betValue)
{
  Player::cash += betValue;
}

float Player::getCash()
{
  return Player::cash;
}