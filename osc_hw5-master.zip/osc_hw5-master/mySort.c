#include <pthread.h>
#include <stdio.h>
#include <stdlib.h> 
#include <limits.h>


pthread_mutex_t mutex;
int activeThreads = 0;
int* nums;
int n, m;
int slice;
int prevSlice;
int initialSort = 1;
int sorting = 1;
int sortingThreads = 0;
int ready = 0;

typedef struct 
{
    int threadNum;
    int *arr;
    int start;
} threadData;

int compare(const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

void merge(int* arr, int rightStart, int size) {
    int left[size + 1];
    int right[size + 1];
    int sorted[size*2];
    for (int i=0; i<size; i++) {
        left[i] = arr[i];
        right[i] = arr[rightStart+i];
    }
    left[size] = INT_MAX;
    right[size] = INT_MAX;

    int i = 0;
    int j = 0;
    int s = 0;
    while (i != size || j != size) {
        if (left[i] < right[j]) {
            sorted[s] = left[i];
            s++;
            i++;
        }
        else {
            sorted[s] = right[j];
            s++;
            j++;
        }
    }
    pthread_mutex_lock(&mutex);
    for (i=0, s=0; i<size*2; i++, s++) {
        arr[i] = sorted[s];
    }
    pthread_mutex_unlock(&mutex);
    
    return;
}

void* mySort(void *ptr) {
    threadData data = *(threadData *)ptr;
    qsort(data.arr, slice, sizeof(int), compare);
    if (data.threadNum == (m - 1)) {
        while (activeThreads != m) {
            continue;
        }
        initialSort = 0;
        sorting = sorting/2;
    }
    while(initialSort) {
        // wait for all threads to be done with initial sorting
        continue;
    }
    if (data.threadNum % 2 == 0) {
        // only even threads continue
        while(activeThreads > 0) {
            if (data.threadNum == 0) {
                if (m > 1) {
                    m = m/2;
                }
                prevSlice = slice;
                slice = n/m;
                if (activeThreads > 1) {
                    activeThreads = activeThreads/2;
                    sortingThreads = activeThreads;
                }
                else {
                    activeThreads = 0;
                }
            }
            else {
                data.threadNum = data.threadNum / 2;
            }
            pthread_mutex_lock(&mutex);
            ready++;
            pthread_mutex_unlock(&mutex);
            while (ready < m){
                continue;
            }
            merge(data.arr, data.start+prevSlice, prevSlice);
            pthread_mutex_lock(&mutex);
            sortingThreads--;
            pthread_mutex_unlock(&mutex);
            while(sortingThreads > 0) {
                continue;
            }
            if (ready != 0) {
                pthread_mutex_lock(&mutex);
                ready = 0;
                pthread_mutex_unlock(&mutex);
            }
        }
    }
}


int main(int argc, char const *argv[])
{
    if (argc == 4) {
        n = atoi(argv[1]);
        m = atoi(argv[2]);
        char const *fileName = argv[3];
        pthread_mutex_init(&mutex, NULL);

        int numsArr[n];
        nums = numsArr;
        printf("unsorted array:\n");
        for (int i=0; i<n; i++) {
            nums[i] = rand() % (n * 2) + 1;
            printf("%i ", nums[i]);
        }
        printf("\n");
        

        pthread_t threads[m];
        pthread_attr_t attrs[m];

        slice = n/m;
        prevSlice = slice;
        threadData data[m];

        for (int i=0; i<m; i++) {
            activeThreads++;
            sortingThreads++;
            pthread_attr_init(&attrs[i]);
            data[i].threadNum = i;
            data[i].arr = &nums[slice * i];
            data[i].start = slice * i;
            pthread_create(&threads[i], &attrs[i], mySort, &data[i]);
        }

        for (int i=0; i<m; i++) {
            pthread_join(threads[i], NULL);
        }

        FILE *outfile = fopen(fileName, "w");
        printf("\nsorted array:\n");
        for (int i=0; i<n; i++) {
            printf("%i ", nums[i]);
            fprintf(outfile, "%i\n", nums[i]);
        }
        printf("\n");
        fclose(outfile);
    }
    return 0;
}
