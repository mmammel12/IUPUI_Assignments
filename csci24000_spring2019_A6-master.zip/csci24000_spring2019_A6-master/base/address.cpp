#include "address.h"

Address::Address()
{
  // default constructor
  Address::adrLine1 = "MISSING ADR LINE 1";
  Address::adrLine2 = "MISSING ADR LINE 2";
  Address::city = "MISSING CITY";
  Address::state = "MISSING STATE";
  Address::zip = "MISSING ZIP CODE";
}

Address::Address(std::stringstream &addressLine)
{
  // addressLine contains all data for the address object
  std::string data;
  int count = 0;
  while (std::getline(addressLine, data, ','))
  {
    if (count == 0)
    {
      Address::adrLine1 = data;
    }
    else if (count == 1)
    {
      Address::adrLine2 = data;
    }
    else if (count == 2)
    {
      Address::city = data;
    }
    else if (count == 3)
    {
      Address::state = data;
    }
    else if (count == 4)
    {
      Address::zip = data;
    }
    count++;
  }
}

std::string Address::getFullAdr()
{
  // create and return a formatted address string
  std::string formattedAdr = Address::adrLine1 + "\t";
  formattedAdr = formattedAdr + Address::adrLine2 + "\t";
  formattedAdr = formattedAdr + Address::city + "\t\t";
  formattedAdr = formattedAdr + Address::state + "\t";
  formattedAdr = formattedAdr + Address::zip;

  return formattedAdr;
}