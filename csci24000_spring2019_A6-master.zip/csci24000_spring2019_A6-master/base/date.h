#ifndef DATE_H_EXISTS
#define DATE_H_EXISTS

#include <string>

class Date
{
private:
  std::string day;
  std::string month;
  std::string year;

public:
  Date();
  Date(std::string);

  std::string getFullDate();
};

#endif