#ifndef ADDRESS_H_EXISTS
#define ADDRESS_H_EXISTS

#include <string>
#include <sstream>

class Address
{
private:
  std::string adrLine1;
  std::string adrLine2;
  std::string city;
  std::string state;
  std::string zip;

public:
  Address();
  Address(std::stringstream &);

  std::string getFullAdr();
};

#endif