#include "student.h"

Student::Student()
{
  Student::firstName = "MISSING FIRST NAME";
  Student::lastName = "MISSING LAST NAME";
  Student::adr = new Address();
  Student::DOB = new Date();
  Student::expectedGradDate = new Date();
  Student::GPA = "0.0";
  Student::creditHours = "0";
}

Student::~Student()
{
  delete Student::adr;
  delete Student::DOB;
  delete Student::expectedGradDate;
}

void Student::populate(std::stringstream &studentLine)
{
  // delete old objects on the heap
  delete Student::adr;
  delete Student::DOB;
  delete Student::expectedGradDate;

  std::string data;
  std::stringstream addressData;
  int count = 0;

  while (std::getline(studentLine, data, ','))
  {
    if (count == 0)
    {
      Student::lastName = data;
    }
    else if (count == 1)
    {
      Student::firstName = data;
    }
    else if (count == 2)
    {
      addressData << data << ",";
    }
    else if (count == 3)
    {
      addressData << data << ",";
    }
    else if (count == 4)
    {
      addressData << data << ",";
    }
    else if (count == 5)
    {
      addressData << data << ",";
    }
    else if (count == 6)
    {
      addressData << data << ",";
      Student::adr = new Address(addressData);
    }
    else if (count == 7)
    {
      Student::DOB = new Date(data);
    }
    else if (count == 8)
    {
      Student::expectedGradDate = new Date(data);
    }
    else if (count == 9)
    {
      Student::GPA = data;
    }
    else if (count == 10)
    {
      Student::creditHours = data;
    }

    count++;
  }
}

std::string Student::getLastName() const
{
  return Student::lastName;
}

std::string Student::getFirstName() const
{
  return Student::firstName;
}

std::string Student::getFullName() const
{
  std::string fullName = Student::lastName + "\t";
  fullName = fullName + Student::firstName;

  return fullName;
}

std::string Student::getFullData() const
{
  std::stringstream fullData;
  fullData << Student::getFullName() << "\t\t";
  fullData << Student::adr->getFullAdr() << "\t";
  fullData << Student::DOB->getFullDate() << "\t";
  fullData << Student::expectedGradDate->getFullDate() << "\t";
  fullData << Student::GPA << "\t";
  fullData << Student::creditHours;

  std::string formattedData(fullData.str());

  return formattedData;
}

bool Student::operator<(const Student &rhs) const
{
  bool smaller = false;

  if (this->lastName == rhs.lastName)
  {
    // last names are the same, check first names
    smaller = this->firstName < rhs.firstName;
  }
  else
  {
    // last names not the same
    smaller = this->lastName < rhs.lastName;
  }

  return smaller;
}