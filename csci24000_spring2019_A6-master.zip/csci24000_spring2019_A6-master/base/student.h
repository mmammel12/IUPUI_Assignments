#ifndef STUDENT_H_EXISTS
#define STUDENT_H_EXISTS

#include <string>
#include <sstream>
#include "date.h"
#include "address.h"

class Student
{
private:
  std::string lastName;
  std::string firstName;
  Address *adr;
  Date *DOB;
  Date *expectedGradDate;
  std::string GPA;
  std::string creditHours;

public:
  Student();
  ~Student();

  void populate(std::stringstream &);

  std::string getLastName() const;
  std::string getFirstName() const;
  std::string getFullName() const;
  std::string getFullData() const;

  bool operator<(const Student &) const;
};

#endif