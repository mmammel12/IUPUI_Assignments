# Heap of Students Algorithm

## Marty Mammel

Goals:

- Take in entire file and store it in a stringstream
- create an array of students on the heap
- loop through each line of stringstream and pass line into Student constructor
  - create new student object on the heap
- get the fullReport for each student in the array, write it to fullReport.txt
- get the shortReport for each student in the array, write it to shortReport.txt
- sort the student array
- write student names (now sorted) to alphaReport.txt

Input:

- students.dat contains all of the student data

Output:

- fullReport.txt full report containing all of the student data nicely formatted
- shortReport.txt short report containing only last name and first name
- alphaReport.txt sorted student names

### Classes

#### Student

Goals:

- Student class to store data about students

Input:

- constructor will receive a stringstream reference that will need to be parsed

Output:

- formatted data:
  - all data formatted for fullReport.txt
  - last name and first name formatted for shortReport.txt and alphaReport.txt

Properties:

- firstName - string
- lastName - string
- adr - Address object
- DOB - Date object
- expectedGradDate - Date object
- GPA - float
- creditHours - int

methods:

> Student()
>
> - Goals:
>
>   - default constructor
>
> - Input:
>
>   - none
>
> - Output:
>
>   - none
>
> - Steps
>   - set all properties to NULL or filler
>   - example: lastName set to "MISSING_LAST_NAME"

> Student(stringstream&)
>
> - Goals:
>
>   - overloaded constructor
>
> - Input:
>
>   - stringstream reference containing single line with all student data
>
> - Output:
>
>   - none
>
> - Steps:
>   - loop through line with "," as delimeter
>   - incoming data is in the following form:
>     - Surname,GivenName,StreetAddress,Address 2,City,State,ZipCode,Birthday,Graduation,GPA,Credit Hours Complete
>   - address data needs to be sent into Address class constructor
>   - two Date objects need to be created as well, DOB and expectedGradDate
>   - adr and both dates will be created on the heap

> ~Student()
>
> - Goals:
>
>   - destructor to remove heap allocated memory
>
> - Input:
>
>   - none
>
> - Output:
>
>   - none
>
> - Steps:
>
>   - delete adr
>   - delete DOB
>   - delete expectedGradDate

> getFullName()
>
> - Goals:
>
>   - return last name, first name formatted to be written to a file
>
> - Input:
>
>   - none
>
> - Output:
>
>   - string containing formatted lastName, firstName
>
> - Steps:
>   - create string with lastName, firstName formatted
>   - return formatted string

> getFullData()
>
> - Goals:
>
>   - return all student data formatted to be written to a file
>
> - Input:
>
>   - none
>
> - Output:
>
>   - string containing all student data formatted
>
> - Steps:
>   - create string to hold student data
>   - concatinate formatted data to it until all data is included
>   - return formatted string

> operator< overload
>
> - Goals:
>
>   - overload < operator so students can be sorted
>
> - Input:
>
>   - two student object references
>
> - Output:
>
>   - returns boolean for the comparison of student 1 to student 2
>
> - Steps:
>
>   - compare student last names, return based on alphabet
>   - if the last names are the same check first name
>   - return boolean for result

#### Address

Goals:

- Address class to store address data

Input:

- constructor will receive a stringstream containing:
  - StreetAddress,Address 2,City,State,ZipCode

Output:

- formatted full address for writing to a file

Properties:

- adrLine1 - string
- adrLine2 - string
- city - string
- state - string
- zip - string

methods:

> Address()
>
> - Goals:
>
>   - default constructor
>
> - Input:
>
>   - none
>
> - Output:
>
>   - none
>
> - Steps
>   - set all properties to NULL or filler
>   - example: adrLine1 set to "MISSING_ADR_LINE_1"

> Address(stringstream&)
>
> - Goals:
>
>   - overloaded constructor
>
> - Input:
>
>   - stringstream reference containing single line with all address data
>
> - Output:
>
>   - none
>
> - Steps:
>   - loop through line with "," as delimeter
>   - incoming data is in the following form:
>     - StreetAddress,Address 2,City,State,ZipCode

> getFullAdr()
>
> - Goals:
>
>   - return full address formatted to be written to a file
>
> - Input:
>
>   - none
>
> - Output:
>
>   - string containing formatted full address
>
> - Steps:
>   - create string with full address formatted
>   - return formatted string

#### Date

Goals:

- Date class to store address data

Input:

- constructor will receive a string containing:
  - mm/dd/yyyy

Output:

- formatted full date for writing to a file

Properties:

- day - string
- month - string
- year - string

methods:

> Date()
>
> - Goals:
>
>   - default constructor
>
> - Input:
>
>   - none
>
> - Output:
>
>   - none
>
> - Steps
>   - set all properties to default values
>   - example: day set to "01"

> Date(string)
>
> - Goals:
>
>   - overloaded constructor
>
> - Input:
>
> - string containing all date data
>
> - Output:
>
>   - none
>
> - Steps:
>   - loop through line with "/" as delimeter
>   - incoming data is in the following form:
>     - mm/dd/yyyy

> getFullDate()
>
> - Goals:
>
>   - return full date formatted to be written to a file
>
> - Input:
>
>   - none
>
> - Output:
>
>   - string containing formatted full date
>
> - Steps:
>   - create string with full date formatted
>   - return formatted string

main()

> Goals:
>
> - open the file and read from it
> - send the data to student objects
> - write fullReport.txt, shortReport.txt, alphaReport.txt
>
> Input:
>
> - students.dat file containing all student data for each student
>
> Output:
>
> - creates fullReport.txt, shortReport.txt, alphaReport.txt
>
> Steps:
>
> - open students.dat
> - create count and initialize to 0
> - call readStudentData() pass in references to the open students.dat and count
> - close students.dat
>
> - create array of student objects of size [count]
> - call createStudents() pass in students array, stringstream
>
> - create fullReport.txt
> - call writeFullData() pass in students array, reference to fullReport.txt
> - close fullReport.txt
>
> - create shortReport.txt
> - call writeFullName() pass in students array, reference to shortReport.txt
> - close shortReport.txt
>
> - sort students array
>
> - create alphaReport.txt
> - call writeFullName() pass in students array, reference to alphaReport.txt
> - close alphaReport.txt

readStudentData()

> Goals:
>
> - read through student.dat, count the lines and return a string stream
>
> Input:
>
> - reference to the opened students.dat
> - reference to stringstream to hold student data
> - pointer to count variable
>
> Output:
>
> - changes the stringstream containing the data from the file
> - changes the count variable because it was passed in as a pointer
>
> Steps:
>
> - read all data from students.dat into stringstream
> - count number of lines while reading from students.dat

createStudents()

> Goals:
>
> - fill the students array with student objects on the heap
>
> Input:
>
> - students array
> - stringstream with the student data
>
> Output:
>
> - creates student objects on the heap in the students array
>
> Steps:
>
> - loop through array of students
>   - create new student object on the heap
>   - send in each line of the stringstream created from the file

writeFullData()

> Goals:
>
> - fill the students array with student objects on the heap
>
> Input:
>
> - students array
> - reference to fullReport.txt
>
> Output:
>
> - writes to fullReport.txt
>
> Steps:
>
> - loop through array of students
>   - write getFullData() for each student to fullReport.txt

writeFullName()

> Goals:
>
> - fill the students array with student objects on the heap
>
> Input:
>
> - students array
> - reference to shortReport.txt or alphaReport.txt
>
> Output:
>
> - writes to shortReport.txt
>
> Steps:
>
> - loop through array of students
>   - write getFullName() for each student to shortReport.txt or alphaReport.txt
