#include "date.h"
#include <sstream>

Date::Date()
{
  // default constructor
  Date::day = "MISSING DAY";
  Date::month = "MISSING MONTH";
  Date::year = "MISSING YEAR";
}

Date::Date(std::string dateLine)
{
  // dateLine contains all the data for the date object
  std::stringstream ss;
  ss << dateLine;
  std::string data;
  int count = 0;

  while (getline(ss, data, '/'))
  {
    if (count == 0)
    {
      Date::month = data;
    }
    else if (count == 1)
    {
      Date::day = data;
    }
    else if (count == 2)
    {
      Date::year = data;
    }
    count++;
  }
}

std::string Date::getFullDate()
{
  // create and return a formatted date string
  std::string formattedDate = Date::month + "/";
  formattedDate = formattedDate + Date::day + "/";
  formattedDate = formattedDate + Date::year;

  return formattedDate;
}