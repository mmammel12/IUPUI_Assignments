#include <iostream>
#include <algorithm>
#include <string>
#include <sstream>
#include <fstream>
#include "address.h"
#include "date.h"
#include "student.h"

void readStudentData(std::ifstream &, std::stringstream &, int &);
void createStudents(Student *, std::stringstream &);
void writeFullData(Student *, std::ofstream &, int);
void writeFullName(Student *, std::ofstream &, int);

int main()
{
  // open students.dat
  std::ifstream inputFile;
  inputFile.open("students.dat");

  // initialize stringstream to hold all the data from the file
  std::stringstream studentData;
  // initialize count variable to determine size of the students array
  int count = 0;

  // initialize string to hold a line of data from the file
  std::string inputLine;

  // clear first line of the file
  std::getline(inputFile, inputLine);

  // read the data from the file
  readStudentData(inputFile, studentData, count);

  // close the file
  inputFile.close();

  // create array of student objects of size [count]
  Student *students = new Student[count];

  // fill students array
  createStudents(students, studentData);

  // create fullReport.txt
  std::ofstream fullReport("fullReport.txt");
  writeFullData(students, fullReport, count);
  fullReport.close();

  // create shortReport.txt
  std::ofstream shortReport("shortReport.txt");
  writeFullName(students, shortReport, count);
  shortReport.close();

  // sort students array
  //sort(students, count);
  std::sort(students, students + count);

  // sort won't work no matter what I do.
  // it either gives an invalid pointer or seg faults
  // Jake, Gabe, Anna, and Evan have all looked at it
  // I give up.

  // create alphaReport.txt
  std::ofstream alphaReport("alphaReport.txt");
  writeFullName(students, alphaReport, count);
  alphaReport.close();

  delete[] students;

  return (0);
}

void readStudentData(std::ifstream &inputFile, std::stringstream &studentData, int &count)
{
  // initialize string to hold a line of data from the file
  std::string inputLine;

  // read all data from students.dat into stringstream
  // and count number of lines while reading from students.dat
  while (std::getline(inputFile, inputLine))
  {
    studentData << inputLine << std::endl;
    count++;
  }
}

void createStudents(Student *students, std::stringstream &studentData)
{
  std::string studentLine;
  int count = 0;

  while (std::getline(studentData, studentLine))
  {
    std::stringstream studentStream;
    studentStream << studentLine;

    // populate the Student objects in students with data
    students[count].populate(studentStream);

    count++;
  }
}

void writeFullData(Student *students, std::ofstream &fullReport, int count)
{
  for (int i = 0; i < count; i++)
  {
    fullReport << students[i].getFullData() << std::endl;
  }
}

void writeFullName(Student *students, std::ofstream &report, int count)
{
  for (int i = 0; i < count; i++)
  {
    report << students[i].getFullName() << std::endl;
  }
}