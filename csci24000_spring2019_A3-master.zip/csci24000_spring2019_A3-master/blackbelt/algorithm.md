# Blackbelt  

## Marty Mammel
## Algorithm

Goals:
* print out the status of the race
* have each horse "flip a coin" to see if they move forward
* update status of the race
* repeat until a horse reaches the end and wins

Input:
* Random seed from user
* global array to store position of horses

Output:
* status of the race
  
main()  
> Goals:
> * Start program
> 
> Input:
> * None
> 
> Output:
> * None
> 
> Steps:
> * clear console
> * call race() to begin race

race()
> Goals:
> * Loop until the race is complete
> * This is the main game loop
> 
> Input:
> * random seed from user
> 
> Output:
> * horse position array
> 
> Steps:
> * Initialize array to be passed from function to function
> * print "Please enter a random seed: "
> * assign user input to seed variable
> * seed rng
> * setManualOrAuto() to determine manual or auto
> * while (keepGoing) loop
> * print status of race with printRace()
> * if manual run was true, print "Press enter for another turn:" and wait for [enter]
> * if checkForWinner() returns false
> * iterateRace()
> * else if checkForWinner() returns true
> * set keepGoing to False
> * printWinner() to print the winning horse

seedRNG()
> Goals:
> * seed the rng
>
> Input:
> * none
>
> Output:
> * none, seeds the rng but not return value
>
> Steps:
> * initialize seed variable
> * ask user for a random seed
> * assign user input to seed variable
> * pass seed variable to rng seeding function

setManualOrAuto()
> Goals:
> * determine if the program should run automatically or from user input
>
> Input:
> * none
>
> Output:
> * boolean
> * true is auto, false is manual
>
> Steps:
> * print "Do you want the program to run manually? (y/n)"
> * while keepGoing to validate user input
> * if the user input is "y" or "n" (case insensitive) exit the loop
> * if the user input is "y", set return value to true

printRace()
> Goals:
> * print the current location of each horse
> 
> Input:
> * horse position array
> 
> Output:
> * current location of each horse
> 
> Steps:
> * clear console
> * loop through global array
> * loop from 0-14
> * if the current position is the same as the horse position, print horse number
> * else, print "."
> * print a new line after each horse track is printed

checkForWinner()
> Goals:
> * determine if a horse has won
> 
> Input:
> * horse position array
> 
> Output:
> * returns boolean depending on if there is a winner
> 
> Steps:
> * loop through global array
> * if a horse is at position 15
> * return true because a horse has won!

iterateRace()
> Goals:
> * "flip a coin" 
> 
> Input:
> * horse position array
> 
> Output:
> * iterates the value of each horse depending on the coin flip
> 
> Steps:
> * loop through global array
> * generate a random number (0 or 1)
> * if random number is 1, add 1 to the horse position

printWinner()
> Goals:
> * print the winning horse
>
> Input:
> * horse position array
> 
> Output:
> * the winning horse as "Horse # wins!"
>
> Steps:
> * iterate through array
> * if horse position is 15, print "Horse # wins!"
