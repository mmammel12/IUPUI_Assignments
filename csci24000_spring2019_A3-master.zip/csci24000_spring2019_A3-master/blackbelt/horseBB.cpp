#include <iostream>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>

// initialize global array to track position of horses
const int SIZE = 5;

// prototype functions
void race();
bool setManualOrAuto();
void printRace(int*);
bool checkForWinner(int*);
void iterateRace(int*);
void printWinner(int*);

int main() {
	system("clear");
	// begin race!
	race();
	return(0);
}

void race() {
	// initialize horsePositions array
	int horsePositions[SIZE] = {0, 0, 0, 0, 0};

	// get seed for rng
	int seed;

	std::cout << "Please enter a random seed: ";
	std::cin >> seed;
	std::cout << std::endl;
	
	// need this to flush the cin buffer
	std::cin.ignore();

	// seed rng
	srand(seed);

	// determine manual or auto run for the program
	bool manualRun = setManualOrAuto();

	bool keepGoing = true;
	
	while(keepGoing) {
		// print current status of the race
		printRace(horsePositions);
		
		if(manualRun) {
			// user needs to press enter for next turn
			std::cout << "Press enter for another turn: ";
	                std::cin.ignore();
		}
		else {
			// wait for half a second
			usleep(250000);
		}

		// determine if there is a winner
		if(checkForWinner(horsePositions)) {
			// a horse won, end loop and print winner
			keepGoing = false;
			printWinner(horsePositions);
		}
		else {
			// no winner yet, iterate the race one turn
			iterateRace(horsePositions);
		}
	}
}

bool setManualOrAuto() {
	// initialize return variable
	bool manualRun = false;	

	// initialize userInput to hold response
	std::string userInput;

	std::cout << "Do you want the program to run manually? (y/n): ";
	
	// assing user input to userInput
	std::cin >> userInput;

	bool keepGoing = true;
	
	while(keepGoing) {
		// change userInput to uppercase
		userInput = std::toupper(userInput[0]);

		if(userInput == "Y") {
			// manual run, return true
			keepGoing = false;
			manualRun = true;
		}
		else if(userInput == "N") {
			// auto run, return false
			keepGoing = false;
			manualRun = false;
		}
		else {
			std::cout << "Please reply with either 'y' or 'n'\n";
			std::cout << "Do you want the program to run manually? (y/n): ";
			std::cin >> userInput;
		}
	}
	
	return manualRun;
}

void printRace(int* horsePositions) {
	// clear console
	std::cout << std::flush;
	system("clear");	

	// loop through horsePositions array
	for(int i=0; i<SIZE; i++) {
		// loop for each position in the race track
		for(int j=0; j<15; j++) {
			// check if the current horse is in the current position
			if(horsePositions[i] == j) {
				// horse position, print horse number
				std::cout << i;
			}
			else {
				// horse not here, print a period
				std::cout << ".";
			}
		}
		// end line for next horse
		std::cout << std::endl;
	}
}

bool checkForWinner(int* horsePositions) {
	// initialize return boolean as false assuming no winner
	bool winner = false;

	// loop through horsePositions array to check for a winner
	for(int i=0; i<SIZE; i++) {
		// check for a winner
		if(horsePositions[i] == 15) {
			// horse at position 15, we have a winner
			winner = true;
		}
	}

	return winner;
}

void iterateRace(int* horsePositions) {
	// loop through horsePositions array
	for(int i=0; i<SIZE; i++) {
		// rng coin flip
		if(rand()%2 == 1) {
			// coin flip says to move horse ahead, iterate the position of the horse
			horsePositions[i]++;
		}
	}
}

void printWinner(int* horsePositions) {
	// variable for ties
	int numWinners = 0;	

	// TODO refactor out maybe
	// TODO refactor seed function

	// loop through horsePositions array
	for(int i=0; i<SIZE; i++) {
		if(horsePositions[i] == 15) {
			// add one to numWinners
			numWinners++;
		}
	}

	if(numWinners > 1) {
		// there was a tie, print all the winners
		std::cout << "There was a tie!" << std::endl;
		std::cout << "The following horses tied:" << std::endl;
		for(int i=0; i<SIZE; i++) {
			if(horsePositions[i] == 15) {
				std::cout << i << std::endl;
			}
		}
	}
	
}
