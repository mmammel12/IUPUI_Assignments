#include <iostream>
#include <stdlib.h>

// initialize global array to track position of horses
const int SIZE = 5;
int horsePositions[SIZE] = {0, 0, 0, 0, 0};

// prototype functions
void race();
void printRace();
bool checkForWinner();
void iterateRace();
void printWinner();

int main() {
	// begin race!
	race();
	return(0);
}

void race() {
	// get seed for rng
	int seed;

	std::cout << "Please enter a random seed: ";
	std::cin >> seed;
	std::cout << std::endl;
	
	// need this to flush the cin buffer
	std::cin.ignore();

	// seed rng
	srand(seed);

	bool keepGoing = true;
	
	while(keepGoing) {
		// print current status of the race
		printRace();
		
		// user needs to press enter for next turn		
		std::cout << "Press enter for another turn: ";
		std::cin.ignore();

		// determine if there is a winner
		if(checkForWinner()) {
			// a horse won, end loop and print winner
			keepGoing = false;
			printWinner();
		}
		else {
			// no winner yet, iterate the race one turn
			iterateRace();
		}
	}
}

void printRace() {
	// loop through horsePositions array
	for(int i=0; i<SIZE; i++) {
		// loop for each position in the race track
		for(int j=0; j<15; j++) {
			// check if the current horse is in the current position
			if(horsePositions[i] == j) {
				// horse position, print horse number
				std::cout << i;
			}
			else {
				// horse not here, print a period
				std::cout << ".";
			}
		}
		// end line for next horse
		std::cout << std::endl;
	}
}

bool checkForWinner() {
	// initialize return boolean as false assuming no winner
	bool winner = false;

	// loop through horsePositions array to check for a winner
	for(int i=0; i<SIZE; i++) {
		// check for a winner
		if(horsePositions[i] == 15) {
			// horse at position 15, we have a winner
			winner = true;
		}
	}

	return winner;
}

void iterateRace() {
	// loop through horsePositions array
	for(int i=0; i<SIZE; i++) {
		// rng coin flip
		if(rand()%2 == 1) {
			// coin flip says to move horse ahead, iterate the position of the horse
			horsePositions[i]++;
		}
	}
}

void printWinner() {
	// loop through horsePositions array
	for(int i=0; i<SIZE; i++) {
		if(horsePositions[i] == 15) {
			// print which horse won
			std::cout << "Horse " << i << " wins!" << std::endl;
		}
	}
}
