# csci24000_spring2019_A3

## Marty Mammel
## Base Algorithm

### Sample Run
Please enter a random seed: 700  
0........................  
.1.......................  
2........................  
3........................  
.4.......................  
Press enter for another turn:  
0........................  
..1......................  
.2.......................  
.3.......................  
.4.......................  
Press enter for another turn:  
.0.......................  
..1......................  
..2......................  
.3.......................  
.4.......................  
Press enter for another turn:  
.0.......................  
...1.....................  
..2......................  
..3......................  
..4......................  
Press enter for another turn:  
..0......................  
...1.....................  
..2......................  
...3.....................  
..4......................  
Press enter for another turn:  
..0......................  
....1....................  
..2......................  
....3....................  
...4.....................  
Press enter for another turn:  
...0.....................  
.....1...................  
...2.....................  
.....3...................  
....4....................  
   
.  
.  
.  
  
Press enter for another turn:  
.................0.......  
..............1..........  
................2........  
.......................3.  
..............4..........  
Press enter for another turn:  
.................0.......  
..............1..........  
................2........  
........................3  
...............4.........  
Press enter for another turn:  
.................0.......  
...............1.........  
................2........  
.........................  
Horse 3 wins!  
................4........  

### Algorithm

Goals:
* print out the status of the race
* have each horse "flip a coin" to see if they move forward
* update status of the race
* repeat until a horse reaches the end and wins

Input:
* Random seed from user
* global array to store position of horses

Output:
* status of the race
  
main()  
> Goals:
> * Start program
> 
> Input:
> * None
> 
> Output:
> * None
> 
> Steps:
> * call race() to begin race

race()
> Goals:
> * Loop until the race is complete
> * This is the main game loop
> 
> Input:
> * random seed from user
> 
> Output:
> * None
> 
> Steps:
> * print "Please enter a random seed: "
> * assign user input to seed variable
> * seed rng
> * while (keepGoing) loop
> * print status of race with printRace()
> * print "Press enter for another turn:" and wait for [enter]
> * if checkForWinner() returns false
> * iterateRace()
> * else if checkForWinner() returns true
> * set keepGoing to False
> * printWinner() to print the winning horse

printRace()
> Goals:
> * print the current location of each horse
> 
> Input:
> * none, uses global array
> 
> Output:
> * current location of each horse
> 
> Steps:
> * loop through global array
> * loop from 0-14
> * if the current position is the same as the horse position, print horse number
> * else, print "."
> * print a new line after each horse track is printed

checkForWinner()
> Goals:
> * determine if a horse has won
> 
> Input:
> * none, uses global array
> 
> Output:
> * returns boolean depending on if there is a winner
> 
> Steps:
> * loop through global array
> * if a horse is at position 15
> * return true because a horse has won!

iterateRace()
> Goals:
> * "flip a coin" 
> 
> Input:
> * uses global array
> 
> Output:
> * iterates the value of each horse depending on the coin flip
> 
> Steps:
> * loop through global array
> * generate a random number (0 or 1)
> * if random number is 1, add 1 to the horse position

printWinner()
> Goals:
> * print the winning horse
>
> Input:
> * none, uses global array
> 
> Output:
> * the winning horse as "Horse # wins!"
>
> Steps:
> * iterate through array
> * if horse position is 15, print "Horse # wins!"
