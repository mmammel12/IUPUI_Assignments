//bubble.c
//famous bubble sort
//implement the swap algorithm with pointers

#include <stdio.h>
#define MAX 9

//function prototypes
void printValues();
void sort();
void swap(int*, int*);

int values[] = {7, 3, 9, 4, 6, 1, 2, 8, 5};

int main(){
  	printf("Before: \n");
  	printValues();
	sort();
  	printf("After: \n");
  	printValues();

  	return(0);
} // end main

// iterates through values array and prints each element
void printValues() {
	printf("[");
	int i = 0;
	for(i=0; i<MAX; i++) {
		printf("%d ", values[i]);
	}
	printf("]\n");
}

// bubble sort
void sort() {
	int i = 0;
	int j = i+1;	
	
	// nested for loops to check every set of two variables against each other
	for(i=0; i<MAX-1; i++) { // check element
		for(j=i+1; j<MAX; j++) { // current element
			if(values[i] > values[j]) {
				// current element is smaller than check element, swap them
				swap(&values[i], &values[j]);
				printValues();
			}
		}
	}
}

// swap two elements using temp variable
void swap(int* lower, int* higher) {
	int temp = *lower;
	
	*lower = *higher;
	*higher = temp;
}
