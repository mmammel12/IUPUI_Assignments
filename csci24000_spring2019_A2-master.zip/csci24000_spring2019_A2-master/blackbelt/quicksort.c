#include <stdio.h>

#define SIZE 9
#define MIN 1
#define MAX 100

// prototype functions
void generateRandomArray();
void printValues();
void sort(int*, int, int);
int partition(int*, int, int);
void swap(int*, int*);

int values[SIZE];

int main() {
	generateRandomArray();
	printf("Before:\n");
	printValues();
	printf("Sorting:\n");
	sort(values, 0, (SIZE - 1));
	printf("After:\n");
	printValues(0);
}

// fill values array with random numbers 
void generateRandomArray() {
	int i = 0;
	for(i=0; i<SIZE; i++) {
		values[i] = (rand() % (MAX + MIN));
	}
}

// print the elements of values array
void printValues() {
	printf("[ ");
	int i = 0;
	for(i=0; i<SIZE; i++) {
		printf("%d ", values[i]);
	}
	printf("]\n");
}

void sort(int* values, int lower, int higher) {
	if(lower < higher) {
		// set pivot and sort it to correct place
		int pivot = partition(values, lower, higher);
		// sort elements smaller than pivot
		sort(values, lower, pivot - 1);
		// sort elements larger than pivot
		sort(values, pivot + 1, higher);
	}
}

int partition(int* values, int lower, int higher) {
	int pivot = values[higher];
	int i = lower - 1;
	int j = lower;

	for(j=lower; j<=higher-1; j++) {
		if(values[j] <= pivot) {
			// element is smaller than pivot, move it to the left of pivot
			i++;
			swap(&values[i], &values[j]);
			printValues();
		}
	}
	// place pivot in sorted position
	swap(&values[i+1], &values[higher]);
	printValues();

	return (i+1);
}

// swap the values of two elements using a temp variable
void swap(int* first, int* second) {
	int temp = *first;
	*first = *second;
	*second = temp;
}
