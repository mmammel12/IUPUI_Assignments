#include <stdio.h>

#define SIZE 9
#define MIN 1
#define MAX 50

// prototype functions
void generateRandomArray();
void printValues();
void sort();
void swap(int*, int*);

int values[SIZE];

int main() {
        generateRandomArray();
        printf("Before:\n");
        printValues();
        printf("Sorting:\n");
        sort(values, 0, (SIZE - 1));
        printf("After:\n");
        printValues(0);
}

// fill values array with random numbers
void generateRandomArray() {
        int i = 0;
        for(i=0; i<SIZE; i++) {
                values[i] = (rand() % (MAX + MIN));
        }
}

// print the elements of the values array
void printValues() {
        printf("[ ");
        int i = 0;
        for(i=0; i<SIZE; i++) {
                printf("%d ", values[i]);
        }
        printf("]\n");
}

// selection sort
void sort() {
	int current = 0;
	// continue until every element has been checked
	while(current < SIZE) {
		int i = 0;
		// loop through values to compare with current
		for(i=0; i<SIZE; i++) {
			// current is in the wrong place, start swapping
			if(values[i] > values[current]) {
				swap(&values[i], &values[current]);
			}
		}
		current++;
	}
}

// Do I need to explain this one again?
void swap(int* first, int* second) {
	int temp = *first;
	*first = *second;
	*second = temp;
}
