import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
import java.util.Vector;

public class ATM {
  private Vector<User> users;
  private User currentUser;

  public static void main(String[] args) {
    ATM atm = new ATM();

    Scanner scanner = new Scanner(System.in);
    boolean isAdmin = atm.signIn(scanner);

    if (atm.currentUser != null) {
      if (isAdmin) {
        atm.adminMenu(scanner);
      } else {
        atm.userMenu(scanner);
      }
    } else {
      atm.signOut();
    }

    scanner.close();
  } // end main

  public ATM() {
    try {
      FileInputStream inFile = new FileInputStream("users.dat");
      ObjectInputStream inObj = new ObjectInputStream(inFile);

      this.users = (Vector<User>) inObj.readObject();

      inFile.close();
      inObj.close();
    } catch (Exception e) {
      System.out.println("\n\nNo user data found, creating new admin account");
      this.users = new Vector<User>();
      this.createAdmin();
      System.out.println("Admin created");
    }
  } // end constructor

  public void createAdmin() {
    this.users.add(0, new User("00000"));
    this.users.get(0).setPin("12345");
  } // end createAdmin

  public boolean signIn(Scanner scanner) {
    boolean isAdmin = false;
    boolean keepGoing = true;

    while (keepGoing) {
      System.out.println("\n\nPlease enter account number or \"99\" to exit:");
      String account = scanner.nextLine();

      if (account.equals("99")) {
        keepGoing = false;
      } else {
        boolean invalid = true;
        int i = 0;
        while (invalid) {
          if (account.equals(this.users.get(i).getAccount())) {
            System.out.println("Please enter PIN or \"99\" to go back :");
            String pin = scanner.nextLine();

            if (pin.equals("99")) {
              invalid = false;
            } else if (this.users.get(i).checkPin(pin)) {
              invalid = false;
              keepGoing = false;

              this.currentUser = this.users.get(i);
            }
          } else if (i == this.users.size()) {
            invalid = false;
            System.out.println("Error: User does not exist");
          } else {
            i++;
          }

          if (i >= this.users.size()) {
            // user not found exit loops
            System.out.println("\nUser not found\n");
            keepGoing = false;
            invalid = false;
          }
        } // end invalid
      }
    } // end keepGoing

    if (this.currentUser != null) {
      if (this.currentUser.getAccount().equals("00000")) {
        isAdmin = true;
      }
    }

    return isAdmin;
  } // end signIn

  public void signOut() {
    this.currentUser = null;

    System.out.println("\nSaving Data");

    try {
      // create output streams
      FileOutputStream outFile = new FileOutputStream("users.dat");
      ObjectOutputStream outObj = new ObjectOutputStream(outFile);

      // write users vector to users.dat
      outObj.writeObject(this.users);

      // close streams
      outObj.close();
      outFile.close();

      System.out.println("\nData saved\n");
    } catch (IOException e) {
      System.out.println("Error: something went wrong when saving the data");
      System.out.println("Error message:\n" + e);
      System.out.println();
    }
  } // end signOut

  public void userMenu(Scanner scanner) {
    boolean keepGoing = true;

    String menu = "\nUser " + this.currentUser.getAccount();
    menu += "\n\n1) View Checking Balance";
    menu += "\n2) Deposit into Checking";
    menu += "\n3) Withdraw from Checking\n";
    menu += "\n4) View Savings Balance";
    menu += "\n5) Deposit into Savings";
    menu += "\n6) Withdraw from Savings\n";
    menu += "\n0) Exit\n";
    menu += "\nWhat would you like to do?";

    while (keepGoing) {
      System.out.println(menu);
      String response = scanner.nextLine();

      if (response.equals("0")) {
        // exit
        this.signOut();
        keepGoing = false;
      } else if (response.equals("1")) {
        // view checking balance
        String currentBal = String.format("$%.2f", currentUser.checkingBal());
        System.out.println("Current Checking balance: " + currentBal);
      } else if (response.equals("2")) {
        // deposit into checking
        this.checkingDeposit(scanner);
      } else if (response.equals("3")) {
        // withdraw from checking
        this.checkingWithdraw(scanner);
      } else if (response.equals("4")) {
        // view savings balance
        String currentBal = String.format("$%.2f", currentUser.savingsBal());
        System.out.println("Current Savings balance: " + currentBal);
      } else if (response.equals("5")) {
        // deposit into savings
        this.savingsDeposit(scanner);
      } else if (response.equals("6")) {
        // withdraw from savings
        this.savingsWithdraw(scanner);
      } else {
        System.out.println("Invalid input\n");
      }
    } // end keepGoing
  } // end userMenu

  public void adminMenu(Scanner scanner) {
    boolean keepGoing = true;

    String menu = "\nUser " + this.currentUser.getAccount();
    menu += "\n\n1) Add new user";
    menu += "\n2) Delete user";
    menu += "\n3) List all users";
    menu += "\n4) Apply interest\n";
    menu += "\n0) Exit\n";
    menu += "\nWhat would you like to do?";

    while (keepGoing) {
      System.out.println(menu);

      String response = scanner.nextLine();

      if (response.equals("0")) {
        // exit
        this.signOut();
        keepGoing = false;
      } else if (response.equals("1")) {
        // add new user
        this.createUser(scanner);
      } else if (response.equals("2")) {
        // delete user
        this.deleteUser(scanner);
      } else if (response.equals("3")) {
        // list all users
        this.listUsers();
      } else if (response.equals("4")) {
        // apply interest
        this.applyInterest(scanner);
      } else {
        System.out.println("Invalid input\n");
      }
    } // end keepGoing
  } // end adminMenu

  public void checkingDeposit(Scanner scanner) {
    // get user input
    String currentBal = String.format("$%.2f", currentUser.checkingBal());
    System.out.println("Current checking balance: " + currentBal);
    System.out.println("How much would you like to deposit?");
    float amount = scanner.nextFloat();

    // pass amount to user's checkingDeposit
    currentUser.checkingDeposit(amount);
  } // end checkingDeposit

  public void checkingWithdraw(Scanner scanner) {
    // get user input
    String currentBal = String.format("$%.2f", currentUser.checkingBal());
    System.out.println("Current checking balance: " + currentBal);
    System.out.println("How much would you like to withdraw?");
    float amount = scanner.nextFloat();

    // pass amount to user's checkingWithdraw
    currentUser.checkingWithdraw(amount);
  } // end checkingWithdraw

  public void savingsDeposit(Scanner scanner) {
    // get user input
    String currentBal = String.format("$%.2f", currentUser.savingsBal());
    System.out.println("Current savings balance: " + currentBal);
    System.out.println("How much would you like to deposit?");
    float amount = scanner.nextFloat();

    // pass amount to user's checkingWithdraw
    currentUser.savingsDeposit(amount);
  } // end savingsDeposit

  public void savingsWithdraw(Scanner scanner) {
    // get user input
    String currentBal = String.format("$%.2f", currentUser.savingsBal());
    System.out.println("Current checking balance: " + currentBal);
    System.out.println("How much would you like to withdraw?");
    float amount = scanner.nextFloat();

    // pass amount to user's checkingWithdraw
    currentUser.savingsWithdraw(amount);
  } // end savingsWithdraw

  public void createUser(Scanner scanner) {
    // assign account number
    int userIndex = this.users.size();
    String account = String.format("%05d", userIndex);

    System.out.println("Creating a new user with account number: " + account);
    this.users.add(new User(account));
    this.users.get(userIndex).setPin(scanner);
  } // end createUser

  public void deleteUser(Scanner scanner) {
    boolean found = false;
    // get user input
    System.out.println("Enter the account number of the user to be deleted");
    String account = scanner.nextLine();

    for (int i = 1; i < this.users.size(); i++) {
      if (this.users.get(i).getAccount().equals(account)) {
        found = true;
        if (this.users.get(i).checkingBal() == 0) {
          if (this.users.get(i).savingsBal() == 0) {
            this.users.remove(i);
            System.out.println("User " + account + "Successfully deleted");
          } else {
            System.out.println("Error: User account not empty, deletion aborted.");
          }
        } else {
          System.out.println("Error: User account not empty, deletion aborted.");
        }
      }
    }

    if (!found) {
      System.out.println("Error: User " + account + " not found.");
    }
  } // end deleteUser

  public void listUsers() {
    System.out.println("There are a total of " + (this.users.size() - 1) + " users.");
    for (int i = 1; i < this.users.size(); i++) {
      // starts at 1 because admin account is in position 0
      System.out.println(i + ": " + this.users.get(i).getAccount());
    } // end for loop
  } // end listUsers

  public void applyInterest(Scanner scanner) {
    // get number of months
    System.out.println("How many months of interest would you like to apply?");
    float months = scanner.nextFloat();

    // apply to all accounts
    for (int i = 1; i < this.users.size(); i++) {
      // starts at 1 because admin account is in position 0
      this.users.get(i).savingsApplyInterest(months);
    } // end for loop

    System.out.println("Interest has been applied to all users");
  } // end applyInterest
} // end class