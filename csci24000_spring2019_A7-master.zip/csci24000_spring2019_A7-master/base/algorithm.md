# Bank on it Algorithm

## Marty Mammel

## ATM

Goals:

> ATM has the menus and allows access to user accounts and admin functionality

Input:

> Pulls in serialized user data
> Gets user input

Output:

> Writes serialized user data
> Interacts with User object

Properties:

> Users array

Methods:

#### ATM()

Goals:

> constructor

Steps:

> none

Output:

> none returned, initializes Users array

Steps:

> initialize Users array

#### main(String[] args)

Goals:

> allow the user to sign in and call correct menu

Input:

> none

Output:

> none

Steps:

> pull in serialized User data
> if no User data exists, call createAdmin()
> call signIn() and assing return boolean to isAdmin
> if isAdmin is true, call adminMenu()
> else call userMenu()

#### createAdmin()

Goals:

> create an admin account, only runs if no accounts exist yet

Input:

> none

Output:

> none returned, creates admin account and adds it to Users array

Steps:

> create new User with account number 00000 and pin 12345

#### signIn()

Goals:

> Allow a user to sign in, check account number and pin

Input:

> none passed in, gets input from the user (account # and pin)

Output:

> returns boolean, true if account # is 00000 (and login success)

Steps:

> ask user for account number
> verify account number is valid
> ask user for pin
> validate pin through User's checkPin(String)
> if account number and pin are valid, set currentUser

#### signOut()

Goals:

> Allow a user to sign out

Input:

> none

Output:

> none

Steps:

> set currentUser to null
> write data to file

#### userMenu()

Goals:

> print user menu and get menu action from user

Input:

> none passed in, gets user input

Output:

> none returned, prints to console

Steps:

> while keepGoing loop
>
> - print:
>
>   - User [account num]
>   -
>   - 1\) View Checking Balance
>   - 2\) Deposit into Checking
>   - 3\) Withdraw from Checking
>   -
>   - 4\) View Savings Balance
>   - 5\) Deposit into Savings
>   - 6\) Withdraw from Savings
>   -
>   - 0\) Exit
>   -
>   - What would you like to do?
>
> - get user input
> - if user input is "0", set keepGoing to false
> - else if "1", call User's checkingBal()
> - else if "2", call User's checkingDeposit()
> - "3" call User's checkingWithdraw()
> - "4" call User's savingsBal()
> - "5" call User's savingsDeposit()
> - "6" call User's savingsWithdraw()
>
> call signOut()

#### adminMenu()

Goals:

> print admin menu and get menu action from user

Input:

> none passed in, gets user input

Output:

> none returned, prints to console

Steps:

> while keepGoing loop
>
> - print:
>
>   - User [account num]
>   -
>   - 1\) Add new User
>   - 2\) Delete User
>   - 3\) List All Users
>   - 4\) Apply Interest
>   -
>   - 0\) Exit
>   -
>   - What would you like to do?
>
> - get user input
> - if user input is "0", set keepGoing to false
> - else if "1", call createUser()
> - else if "2", call deleteUser()
> - "3" call User's listUsers()
> - "4" call User's applyInterest()
>
> call signOut()

#### createUser()

Goals:

> create a new User

Input:

> none passed in, gets user input

Output:

> none returned, creates new User object in Users array

Steps:

> assign account number based on index in Users array
>
> note: "efficiency through complete disregard for user security"
> call User's setPin() to set pin
> ask user if they want to add money to checking and/or savings
> call appropriate deposit methods

#### deleteUser()

Goals:

> delete a user

Input:

> none passed in

Output:

> none returned, deletes a User object in Users array

Steps:

> ask which account number to delete
> make sure User to be deleted has no money in Checking or Savings
> if they do have money, do not allow deletion
> if no money, delete the User from the array

#### listUsers()

Goals:

> list all the users

Input:

> none passed in, uses Users array

Output:

> none returned, prints to console

Steps:

> loop through Users array
>
> - print each User account number

#### applyInterest()

Goals:

> apply interest to all of the Users

Input:

> none passed in, gets user input

Output:

> none returned
> passes number of months to savingsApplyInterest(float) for each User

Steps:

> ask for how many month worth of interest to apply
> validate input
> loop through Users array
>
> - pass months value to each User's savingsApplyInterest(float)

## User

Goals:

> User object to contain information about the user and the user's accounts
> implement Serializable for serialization of data

Input:

> String passed in for the account number
> pin is set shortly after through setPin(String)
> balances for Checking and Savings passed in through methods as well

Output:

> information about the properties

Properties:

> account: String
> pin: String
> checking: Checking object
> savings: Savings object

Methods:

#### User(String)

Goals:

> constructor

Input:

> String containing account number

Output:

> none returned
> sets account number and creates Checking and Savings objects

Steps:

> initialize and assign account with String passed in
> create Checking object
> create Savings object
> both checking and savings will start with \$0 in the account

#### main(String[] args)

Goals:

> main function to be used for testing purposes

Input:

> none

Output:

> no return value
> creates a User for testing

Steps:

> create new User object
> initialize and set properties
> test each method to make sure it is working as intended

#### getAccount()

Goals:

> return the account number

Input:

> none

Output:

> account number as a String

Steps:

> return account

#### setPin()

Goals:

> pin setter

Input:

> none

Output:

> none

Steps:

> ask user what they want their pin to be
> validate pin is exactly 5 characters long and all numbers
> set pin

#### checkPin(String)

Goals:

> determine if the user entered the correct pin

Input:

> String with pin

Output:

> boolean depending on if the pin passed in matches the User object pin

Steps:

> compare pin passed in to User object pin, return result

#### checkingDeposit()

Goals:

> allow the user to deposit money to their checking

Input:

> none passed in
> gets input from user

Output:

> none returned
> prints to the console

Steps:

> ask user how much they would like to deposit
> validate the number, needs to be positive float
> call Checking deposit(float)
> print "Deposit successful"
> print "Your new balance is " + checkingBal() to get current balance

#### checkingWithdraw()

Goals:

> withdraw from the checking account

Input:

> none passed in
> gets user input

Output:

> none returned
> prints to the console

Steps:

> ask the user how much they would like to withdraw
> validate the number, needs to be positive float and less than current balance
> call Checking withdraw(float)
> print "Your money flies out of the ATM and a goes straight into a sewer drain"
> print "That sucks for you"

#### checkingBal()

Goals:

> return the current balance of the checking account

Input:

> none

Output:

> float of the current balance

Steps:

> return the Checking balance from Checking getBalance()

#### savingsDeposit()

Goals:

> allow the user to deposit money to their checking

Input:

> none passed in
> gets input from user

Output:

> none returned

Steps:

> ask user how much they would like to deposit
> validate the number, needs to be positive float
> call Savings deposit(float)
> print "Deposit successful"
> print "Your new balance is " + savingsBal() to get current balance

#### savingsWithdraw()

Goals:

> withdraw from the checking account

Input:

> none passed in
> gets user input

Output:

> none returned
> prints to the console

Steps:

> ask the user how much they would like to withdraw
> validate the number, needs to be positive float and less than current balance
> call Savings withdraw(float)
> print "Your money comes out but it's all stickey and gross"
> print "That sucks for you"

#### savingsBal()

Goals:

> return the current balance of the savings account

Input:

> none

Output:

> float of the current balance

Steps:

> return the Savings balance through Savings getBalance()

#### savingsApplyInterest(float)

Goals:

> apply interest to the savings account

Input:

> float months containing number of months to apply interest for

Output:

> none

Steps:

> validate months is positive
> call Savings applyInterest(float)

## Checking

Goals:

> checking account object
> each user has one

Properties:

> balance: float

Methods:

#### Checking()

Goals:

> constructor

Input:

> none

Output:

> none

Steps:

> initialize and set balance to 0.0

#### main(String[] args)

Goals:

> main method for testing purposes

Input:

> none

Output:

> none returned
> writes to console

Steps:

> create Checking object
> run each method to test them
> print output for each test

#### deposit(float)

Goals:

> deposit money into the account

Input:

> float value containing how much money is being deposited

Output:

> none

Steps:

> validate value is positive
> add value to balance

#### withdraw(float)

Goals:

> withdraw money from the account

Input:

> float value containing how much is going to be withdrawn

Output:

> none

Steps:

> validate value is positive and less than balance
> subtract value from balance

#### getBalance()

Goals:

> getter for balance

Input:

> none

Output:

> float balance

Steps:

> return balance

## Savings

Goals:

> savings account object, inherits from checking
> each user has one

Properties:

> balance: float inherited from Checking
> interestRate: float

Methods:

#### Savings()

Goals:

> constructor

Input:

> none

Output:

> none

Steps:

> call parent constructor
> initialize and set interestRate to 0.01

#### main(String[] args)

Goals:

> main method for testing purposes

Input:

> none

Output:

> none returned
> writes to console

Steps:

> create Savings object
> run each method to test them
> print output for each test

#### deposit(float)

inherits from Checking

#### withdraw(float)

inherits from Checking

#### getBalance()

inherits from Checking

#### applyInterest(float)

Goals:

> apply interest to the savings account

Input:

> float months for time period

Output:

> none

Steps:

> validate months is positive
> set balance to = current balance \* (1 + interestRate\*months)
