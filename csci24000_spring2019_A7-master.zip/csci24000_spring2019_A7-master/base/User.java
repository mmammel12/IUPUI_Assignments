import java.io.Serializable;
import java.util.InputMismatchException;
import java.util.Scanner;

public class User implements Serializable {
  private static final long serialVersionUID = 1L;
  private String account;
  private String pin;
  private Checking checking;
  private Savings savings;

  public static void main(String[] args) {
    User user = new User("12345");

    Scanner scanner = new Scanner(System.in);

    // set the pin
    user.setPin(scanner);

    // test pin 12345, should return true
    System.out.println("12345: " + user.checkPin("12345"));

    // test pin 11111, should return false
    System.out.println("11111: " + user.checkPin("11111"));

    // test getAccount, should return 12345
    System.out.println("get Account: " + user.getAccount());

    // test checkingDeposit
    user.checkingDeposit(123.45f);

    // test checkingWithdraw
    user.checkingWithdraw(100.34f);

    // test savingsDeposit
    user.savingsDeposit(123.45f);

    // test savingsWithdraw
    user.savingsWithdraw(100.34f);

    // test savingsApplyInterest
    user.savingsApplyInterest(12.0f);

    // test invalid savingsApplyInterest
    user.savingsApplyInterest(-12.0f);
  } // end main

  public User(String act) {
    this.account = act;
    this.checking = new Checking();
    this.savings = new Savings();
    this.pin = "12345";
  } // end constructor

  public String getAccount() {
    return this.account;
  }

  public void setPin(Scanner scanner) {
    boolean keepGoing = true;

    while (keepGoing) {
      // get pin from user

      System.out.println("Please set your pin:");
      String userPin = scanner.nextLine();

      // validate pin
      if (userPin.length() == 5) {
        this.pin = userPin;
        keepGoing = false;
      } else {
        System.out.println("Error: PIN must be exactly 5 digits\n");
      }
    } // end keepGoing
  } // end setPin

  public void setPin(String pin) {
    if (pin.length() == 5) {
      this.pin = pin;
    } else {
      System.out.println("Error: PIN must be exactly 5 digits\n");
    }
  }

  public boolean checkPin(String userPin) {
    return this.pin.equals(userPin);
  }

  public void checkingDeposit(float amount) {
    if (amount > 0) {
      checking.deposit(amount);
      System.out.println("Deposit successful");
      String currentBal = String.format("$%.2f", checking.getBalance());
      System.out.println("Your new balance is $" + currentBal);
    } else {
      System.out.println("Error: Deposit must be a positive number");
    }
  } // end checkingDeposit

  public void checkingWithdraw(float amount) {
    if (amount > 0) {
      if (amount <= checking.getBalance()) {
        checking.withdraw(amount);
        System.out.println("Your money flies out of the ATM and goes straight into a sewer drain.");
        System.out.println("That sucks for you.");
        String currentBal = String.format("$%.2f", checking.getBalance());
        System.out.println("New balance: $" + currentBal);
      } else {
        System.out.println("Error: Cannot withdraw more than current balance");
      }
    } else {
      System.out.println("Error: Withdrawal must be a positive number");
    }
  } // end chekingWithdraw

  public float checkingBal() {
    return checking.getBalance();
  } // end checkingBal

  public void savingsDeposit(float amount) {
    if (amount > 0) {
      savings.deposit(amount);
      System.out.println("Deposit successful");
      String currentBal = String.format("$%.2f", savings.getBalance());
      System.out.println("Your new balance is $" + currentBal);
    } else {
      System.out.println("Error: Deposit must be a positive number");
    }
  } // end savingsDeposit

  public void savingsWithdraw(float amount) {
    if (amount > 0) {
      if (amount <= savings.getBalance()) {
        savings.withdraw(amount);
        System.out.println("Your money flies out of the ATM and goes straight into a sewer drain.");
        System.out.println("That sucks for you.");
        String currentBal = String.format("$%.2f", savings.getBalance());
        System.out.println("New balance: $" + currentBal);
      } else {
        System.out.println("Error: Cannot withdraw more than current balance");
      }
    } else {
      System.out.println("Error: Withdrawal must be a positive number");
    }
  } // end savingsWithdraw

  public float savingsBal() {
    return savings.getBalance();
  } // end savingsBal

  public void savingsApplyInterest(float months) {
    if (months > 0) {
      savings.applyInterest(months);
    } else {
      System.out.println("Error: Months must be a positive number");
    }
  } // end savingsApplyInterest
} // end class