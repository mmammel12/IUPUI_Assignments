import java.io.Serializable;

public class Savings extends Checking implements Serializable {
  private static final long serialVersionUID = 1L;
  private float interestRate;

  public static void main(String[] args) {
    Savings savings = new Savings();

    // check starting balance is 0.0
    System.out.println("Starting balance: " + savings.getBalance());

    // deposit a test amount
    float value = 175.83f;
    savings.deposit(value);

    // check new balance after deposit
    // should be "Deposit 1 Balance: 175.83"
    System.out.println("Deposit 1 balance: " + savings.getBalance());

    // try to deposit a negative value
    value = -5.83f;
    savings.deposit(value);

    // check new balance after deposit
    // should be "Deposit 2 Balance: 175.83"
    System.out.println("Deposit 2 balance: " + savings.getBalance());

    // withdraw test amount
    value = 5.41f;
    savings.withdraw(value);

    // check new balance after withdraw
    // should be "Withdraw 1 Balance: 170.42"
    System.out.println("Withdraw 1 Balance: " + savings.getBalance());

    // try to withdraw a negative
    value = -5.41f;
    savings.withdraw(value);

    // check new balance after withdraw
    // should be "Withdraw 2 Balance: 170.42"
    System.out.println("Withdraw 2 Balance: " + savings.getBalance());

    // apply interest to the account
    float months = 12.0f;
    savings.applyInterest(months);

    // check new balance after interest is applied
    // should be "Interest 1 Balance: 190.87"
    System.out.println("Interest 1 Balance: " + savings.getBalance());

    // try to apply interest with negative months
    months = -12.0f;
    savings.applyInterest(months);

    // check new balance after interest is applied
    // should be "Interest 2 Balance: 190.87"
    System.out.println("Interest 2 Balance: " + savings.getBalance());
  } // end main

  public Savings() {
    super();
    this.interestRate = 0.01f;
  } // end constructor

  public void applyInterest(float months) {
    if (months > 0) {
      this.balance = this.balance * (1 + this.interestRate * months);
    }
  } // end applyInterest
} // end class