import java.io.Serializable;

public class Checking implements Serializable {
  private static final long serialVersionUID = 1L;
  protected float balance;

  public static void main(String[] args) {
    Checking checking = new Checking();

    // check starting balance is 0.0
    System.out.println("Starting balance: " + checking.getBalance());

    // deposit a test amount
    float value = 175.83f;
    checking.deposit(value);

    // check new balance after deposit
    // should be "Deposit 1 Balance: 175.83"
    System.out.println("Deposit 1 balance: " + checking.getBalance());

    // try to deposit a negative value
    value = -5.83f;
    checking.deposit(value);

    // check new balance after deposit
    // should be "Deposit 2 Balance: 175.83"
    System.out.println("Deposit 2 balance: " + checking.getBalance());

    // withdraw test amount
    value = 5.41f;
    checking.withdraw(value);

    // check new balance after withdraw
    // should be "Withdraw 1 Balance: 170.42"
    System.out.println("Withdraw 1 Balance: " + checking.getBalance());

    // try to withdraw a negative
    value = -5.41f;
    checking.withdraw(value);

    // check new balance after withdraw
    // should be "Withdraw 2 Balance: 170.42"
    System.out.println("Withdraw 2 Balance: " + checking.getBalance());
  } // end main

  public Checking() {
    this.balance = 0.0f;
  } // end constructor

  public void deposit(float value) {
    if (value > 0) {
      this.balance += value;
    }
  } // end deposit

  public void withdraw(float value) {
    if (value > 0) {
      if (value <= this.balance) {
        this.balance -= value;
      }
    }
  } // end withdraw

  public float getBalance() {
    return this.balance;
  } // end getBalance
} // end class