#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define NUM_PHILOSOPHERS 5
#define MAX_WAIT 5

pthread_mutex_t mutex;
pthread_cond_t cond[NUM_PHILOSOPHERS];

enum
{
    READY,
    IN_USE
} chopsticks[NUM_PHILOSOPHERS];

int philosophers[NUM_PHILOSOPHERS];

void pickup(int i)
{
    // lock mutex for critical section
    pthread_mutex_lock(&mutex);

    // while left or right chopstick is being used
    // spin
    while (chopsticks[(i + NUM_PHILOSOPHERS - 1) % NUM_PHILOSOPHERS] == IN_USE ||
           chopsticks[(i + 1) % NUM_PHILOSOPHERS] == IN_USE)
    {
        pthread_cond_wait(&cond[i], &mutex);
    }
    // not spinning
    // set chopsticks to in use
    chopsticks[(i + NUM_PHILOSOPHERS - 1) % NUM_PHILOSOPHERS] = IN_USE;
    chopsticks[(i + 1) % NUM_PHILOSOPHERS] = IN_USE;

    printf("Philosopher %d is eating\n", i);

    // unlock mutex, critical section done
    pthread_mutex_unlock(&mutex);
}

void putdown(int i)
{
    // lock mutex for critical section
    pthread_mutex_lock(&mutex);
    
    // set chopsticks to ready
    chopsticks[(i + NUM_PHILOSOPHERS - 1) % NUM_PHILOSOPHERS] = READY;
    chopsticks[(i + 1) % NUM_PHILOSOPHERS] = READY;
    
    printf("Philosopher %d is thinking\n", i);

    // unlock mutex, critical section done
    pthread_mutex_unlock(&mutex);
}

void* dine(void *ptr)
{
    int i = *(int *)ptr;
    // make the philosophers run forever
    // they are going to get fat
    while (1)
    {
        pickup(i);

        putdown(i);

        // thinking time
        sleep(rand() % (3) + 1);
    }
}

int main(int argc, char *argv[])
{
    // define thread identifier, one for each philosopher
    pthread_t threads[NUM_PHILOSOPHERS];
    
    // define thread attributes
    pthread_attr_t attrs[NUM_PHILOSOPHERS];

    // initialize mutex
    pthread_mutex_init(&mutex, NULL);

    // initialize philosophers and chopsticks
    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        philosophers[i] = i;
        chopsticks[i] = READY;
    }

    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        // initialize thread attribute
        pthread_attr_init(&attrs[i]);

        // initiaize conditions
        pthread_cond_init(&cond[i], NULL);

        // create thread to execute dine
        pthread_create(&threads[i], &attrs[i], dine, &philosophers[i]);
    }

    // join threads (even though this will run indefinitely)
    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
    {
        pthread_join(threads[i], NULL);
    }
    

    return 0;
}
