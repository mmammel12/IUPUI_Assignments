#include "Parser/Parser.h"

int main(int argc, char const *argv[])
{
  Parser parser;

  parser.run();

  return 0;
}