// $Id: Array.cpp 827 2011-02-07 14:20:53Z hillj $

// Author: Marty Mammel
// Last Modification: 9/16/2019
// Array template class without the use of the std library

// Honor Pledge:
//
// I pledge that I have neither given nor receieved any help
// on this assignment.

#include <stdexcept>

//
// Array
//
template <typename T>
Array<T>::Array(void)
    : Array_Base<T>()
{
}

//
// Array (size_t)
//
template <typename T>
Array<T>::Array(size_t length)
    : Array_Base<T>(length)
{
}

//
// Array (size_t, T)
//
template <typename T>
Array<T>::Array(size_t length, T fill)
    : Array_Base<T>(length, fill)
{
}

//
// Array (const Array &)
//
template <typename T>
Array<T>::Array(const Array<T> &array)
    : Array_Base<T>(array)
{
}

//
// ~Array
//
template <typename T>
Array<T>::~Array(void)
{
  if (this->data_ != nullptr)
  {
    delete[] this->data_;
    this->data_ = nullptr;
  }
}

//
// resize
//
template <typename T>
void Array<T>::resize(size_t new_size)
{
  // if the array is being truncated
  if (this->cur_size_ > new_size)
  {
    this->truncate(new_size);
  }
  // if the array is being expanded
  else if (this->cur_size_ < new_size)
  {
    // if max_size_ does not need to increase
    if (this->max_size_ > new_size)
    {
      this->cur_size_ = new_size;
    }
    // if max_size_ also needs to be increased
    else
    {
      this->expand(new_size);
    }
  }
}

template <typename T>
void Array<T>::shrink(void)
{
  // create temp_data to be the size of cur_size_
  char *temp_data = new char[this->cur_size_];
  // fill temp_data with the contents of data_
  for (int i = 0; i < this->cur_size_; i++)
  {
    temp_data[i] = this->data_[i];
  }
  // delete original data_ and assign temp_data to it
  delete[] this->data_;
  this->data_ = nullptr;
  this->data_ = temp_data;
  // change max_size_ to reflect change
  this->max_size_ = this->cur_size_;
}

//
// slice
//
template <typename T>
Array<T> Array<T>::slice(size_t begin) const
{
  // if begin is valid
  if (begin >= 0 && begin < this->cur_size_)
  {
    // get size of the new array
    size_t newSize = this->cur_size_ - begin;
    // create new array then fill
    Array newArr = Array(newSize);
    for (int i = 0; i < newSize; i++)
    {
      newArr.set(i, this->data_[i + begin]);
    }
    return newArr;
  }
  else
  {
    throw std::out_of_range("begin must be within the bounds of the array");
  }
}

//
// slice
//
template <typename T>
Array<T> Array<T>::slice(size_t begin, size_t end) const
{
  // if begin is valid
  if (begin >= 0 && begin < this->cur_size_)
  {
    // if end is valid
    if (end > begin && end <= this->cur_size_)
    {
      // get size of the new array
      size_t newSize = end - begin;
      // create new array then fill
      Array<T> newArr = Array<T>(newSize);
      for (int i = 0; i < newSize; i++)
      {
        newArr.set((i), this->data_[i + begin]);
      }
      return newArr;
    }
    else
    {
      throw std::out_of_range("end must be within the bounds of the array and larger than begin");
    }
  }
  else
  {
    throw std::out_of_range("begin must be within the bounds of the array");
  }
}

//
// truncate
//
template <typename T>
void Array<T>::truncate(size_t new_size)
{
  // create temp_data to store new memory location and fill with original data_
  T *temp_data = new T[this->max_size_];
  for (int i = 0; i < new_size; i++)
  {
    temp_data[i] = this->data_[i];
  }
  // delete original data_ pointer and assign new data to it
  delete[] this->data_;
  this->data_ = nullptr;
  this->data_ = temp_data;
  // update size properties to reflect change
  this->cur_size_ = new_size;
  this->max_size_ = new_size;
}

//
// expand
//
template <typename T>
void Array<T>::expand(size_t new_size)
{
  // create temp_data to store new memory location and fill with original data_
  T *temp_data = new T[new_size];
  for (int i = 0; i < this->cur_size_; i++)
  {
    temp_data[i] = this->data_[i];
  }
  // delete original data_ pointer and assign temp_data to it
  delete[] this->data_;
  this->data_ = nullptr;
  this->data_ = temp_data;
  // change max_size_ to reflect change
  this->max_size_ = new_size;
}
