#ifndef COMMAND_EXISTS
#define COMMAND_EXISTS

#include "../Assignment2/Stack.h"

class Command
{
public:
  virtual int execute(Stack<int> &postfix) = 0;
};

#endif