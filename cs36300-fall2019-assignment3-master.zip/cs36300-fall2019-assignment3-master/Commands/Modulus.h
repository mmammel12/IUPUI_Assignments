#ifndef MODULUS_EXISTS
#define MODULUS_EXISTS

#include "Binary.h"

class Modulus : public Binary
{
public:
  Modulus() = default;

  ~Modulus() = default;

  int evaluate(int n1, int n2) const;
};

#endif