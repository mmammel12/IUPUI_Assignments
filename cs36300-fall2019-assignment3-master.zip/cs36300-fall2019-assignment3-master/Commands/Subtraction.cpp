#include "Subtraction.h"

int Subtraction::evaluate(int n1, int n2) const
{
  return n2 - n1;
}