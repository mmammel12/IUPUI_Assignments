#include "Binary.h"
#include "Number.h"

int Binary::execute(Stack<int> &postfix)
{
  int n1 = postfix.top();
  postfix.pop();

  int n2 = postfix.top();
  postfix.pop();

  int result = this->evaluate(n1, n2);

  return result;
}