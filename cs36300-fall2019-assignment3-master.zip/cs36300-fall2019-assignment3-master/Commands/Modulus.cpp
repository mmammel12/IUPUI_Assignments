#include "Modulus.h"

int Modulus::evaluate(int n1, int n2) const
{
  //COMMENT: Your code will break on mod by 0.
  //REPLY: forgot about that, fixed.
  if (n1 == 0)
  {
    throw std::overflow_error("Error: Modulus by 0");
  }

  return n2 % n1;
}