#ifndef MULTIPLICATION_EXISTS
#define MULTIPLICATION_EXISTS

#include "Binary.h"

class Multiplication : public Binary
{
public:
  Multiplication() = default;

  ~Multiplication() = default;

  int evaluate(int n1, int n2) const;
};

#endif