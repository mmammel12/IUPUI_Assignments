#include "Number.h"

Number::Number(int num)
    : num_(num)
{
}

int Number::execute(Stack<int> &postfix)
{
  return num_;
}

void Number::setNumber(int num)
{
  num_ = num;
}

int Number::getNumber()
{
  return num_;
}