#ifndef BINARY_EXISTS
#define BINARY_EXISTS

#include "../Assignment2/Stack.h"
#include "Command.h"
#include "Number.h"

class Binary : public Command
{
public:
  Binary() = default;

  ~Binary() = default;

  int execute(Stack<int> &postfix);

  virtual int evaluate(int n1, int n2) const = 0;
};

#endif