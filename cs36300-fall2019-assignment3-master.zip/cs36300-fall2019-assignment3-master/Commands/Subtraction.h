#ifndef SUBTRACTION_EXISTS
#define SUBTRACTION_EXISTS

#include "Binary.h"

class Subtraction : public Binary
{
public:
  Subtraction() = default;

  ~Subtraction() = default;

  int evaluate(int n1, int n2) const;
};

#endif