#ifndef ADDITION_EXISTS
#define ADDITION_EXISTS

#include "Binary.h"

class Addition : public Binary
{
public:
  Addition() = default;

  ~Addition() = default;

  int evaluate(int n1, int n2) const;
};

#endif