#ifndef DIVISION_EXISTS
#define DIVISION_EXISTS

#include "Binary.h"

class Division : public Binary
{
public:
  Division() = default;

  ~Division() = default;

  int evaluate(int n1, int n2) const;
};

#endif