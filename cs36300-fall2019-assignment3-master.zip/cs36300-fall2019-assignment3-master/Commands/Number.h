#ifndef NUMBER_EXISTS
#define NUMBER_EXISTS

#include "Command.h"

#include <string>

class Number : public Command
{
public:
  Number(int num);

  ~Number() = default;

  int execute(Stack<int> &postfix);

  void setNumber(int num);

  int getNumber();

private:
  Number() = delete;

  int num_;
};

#endif