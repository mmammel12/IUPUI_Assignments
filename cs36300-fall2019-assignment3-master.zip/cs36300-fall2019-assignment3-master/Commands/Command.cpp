#include "Command.h"

//COMMENT: This is an interface and therefore doesn't have any implemenation.
//Why do you have a .cpp file then?
//REPLY: it won't compile if I do not have this file. I am not sure why.