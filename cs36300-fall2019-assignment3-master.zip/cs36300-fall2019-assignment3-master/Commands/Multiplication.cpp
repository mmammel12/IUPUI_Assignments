#include "Multiplication.h"

int Multiplication::evaluate(int n1, int n2) const
{
  return n2 * n1;
}