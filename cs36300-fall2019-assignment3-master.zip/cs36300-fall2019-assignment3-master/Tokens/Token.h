#ifndef TOKEN_EXISTS
#define TOKEN_EXISTS

#include <string>

class Token
{
public:
  Token();

  Token(std::string token);

  ~Token() = default;

  void setToken(std::string token);

  std::string getToken();

  int getPriority();

private:
  std::string token_;
  int priority_;

  void setPriority();
};

#endif