#include <sstream>
#include <iostream>
#include <stdexcept>

#include "Parser.h"
#include "../Commands/Command.h"
#include "../Assignment2/empty_exception.h"

#define NUMBER -1
#define PARENTHESIS 0
#define ADD_SUB 1
#define MULT_DIV_MOD 2

void Parser::run()
{
  // get infix from user
  std::string infix;
  while (infix != "QUIT")
  {
    std::getline(std::cin, infix);

    try
    {
      if (infix != "QUIT")
      {
        // make sure length is at least 5, the minimum required to have a full expression
        if (infix.length() >= 5)
        {
          Stack<std::shared_ptr<Command>> postfix;
          Stack_Command_Factory factory;

          infix_to_postfix(infix, postfix, factory);

          int result = evaluate_postfix(postfix);

          std::cout << result << std::endl;
        }
        else
        {
          throw std::invalid_argument("Error: Invalid equation");
        }
      }
    }
    catch (const empty_exception &e)
    {
      std::cout << "Error: Invalid expression." << std::endl;
    }
    catch (const std::exception &e)
    {
      std::cout << e.what() << std::endl;
    }
  }
}

void Parser::infix_to_postfix(const std::string &infix,
                              Stack<std::shared_ptr<Command>> &postfix,
                              Stack_Command_Factory &factory)
{
  bool firstToken = true;

  std::istringstream input(infix);
  std::string token;

  Stack<Token> temp;

  Token prevToken;

  while (!input.eof())
  {
    input >> token;

    Token newToken(token);

    // check if the first token is an operator
    if (firstToken)
    {
      if (newToken.getPriority() == ADD_SUB || newToken.getPriority() == MULT_DIV_MOD)
      {
        throw std::invalid_argument("Error: Expression cannot start with an operator.");
      }
      else if (newToken.getToken() == ")")
      {
        throw std::invalid_argument("Error: Expression cannot start with ')'");
      }

      prevToken.setToken(token);

      firstToken = false;
    }
    // else not first token, make sure not repeating operator/operand
    else
    {
      if (newToken.getPriority() == ADD_SUB || newToken.getPriority() == MULT_DIV_MOD)
      {
        if (prevToken.getPriority() == ADD_SUB || prevToken.getPriority() == MULT_DIV_MOD)
        {
          throw std::invalid_argument("Error: Cannot have multiple operators in a row.");
        }
      }
      else if (newToken.getPriority() == NUMBER)
      {
        if (prevToken.getPriority() == NUMBER)
        {
          throw std::invalid_argument("Error: Cannot have multiple numbers in a row.");
        }
      }

      prevToken.setToken(token);
    }

    // if token is a number
    if (newToken.getPriority() == NUMBER)
    {
      // check if token is a number
      if (is_number(token))
      {
        std::stringstream ss(token);

        int num;
        ss >> num;

        postfix.push(factory.create_number_command(num));

        ss.clear();
      }
      else
      {
        throw std::invalid_argument("Error: Only integers and {+,-,*,/,%,(,)} allowed.");
      }
    }
    // else token is an operator
    else
    {
      // if temp is not empty
      if (!temp.is_empty())
      {
        // if token is not a parenthesis
        if (newToken.getPriority() > PARENTHESIS)
        {
          // if token priority is greater than priority of temp.top()
          // push token to temp
          if (newToken.getPriority() > temp.top().getPriority())
          {
            temp.push(Token(token));
          }
          // else if token priority is <= to priority of temp.top()
          // loop and push commands from temp to postfix until not true
          else if (newToken.getPriority() <= temp.top().getPriority())
          {
            while (!temp.is_empty() && newToken.getPriority() <= temp.top().getPriority())
            {
              postfix.push(determine_command(temp.top(), factory));
              temp.pop();
            }
            temp.push(Token(token));
          }
        }
        // if the token is a parenthesis, determine open or close
        else if (newToken.getPriority() == PARENTHESIS)
        {
          // if it is open, push to temp
          if (newToken.getToken() == "(")
          {
            temp.push(Token(token));
          }
          // else if it is close, pop temp and push command to
          // postfix until open is found
          else
          {
            while (temp.top().getToken() != "(")
            {
              postfix.push(determine_command(temp.top(), factory));
              temp.pop();

              if (temp.is_empty())
              {
                throw std::invalid_argument("Error: ')' found without matching '('");
              }
            }
            temp.pop();
          }
        }
      }
      // else temp is empty, push operator Token onto temp stack
      else
      {
        temp.push(Token(token));
      }
    }
  }

  while (!temp.is_empty())
  {
    if (temp.top().getPriority() == PARENTHESIS)
    {
      temp.pop();
    }
    else
    {
      postfix.push(determine_command(temp.top(), factory));
      temp.pop();
    }
  }
}

std::shared_ptr<Command> Parser::determine_command(Token token, Stack_Command_Factory factory)
{
  std::shared_ptr<Command> command;

  if (token.getToken() == "+")
  {
    command = factory.create_addition_command();
  }
  else if (token.getToken() == "-")
  {
    command = factory.create_subtraction_command();
  }
  else if (token.getToken() == "*")
  {
    command = factory.create_multiplication_command();
  }
  else if (token.getToken() == "/")
  {
    command = factory.create_division_command();
  }
  else if (token.getToken() == "%")
  {
    command = factory.create_modulus_command();
  }

  return command;
}

int Parser::evaluate_postfix(Stack<std::shared_ptr<Command>> &postfix)
{
  // reverse postfix to evaluate
  Stack<std::shared_ptr<Command>> reverse_postfix;
  while (!postfix.is_empty())
  {
    reverse_postfix.push(postfix.top());
    postfix.pop();
  }

  Stack<int> working_stack;

  while (!reverse_postfix.is_empty())
  {
    working_stack.push(reverse_postfix.top()->execute(working_stack));
    reverse_postfix.pop();
  }

  return working_stack.top();
}

bool Parser::is_number(const std::string &token)
{
  bool is_num = true;

  const char *cToken = token.c_str();

  for (int i = 0; i < token.length(); i++)
  {
    // if char is not a digit, check if it is negative sign
    if (!isdigit(cToken[i]))
    {
      // if char is a negative sign, check it is element 0
      if (cToken[i] == '-')
      {
        // if negative sign is not element 0, set is_num to false
        if (i != 0)
        {
          is_num = false;
          break;
        }
      }
      // else char is not a number
      else
      {
        is_num = false;
        break;
      }
    }
  }

  return is_num;
}