#ifndef PARSER_EXISTS
#define PARSER_EXISTS

#include <string>
#include <memory>

#include "../Factories/Stack_Command_Factory.h"
#include "../Tokens/Token.h"

class Parser
{
public:
  Parser() = default;

  ~Parser() = default;

  void run();

  void infix_to_postfix(const std::string &infix,
                        Stack<std::shared_ptr<Command>> &postfix,
                        Stack_Command_Factory &factory);

  std::shared_ptr<Command> determine_command(Token token, Stack_Command_Factory factory);

private:
  int evaluate_postfix(Stack<std::shared_ptr<Command>> &postfix);

  bool is_number(const std::string &token);
};

#endif