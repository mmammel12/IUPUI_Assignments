#ifndef COMMAND_FACTORY_EXISTS
#define COMMAND_FACTORY_EXISTS

#include <memory>

#include "../Commands/Number.h"
#include "../Commands/Addition.h"
#include "../Commands/Subtraction.h"
#include "../Commands/Multiplication.h"
#include "../Commands/Division.h"
#include "../Commands/Modulus.h"

class Command_Factory
{
public:
  virtual std::shared_ptr<Command> create_number_command(int num) = 0;

  virtual std::shared_ptr<Command> create_addition_command() = 0;

  virtual std::shared_ptr<Command> create_subtraction_command() = 0;

  virtual std::shared_ptr<Command> create_multiplication_command() = 0;

  virtual std::shared_ptr<Command> create_division_command() = 0;

  virtual std::shared_ptr<Command> create_modulus_command() = 0;
};

#endif