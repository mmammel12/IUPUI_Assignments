#include "Stack_Command_Factory.h"

std::shared_ptr<Command> Stack_Command_Factory::create_number_command(int num)
{
  return std::shared_ptr<Command>(new Number(num));
}

std::shared_ptr<Command> Stack_Command_Factory::create_addition_command()
{
  return std::shared_ptr<Command>(new Addition());
}

std::shared_ptr<Command> Stack_Command_Factory::create_subtraction_command()
{
  return std::shared_ptr<Command>(new Subtraction());
}

std::shared_ptr<Command> Stack_Command_Factory::create_multiplication_command()
{
  return std::shared_ptr<Command>(new Multiplication());
}

std::shared_ptr<Command> Stack_Command_Factory::create_division_command()
{
  return std::shared_ptr<Command>(new Division());
}

std::shared_ptr<Command> Stack_Command_Factory::create_modulus_command()
{
  return std::shared_ptr<Command>(new Modulus());
}