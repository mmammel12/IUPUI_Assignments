#ifndef STACK_COMMAND_FACTORY_EXISTS
#define STACK_COMMAND_FACTORY_EXISTS

#include <memory>

#include "../Assignment2/Stack.h"
#include "Command_Factory.h"

class Stack_Command_Factory : public Command_Factory
{
public:
  Stack_Command_Factory() = default;

  ~Stack_Command_Factory() = default;

  std::shared_ptr<Command> create_number_command(int num);

  std::shared_ptr<Command> create_addition_command();

  std::shared_ptr<Command> create_subtraction_command();

  std::shared_ptr<Command> create_multiplication_command();

  std::shared_ptr<Command> create_division_command();

  std::shared_ptr<Command> create_modulus_command();
};

#endif