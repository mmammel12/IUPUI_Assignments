#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <signal.h>
#include <string.h>

#define GRID_SIZE 9

typedef struct
{
  int *isValid;
  char nums[GRID_SIZE];
} threadData;

void *validate(void *arg)
{
  threadData *data = (threadData *)arg;
  int isValid = 1;

  int found[GRID_SIZE] = {0};
  int i;

  for (i = 0; i < GRID_SIZE; i++)
  {
    char numChar = data->nums[i];
    int num = atoi(&numChar);

    if (found[num - 1] == 0)
    {
      found[num - 1] = 1;
    }
    else
    {
      isValid = 0;
      break;
    }
  }

  *data->isValid = isValid;

  pthread_exit(0);
}

int createSubgrids(char rows[GRID_SIZE][GRID_SIZE], char (*subgrid)[GRID_SIZE])
{
  int rowIndex = 0;
  int colIndex = 0;
  for (int i = 0; i < GRID_SIZE; i += 3)
  {
    for (int j = 0; j < GRID_SIZE; j += 3)
    {
      for (int row = i; row < i + 3; row++)
      {
        for (int col = j; col < j + 3; col++)
        {
          subgrid[rowIndex][colIndex] = rows[row][col];
          colIndex++;
        }
      }
      colIndex = 0;
      rowIndex++;
    }
  }

  return 0;
}

void copyArray(char *lhs, char *rhs)
{
  for (int i = 0; i < GRID_SIZE; i++)
  {
    lhs[i] = rhs[i];
  }
}

int main()
{
  FILE *input = fopen("input.txt", "r");

  if (input == NULL)
  {
    printf("\nError opening file. Make sure input file is named input.txt\n");
  }
  else
  {
    int valid[GRID_SIZE * 3] = {0};
    char line[GRID_SIZE * 2];
    char rows[GRID_SIZE][GRID_SIZE];
    int i = 0;
    int j;
    while (fgets(line, GRID_SIZE * 2, input))
    {
      if (line[0] != '\n')
      {
        j = 0;
        char *token = strtok(line, ",\n");
        while (token)
        {
          rows[i][j] = *token;
          token = strtok(NULL, ",");
          j++;
        }
        i++;
      }
    }

    pthread_t workers[GRID_SIZE * 3];
    pthread_attr_t attrs[GRID_SIZE * 3];

    threadData data[GRID_SIZE * 3];

    for (i = 0; i < GRID_SIZE * 2; i++)
    {
      pthread_attr_init(&attrs[i]);
      data[i].isValid = &valid[i];

      if (i < GRID_SIZE)
      {
        // check rows
        copyArray(data[i].nums, rows[i]);
        pthread_create(&workers[i], &attrs[i], validate, &data[i]);
      }
      else
      {
        // check columns
        char col[GRID_SIZE];
        for (j = 0; j < GRID_SIZE; j++)
        {
          col[j] = rows[j][i - GRID_SIZE];
        }

        copyArray(data[i].nums, col);
        pthread_create(&workers[i], &attrs[i], validate, &data[i]);
      }
    }

    char subgrid[GRID_SIZE][GRID_SIZE];
    createSubgrids(rows, subgrid);

    for (i = 0; i < GRID_SIZE; i++)
    {
      int index = i + GRID_SIZE * 2;
      data[index].isValid = &valid[index];
      copyArray(data[index].nums, subgrid[i]);
      pthread_attr_init(&attrs[index]);
      pthread_create(&workers[index], &attrs[index], validate, &data[index]);
    }

    int invalid = 0;
    for (i = 0; i < GRID_SIZE * 3; i++)
    {
      pthread_join(workers[i], NULL);
    }

    for (i = 0; i < GRID_SIZE * 3; i++)
    {
      if (valid[i] == 0)
      {
        // invalid area
        invalid = 1;
        break;
      }
    }

    if (invalid == 1)
    {
      printf("Invalid Grid\n");
    }
    else
    {
      printf("Valid Grid\n");
    }
  }

  return 0;
}
