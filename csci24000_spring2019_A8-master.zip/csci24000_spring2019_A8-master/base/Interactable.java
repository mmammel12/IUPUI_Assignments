interface Interactable {
  public void pet();

  public void feed();

  public void sleep();

  public void makeNoise();
}