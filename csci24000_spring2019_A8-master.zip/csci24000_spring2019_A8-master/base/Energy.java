import java.util.Vector;

class Energy extends Pettribute {
  private static final long serialVersionUID = 1L;

  Vector<String> values;
  int currentValue;

  public static void main(String[] args) {
    // main stuff
  } // end main

  public Energy() {
    this.values = new Vector<String>();
    this.values.add("asleep");
    this.values.add("tired");
    this.values.add("neutral");
    this.values.add("awake");
    this.values.add("energetic");
    this.currentValue = 2;
  } // end constructor

  public String getValue() {
    return values.get(this.currentValue);
  } // end getValue

  public void setValue(int num) {
    if (num == -1) {
      if (this.currentValue + num >= 0) {
        this.currentValue += num;
      } else {
        System.out.println("Cannot be more tired than asleep");
      } // end if else
    } else if (num == 1) {
      if (this.currentValue + num < this.values.size()) {
        this.currentValue += num;
      } else {
        System.out.println("Cannot be more awake than energetic");
      } // end if else
    } // end if else
  } // end setValue
} // end class