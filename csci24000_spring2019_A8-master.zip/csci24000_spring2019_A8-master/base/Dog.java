import java.util.Random;

class Dog extends Pet implements Interactable {
  private static final long serialVersionUID = 1L;

  final boolean goodDog = true;
  final String[] genders = { "MALE", "FEMALE" };

  final String[] breeds = { "MINPIN", "TERRIER", "DACHSHUND", "RETRIEVER", "SHEPERD", "HOUND", "LABRADOR", "DOBERMANN",
      "LEONBERGER", "GREYHOUND", "SCHNAUZER", "PEKINGESE", "POMSKY", "XOLOITZCUINTLE", "MUDI", "PUG", "HOKKAIDO",
      "TOSA", "MASTIFF", "AZAWAKH", "OTTERHOUND", "KOI", "OTTER", "SEAL", "LLAMA_WITH_HAT", "SALMON" };

  String gender;
  String breed;

  public static void main(String[] args) {
    // main stuff
  } // end main

  public Dog(String name) {
    this.setGender();
    this.setBreed();
    this.name = name;
    this.age = 1;
    this.happiness = new Happiness();
    this.hunger = new Hunger();
    this.energy = new Energy();
    this.sound = "bark";
    this.awake = true;
    this.pettable = true;
  }

  // setters
  private void setGender() {
    Random rand = new Random();
    int num = rand.nextInt(genders.length);
    this.gender = genders[num];
  } // end setGender

  private void setBreed() {
    Random rand = new Random();
    int num = rand.nextInt(breeds.length);
    this.breed = breeds[num];
  } // end setBreed

  public void setHappiness(int num) {
    if (num == -1 || num == 1) {
      this.happiness.setValue(num);
    } else {
      System.out.println("Error: happiness can only be changed by 1");
    } // end if else
  } // end setHappiness

  public void setHunger(int num) {
    if (num == -1 || num == 1) {
      this.hunger.setValue(num);
    } else {
      System.out.println("Error: hunger can only be changed by 1");
    } // end if else
  } // end setHunger

  public void setEnergy(int num) {
    if (num == -1 || num == 1) {
      this.energy.setValue(num);
    } else {
      System.out.println("Error: energy can only be changed by 1");
    } // end if else
    if (this.getEnergy().equals("asleep")) {
      this.awake = false;
    } else {
      this.awake = true;
    } // end if else
  } // end setEnergy

  public void setName(String name) {
    this.name = name;
  } // end setName

  public void setSound(String sound) {
    this.sound = sound;
  } // end setSound

  public void setAwake(boolean awake) {
    this.awake = awake;
  }

  public void setPettable(boolean pettable) {
    if (pettable) {
      this.pettable = pettable;
    } else {
      System.out.println("Error: These are good dogs, they are pettable");
      this.pettable = true;
    } // end if else
  } // end setPettable

  public void setAge(int age) {
    if (age > 0) {
      this.age += age;
    } // end if
  } // end setAge

  // getters
  public String isGoodDog() {
    String output = "";
    if (this.goodDog) {
      output = "Yes, " + this.name + " is a good dog.";
    } else {
      output = "Somehow you tried to make " + this.name + " not be a good dog.\n";
      output = this.name + " is a good dog.";
    } // end if else
    return output;
  } // end isGoodDog

  public int getDogYears() {
    return this.age * 7;
  } // end getDogYears

  public String getBreed() {
    return this.breed;
  } // end getBreed

  public String getGender() {
    return this.gender;
  } // end getGender

  // other methods
  public void playFetch() {
    System.out.println("You play fetch with the dog. " + this.name + " is very good at fetch");
    this.setHunger(-1);
    this.setHappiness(1);
    this.setEnergy(-1);
  } // end playFetch

  // Interactable methods
  public void feed() {
    System.out.println("You feed the dog. " + this.name + " wags their tail happily");
    this.setHunger(1);
    this.setHappiness(1);
    this.setEnergy(1);
  } // end feed

  public void pet() {
    System.out.println("You pet the dog. " + this.name + " wags their tail happily");
    this.setHappiness(1);
    this.setEnergy(1);
  } // end pet

  public void sleep() {
    System.out.println(this.name + " takes a nap.");
    this.setHappiness(1);
    this.setEnergy(1);
  } // end sleep

  public void makeNoise() {
    System.out.println(this.sound);
    this.setHappiness(1);
    this.setEnergy(1);
  } // end makeNoise
} // end class