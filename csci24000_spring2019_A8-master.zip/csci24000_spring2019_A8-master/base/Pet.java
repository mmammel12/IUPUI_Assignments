import java.io.Serializable;

abstract class Pet implements Serializable {
  private static final long serialVersionUID = 1L;

  Happiness happiness;
  Hunger hunger;
  Energy energy;
  String name;
  String sound;
  boolean awake;
  boolean pettable;
  int age;

  // setters
  public abstract void setHappiness(int num);

  public abstract void setHunger(int num);

  public abstract void setEnergy(int num);

  public abstract void setName(String name);

  public abstract void setSound(String sound);

  public abstract void setAwake(boolean awake);

  public abstract void setPettable(boolean pettable);

  public abstract void setAge(int age);

  // getters
  public String getHappiness() {
    return this.happiness.getValue();
  }

  public String getHunger() {
    return this.hunger.getValue();
  }

  public String getEnergy() {
    return this.energy.getValue();
  }

  public String getName() {
    return this.name;
  }

  public String getSound() {
    return this.sound;
  }

  public boolean isAwake() {
    return this.awake;
  }

  public boolean isPettable() {
    return this.pettable;
  }

  public int getAge() {
    return this.age;
  }

} // end class