import java.io.Serializable;
import java.util.Vector;

abstract class Pettribute implements Serializable {
  private static final long serialVersionUID = 1L;

  Vector<String> values;
  int currentValue;

  public abstract String getValue();

  public abstract void setValue(int num);
}