import java.util.Vector;

class Happiness extends Pettribute {
  private static final long serialVersionUID = 1L;

  Vector<String> values;
  int currentValue;

  public static void main(String[] args) {
    // main stuff
  } // end main

  public Happiness() {
    this.values = new Vector<String>();
    this.values.add("sad");
    this.values.add("upset");
    this.values.add("neutral");
    this.values.add("happy");
    this.values.add("ecstatic");
    this.currentValue = 2;
  } // end constructor

  public String getValue() {
    return values.get(this.currentValue);
  } // end getValue

  public void setValue(int num) {
    if (num == -1) {
      if (this.currentValue + num >= 0) {
        this.currentValue += num;
      } else {
        System.out.println("Cannot be more sad than sad");
      } // end if else
    } else if (num == 1) {
      if (this.currentValue + num < this.values.size()) {
        this.currentValue += num;
      } else {
        System.out.println("Cannot be happier than ecstatic");
      } // end if else
    } // end if else
  } // end setValue
} // end class