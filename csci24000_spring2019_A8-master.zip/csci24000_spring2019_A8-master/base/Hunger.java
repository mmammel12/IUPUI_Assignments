import java.util.Vector;

class Hunger extends Pettribute {
  private static final long serialVersionUID = 1L;

  Vector<String> values;
  int currentValue;

  public static void main(String[] args) {
    // main stuff
  } // end main

  public Hunger() {
    this.values = new Vector<String>();
    this.values.add("starving");
    this.values.add("hungry");
    this.values.add("neutral");
    this.values.add("content");
    this.values.add("stuffed");
    this.currentValue = 2;
  } // end constructor

  public String getValue() {
    return values.get(this.currentValue);
  } // end getValue

  public void setValue(int num) {
    if (num == -1) {
      if (this.currentValue + num >= 0) {
        this.currentValue += num;
      } else {
        System.out.println("Cannot be more hungry than starving");
      } // end if else
    } else if (num == 1) {
      if (this.currentValue + num < this.values.size()) {
        this.currentValue += num;
      } else {
        System.out.println("Cannot be less hungry than stuffed");
      } // end if else
    } // end if else
  } // end setValue
} // end class