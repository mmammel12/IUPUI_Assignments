import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
import java.util.Vector;

class Menu {
  Vector<Dog> dogs;
  Dog currentDog;

  public static void main(String[] args) {
    Menu menu = new Menu();

    menu.defaultMenu();
    menu.storeData();
  } // end main

  public Menu() {
    try {
      FileInputStream inFile = new FileInputStream("dogs.dat");
      ObjectInputStream inObj = new ObjectInputStream(inFile);

      this.dogs = (Vector<Dog>) inObj.readObject();

      inObj.close();
      inFile.close();
    } catch (Exception e) {
      System.out.println("\nNo previous dog data found.\nCreating new Dog");
      this.dogs = new Vector<Dog>();
      this.createDog();
    } // end try catch
  } // end constructor

  public void defaultMenu() {
    Scanner scanner = new Scanner(System.in);
    boolean keepGoing = true;
    while (keepGoing) {
      this.displayDefaultMenu();
      String selection = scanner.nextLine();

      if (selection.equals("1")) {
        this.listDogs();
      } else if (selection.equals("2")) {
        this.createDog();
      } else if (selection.equals("3")) {
        this.selectDog();
        if (this.currentDog != null) {
          this.dogMenu();
        } // end if
      } else if (selection.equals("0")) {
        keepGoing = false;
        System.out.println("\nThanks for playing with the dogs!");
      } else {
        System.out.println("\nError: Please select only 1,2,3, or 0");
      } // end if else
    } // end while
  } // end defualtMenu

  public void displayDefaultMenu() {
    String defaultMenu = "\n1) List all dogs";
    defaultMenu += "\n2) Create a dog";
    defaultMenu += "\n3) Select a dog";
    defaultMenu += "\n\n0) exit";
    defaultMenu += "\n\nEnter selection:";

    System.out.println(defaultMenu);
  } // end displayDefaultMenu

  public void dogMenu() {
    this.displayDogMenu();
    Scanner scanner = new Scanner(System.in);
    boolean keepGoing = true;
    while(keepGoing) {
      this.displayDogMenu();
      String selection = scanner.nextLine();

      if (selection.equals("1")) {
        System.out.println("\nWhat would you like the new name to be?");
        String name = scanner.nextLine();

        currentDog.setName(name);
      } else if (selection.equals("2")) {
        currentDog.playFetch();
      } else if (selection.equals("3")) {
        currentDog.feed();
      } else if (selection.equals("4")) {
        currentDog.sleep();
      } else if (selection.equals("5")) {
        currentDog.makeNoise();
      } else if (selection.equals("6")) {
        System.out.println("\nWhat would you like the sound to be?");
        String sound = scanner.nextLine();

        currentDog.setSound(sound);
      } else if (selection.equals("7")) {
        System.out.println(this.getInfo());
      } else if (selection.equals("0")) {
        keepGoing = false;
        this.currentDog = null;
      } else {
        System.out.println("\nError: Please select only 1,2,3,4,5,6,7, or 0");
      }
    } // end while
  } // end dogMenu

  public void displayDogMenu() {
    String dogMenu = "\n1) Rename dog";
    dogMenu += "\n2) Play fetch";
    dogMenu += "\n3) Feed";
    dogMenu += "\n4) Sleepy time";
    dogMenu += "\n5) Speak";
    dogMenu += "\n6) Change sound";
    dogMenu += "\n7) Check all info";
    dogMenu += "\n\n0) exit";

    System.out.println(dogMenu);
  } // end displayDogMenu

  public void storeData() {
    for (int i = 0; i < dogs.size(); i++) {
      dogs.get(i).setHappiness(-1);
      dogs.get(i).setHunger(-1);
      dogs.get(i).setEnergy(-1);
      dogs.get(i).setAge(1);
    } // end for

    try {
      System.out.println("Saving Dog Data");
      FileOutputStream outFile = new FileOutputStream("dogs.dat");
      ObjectOutputStream outObj = new ObjectOutputStream(outFile);

      outObj.writeObject(this.dogs);

      outObj.close();
      outFile.close();

      System.out.println("Dog Data Saved");
    } catch (Exception e) {
      System.out.println("Something went wrong saving the dog data");
      System.out.println(e.getMessage());
    } // end try catch
  } // end storeData

  public void createDog() {
    Scanner scanner = new Scanner(System.in);
    System.out.println("What would you like to name this dog?");
    String name = scanner.nextLine();
    dogs.add(new Dog(name));
  } // end createDog

  public void listDogs() {
    System.out.println();
    System.out.println("Here are all of the dogs:");
    for (int i = 0; i < dogs.size(); i++) {
      String dogName = dogs.get(i).getName();
      System.out.println(i + ": " + dogName);
    } // end for
  } // end listDogs

  public void selectDog() {
    Scanner scanner = new Scanner(System.in);
    boolean keepGoing = true;
    while (keepGoing) {
      this.listDogs();
      System.out.println("\nPlease enter the number of the dog you would like to interact with:");
      try {
        int choice = scanner.nextInt();
        if (choice >= 0) {
          if (choice < this.dogs.size()) {
            this.currentDog = this.dogs.get(choice);
            keepGoing = false;
          } else {
            System.out.println("Error: that dog does not exist");
          } // end if else
        } else {
          System.out.println("Error: that dog does not exist");
        } // end if else
      } catch (Exception e) {
        System.out.println("Error: Please enter a valid input");
      } // end try catch
    } // end while
  } // end selectDog

  public String getInfo() {
    String output = "Name: " + currentDog.getName();
    output += "\nBreed: " + currentDog.getBreed();
    output += "\nGender: " + currentDog.getGender();
    output += "\nAwake: " + currentDog.isAwake();
    output += "\nPettable: " + currentDog.isPettable();
    output += "\nGood Dog: " + currentDog.isGoodDog();
    output += "\nSound: " + currentDog.getSound();
    output += "\nAge: " + currentDog.getAge();
    output += "\nAge in dog years: " + currentDog.getDogYears();
    output += "\nHappiness: " + currentDog.getHappiness();
    output += "\nHunger: " + currentDog.getHunger();
    output += "\nEnergy: " + currentDog.getEnergy() + "\n";
    return output;
  } // end getInfo
} // end class