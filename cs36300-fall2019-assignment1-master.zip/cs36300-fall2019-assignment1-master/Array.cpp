// $Id: Array.cpp 820 2011-01-17 15:30:41Z hillj $

// Author: Marty Mammel
// Last Modification: 9/11/2019
// Array class using none of the std library

// Honor Pledge:
//
// I pledge that I have neither given nor receieved any help
// on this assignment.

#include "Array.h"
#include <stdexcept>

#define DEFAULT_SIZE 100
#define MAX_ALLOWED_SIZE 500000

//COMMENT: I suggest you put each member variable on its own line in the BMI list.
//This will help with debugging.
//REPLY: Done.
Array::Array(void)
: cur_size_(0),
  max_size_(DEFAULT_SIZE),
  data_(new char[DEFAULT_SIZE])
{
}

//COMMENT: I suggest you put each member variable on its own line in the BMI list.
//This will help with debugging.
//REPLY: Done.
Array::Array(size_t length)
: cur_size_(0),
  max_size_(length)
{
  // if length is valid
  if (length > 0 && length <= MAX_ALLOWED_SIZE)
  {
    Array::data_ = new char[Array::max_size_];
  }
  // length is invalid
  else
  {
    //COMMENT: Constructors should not throw excpetions. Users usually want
    //the objects to be created before they start getting exceptions thrown.
    //REPLY: Done. Now sets max_size_ to be DEFAULT_SIZE and initializes data_ to that size as well
    Array::max_size_ = DEFAULT_SIZE;
    Array::data_ = new char[DEFAULT_SIZE];
  }
}

//COMMENT: I suggest you put each member variable on its own line in the BMI list.
//This will help with debugging.
//REPLY: Done.
Array::Array(size_t length, char fill)
: cur_size_(length),
  max_size_(length)
{
  // if length is valid
  if (length > 0 && length <= MAX_ALLOWED_SIZE)
  {
    Array::data_ = new char[Array::max_size_];
  }
  // length is invalid
  else
  {
    //COMMENT: Constructors should not throw excpetions. Users usually want
    //the objects to be created before they start getting exceptions thrown.
    //REPLY: Done. Now sets max_size_ and cur_size_ to be DEFAULT_SIZE and initializes data_ to that size as well
    Array::cur_size_ = DEFAULT_SIZE;
    Array::max_size_ = DEFAULT_SIZE;
    Array::data_ = new char[DEFAULT_SIZE];
  }
  // fill array with fill char
  for (int i = 0; i < Array::max_size_; i++)
  {
    Array::data_[i] = fill;
  }
}

//COMMENT: I suggest you put each member variable on its own line in the BMI list.
//This will help with debugging.
//REPLY: Done.
Array::Array(const Array &arr)
: cur_size_(arr.cur_size_),
  max_size_(arr.max_size_)
{
  // create new char array and fill with values from arr.data_
  Array::data_ = new char[Array::max_size_];
  for (int i = 0; i < Array::cur_size_; i++)
  {
    Array::data_[i] = arr.data_[i];
  }
}

Array::~Array(void)
{
  delete[] Array::data_;
  Array::data_ = nullptr;
}

const Array &Array::operator=(const Array &rhs)
{
  // delete original pointer
  delete[] Array::data_;
  Array::data_ = nullptr;
  // create new pointer and copy contents of rhs into it
  Array::data_ = new char[rhs.max_size_];
  for (int i = 0; i < rhs.cur_size_; i++)
  {
    Array::data_[i] = rhs.data_[i];
  }
  // change size properties to refelct change
  Array::cur_size_ = rhs.cur_size_;
  Array::max_size_ = rhs.max_size_;
}

char &Array::operator[](size_t index)
{
  // if index is not within the bounds of the array
  if (index >= Array::cur_size_ || index < 0)
  {
    throw std::out_of_range("Invalid index");
  }
  return Array::data_[index];
}

const char &Array::operator[](size_t index) const
{
  // if index is not within the bounds of the array
  if (index >= Array::cur_size_ || index < 0)
  {
    throw std::out_of_range("Invalid index");
  }
  return Array::data_[index];
}

char Array::get(size_t index) const
{
  // if index is not within the bounds of the array
  if (index >= Array::cur_size_ || index < 0)
  {
    throw std::out_of_range("Invalid index");
  }
  return Array::data_[index];
}

void Array::set(size_t index, char value)
{
  // if index is not within the bounds of the array
  if (index >= Array::max_size_ || index < 0)
  {
    throw std::out_of_range("Invalid index");
  }
  // else if cur_size_ needs to increase
  else if (index >= Array::cur_size_)
  {
    Array::cur_size_ = index + 1;
  }
  Array::data_[index] = value;
}

void Array::resize(size_t new_size)
{
  // if the array is being truncated
  if (Array::cur_size_ > new_size)
  {
    Array::truncate(new_size);
  }
  // if the array is being expanded
  else if (Array::cur_size_ < new_size)
  {
    // if max_size_ does not need to increase
    if (Array::max_size_ > new_size)
    {
      Array::cur_size_ = new_size;
    }
    // if max_size_ also needs to be increased
    else
    {
      Array::expand(new_size);
    }
  }
}

void Array::shrink(void)
{
  // create temp_data to be the size of cur_size_
  char *temp_data = new char[Array::cur_size_];
  // fill temp_data with the contents of data_
  for (int i = 0; i < Array::cur_size_; i++)
  {
    temp_data[i] = Array::data_[i];
  }
  // delete original data_ and assign temp_data to it
  delete[] Array::data_;
  Array::data_ = nullptr;
  Array::data_ = temp_data;
  // change max_size_ to reflect change
  Array::max_size_ = Array::cur_size_;
}

int Array::find(char ch) const
{
  // loop through array to find character
  for (int i = 0; i < Array::cur_size_; i++)
  {
    if (Array::data_[i] == ch)
    {
      return i;
    }
  }
  return -1;
}

int Array::find(char ch, size_t start) const
{
  // if start is within the bounds of the array
  if (start >= 0 && start < Array::cur_size_)
  {
    // loop through array to find character
    for (int i = start; i < Array::cur_size_; i++)
    {
      if (Array::data_[i] == ch)
      {
        return i;
      }
    }
    return -1;
  }
  else
  {
    throw std::out_of_range("start must be within the bounds of the array");
  }
}

bool Array::operator==(const Array &rhs) const
{
  bool equal = true;
  // check lengths first
  if (Array::cur_size_ != rhs.cur_size_)
  {
    equal = false;
  }
  else
  {
    // loop through arrays to compare values
    for (int i = 0; i < Array::cur_size_; i++)
    {
      if (Array::data_[i] != rhs.data_[i])
      {
        equal = false;
        break;
      }
    }
    return equal;
  }
}

//COMMENT: Try defining != in terms of the == operator.
//REPLY: Done. Removed previous code and changed to using previously defined == operator.
bool Array::operator!=(const Array &rhs) const
{
  return !(*this == rhs);
}

void Array::fill(char ch)
{
  // update cur_size_ to max_size_ and fill with ch argument
  Array::cur_size_ = Array::max_size_;
  for (int i = 0; i < Array::cur_size_; i++)
  {
    Array::data_[i] = ch;
  }
}

void Array::reverse(void)
{
  // loop through first half of the array
  for (int i = 0; i < (Array::cur_size_ / 2); i++)
  {
    char temp = Array::data_[i];
    Array::data_[i] = Array::data_[Array::cur_size_ - (i + 1)];
    Array::data_[Array::cur_size_ - (i + 1)] = temp;
  }
}

Array Array::slice(size_t begin) const
{
  // if begin is valid
  if (begin >= 0 && begin < Array::cur_size_)
  {
    // get size of the new array
    size_t newSize = Array::cur_size_ - begin;
    // create new array then fill
    Array newArr = Array(newSize);
    for (int i = begin; i < Array::cur_size_; i++)
    {
      newArr.set(i - begin, Array::data_[i]);
    }
    return newArr;
  }
  else
  {
    throw std::out_of_range("begin must be within the bounds of the array");
  }
}

Array Array::slice(size_t begin, size_t end) const
{
  // if begin is valid
  if (begin >= 0 && begin < Array::cur_size_)
  {
    // if end is valid
    if (end > begin && end <= Array::cur_size_)
    {
      // get size of the new array
      size_t newSize = end - begin;
      // create new array then fill
      Array newArr = Array(newSize);
      for (int i = begin; i < end - 1; i++)
      {
        newArr.set((i - begin), Array::data_[i]);
      }
      return newArr;
    }
    else
    {
      throw std::out_of_range("end must be within the bounds of the array and larger than begin");
    }
  }
  else
  {
    throw std::out_of_range("begin must be within the bounds of the array");
  }
}

void Array::truncate(size_t new_size)
{
  // create temp_data to store new memory location and fill with original data_
  char *temp_data = new char[Array::max_size_];
  for (int i = 0; i < new_size; i++)
  {
    temp_data[i] = Array::data_[i];
  }
  // delete original data_ pointer and assign new data to it
  delete[] Array::data_;
  Array::data_ = nullptr;
  Array::data_ = temp_data;
  // update size properties to reflect change
  Array::cur_size_ = new_size;
  Array::max_size_ = new_size;
}

void Array::expand(size_t new_size)
{
  // create temp_data to store new memory location and fill with original data_
  char *temp_data = new char[new_size];
  for (int i = 0; i < Array::cur_size_; i++)
  {
    temp_data[i] = Array::data_[i];
  }
  // delete original data_ pointer and assign temp_data to it
  delete[] Array::data_;
  Array::data_ = nullptr;
  Array::data_ = temp_data;
  // change max_size_ to reflect change
  Array::max_size_ = new_size;
}