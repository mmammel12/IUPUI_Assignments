#include "Array.h"
#include <iostream>

int main(int argc, char *argv[])
{
  // create Array with default constructor
  Array defArray = Array();

  // create array with length constructor
  Array lenArray = Array(10);

  // create array with length constructor at max size (200,000)
  Array maxLenArray = Array(200000);

  // create array with length and fill constructor
  Array fillArray = Array(5, 'm');

  // create array with array argument constructor
  Array copyArray = Array(fillArray);

  // check sizes of each array
  // defArray current should be 0, max 100
  std::cout << "default current: " << defArray.size() << "\ndefault max: " << defArray.max_size();

  // lenArray current: 0, max 10
  std::cout << "\n\nlength current: " << lenArray.size() << "\nlength max: " << lenArray.max_size();

  // lenArray current: 0, max 200000
  std::cout << "\n\nmax length current: " << maxLenArray.size() << "\nlength max: " << maxLenArray.max_size();

  // fillArray current: 5, max 5
  std::cout << "\n\nfill current: " << fillArray.size() << "\nfill max: " << fillArray.max_size();

  // copyArray current: 5, max 5
  std::cout << "\n\ncopy current: " << fillArray.size() << "\ncopy max: " << fillArray.max_size();

  // fill default with 'x'
  defArray.fill('x');

  // defArray current should be 100, max 100
  std::cout << "\n\ndefault current: " << defArray.size() << "\ndefault max: " << defArray.max_size();

  // test set
  defArray.set(5, 'o');

  // test get, should be 'x' then 'o'
  std::cout << "\n\ndefault index 4: " << defArray.get(4) << "\ndefault index 5: " << defArray.get(5);

  // test [] overload, should be 'o'
  char bracket = defArray[5];
  std::cout << "\n\n[] test: " << bracket;

  // resize default array to 10
  defArray.resize(10);

  // defArray current should be 10, max 10
  std::cout << "\n\ndefault current: " << defArray.size() << "\ndefault max: " << defArray.max_size();

  // resize larger
  defArray.resize(20);

  // defArray current should be 10, max 20
  std::cout << "\n\ndefault current: " << defArray.size() << "\ndefault max: " << defArray.max_size();

  // shrink test
  defArray.shrink();

  // defArray current should be 10, max 10
  std::cout << "\n\ndefault current: " << defArray.size() << "\ndefault max: " << defArray.max_size();

  // test find, should return 5
  std::cout << "\n\nfind test: " << defArray.find('o');

  // test find, should return -1
  std::cout << "\n\nfind test: " << defArray.find('y');

  // test find overload, should return 5
  std::cout << "\n\nfind test: " << defArray.find('o', 2);

  // test find overload, should return -1
  std::cout << "\n\nfind test: " << defArray.find('o', 6);

  // test assignment operator overload
  fillArray = defArray;

  // test == != operator overload
  if (fillArray == defArray)
  {
    std::cout << "\n\n== correct";
  }

  // test != operator overload
  fillArray[3] = 'v';
  if (fillArray != defArray)
  {
    std::cout << "\n\n!= correct";
  }

  // test reverse
  defArray[0] = '0';
  defArray[1] = '1';
  defArray[2] = '2';
  defArray[3] = '3';
  defArray[4] = '4';
  defArray[5] = '5';
  defArray[6] = '6';
  defArray[7] = '7';
  defArray[8] = '8';
  defArray[9] = '9';
  std::cout << "\n\nbefore reverse:\n";
  for (int i = 0; i < defArray.size(); i++)
  {
    std::cout << defArray[i];
  }
  defArray.reverse();
  std::cout << "\n\nafter reverse:\n";
  for (int i = 0; i < defArray.size(); i++)
  {
    std::cout << defArray[i];
  }

  // slice from 1 to end
  Array sliceArray = defArray.slice(1);
  std::cout << "\n\nafter slice 1:\n";
  for (int i = 0; i < sliceArray.size(); i++)
  {
    std::cout << sliceArray[i];
  }

  // slice from 2 to 5, 5 not included
  Array sliceArray2 = defArray.slice(2, 5);
  std::cout << "\n\nafter slice 2:\n";
  for (int i = 0; i < sliceArray2.size(); i++)
  {
    std::cout << sliceArray2[i];
  }

  // slice from start to end
  Array sliceArray3 = defArray.slice(0);
  std::cout << "\n\nafter slice 3:\n";
  for (int i = 0; i < sliceArray3.size(); i++)
  {
    std::cout << sliceArray3[i];
  }

  // slice from start to end, end not included
  Array sliceArray4 = defArray.slice(0, defArray.size());
  std::cout << "\n\nafter slice 4:\n";
  for (int i = 0; i < sliceArray4.size(); i++)
  {
    std::cout << sliceArray4[i];
  }

  std::cout << "\n\nERROR TESTING" << std::endl;

  try
  {
    char x = defArray[20];
  }
  catch (std::out_of_range &e)
  {
    std::cout << "\n\nOut of range error caught: " << e.what();
  }

  try
  {
    char y = defArray.get(20);
  }
  catch (std::out_of_range &e)
  {
    std::cout << "\n\nGet out of range error caught: " << e.what();
  }

  try
  {
    defArray.set(20, 'x');
  }
  catch (std::out_of_range &e)
  {
    std::cout << "\n\nSet out of range error caught: " << e.what();
  }

  try
  {
    int z = defArray.find(20, 'y');
  }
  catch (std::out_of_range &e)
  {
    std::cout << "\n\nFind out of range error caught: " << e.what();
  }

  try
  {
    Array sliceErrArray = defArray.slice(20);
  }
  catch (std::out_of_range &e)
  {
    std::cout << "\n\nSlice out of range error caught: " << e.what();
  }

  try
  {
    Array slice2ErrArray = defArray.slice(20, 30);
  }
  catch (std::out_of_range &e)
  {
    std::cout << "\n\nSlice 2 out of range error caught: " << e.what();
  }

  try
  {
    Array slice3ErrArray = defArray.slice(2, 30);
  }
  catch (std::out_of_range &e)
  {
    std::cout << "\n\nSlice 3 out of range error caught: " << e.what();
  }

  try
  {
    Array slice4ErrArray = defArray.slice(5, 3);
  }
  catch (std::out_of_range &e)
  {
    std::cout << "\n\nSlice 4 out of range error caught: " << e.what();
  }

  std::cout << std::endl
            << std::endl;

  return 0;
}
