// $Id: Fixed_Array.cpp 827 2011-02-07 14:20:53Z hillj $

// Honor Pledge:
//
// I pledge that I have neither given nor received any help
// on this assignment.

//
// Fixed_Array
//
//COMMENT: Learn/Lookup how to call the parent constructor in C++.
//REPLY: switched to calling the parent constructor
template <typename T, size_t N>
Fixed_Array<T, N>::Fixed_Array(void)
    : Array_Base<T>(N)
{
}

//
// Fixed_Array (const Fixed_Array &)
//
//COMMENT: Learn/Lookup how to call the parent constructor in C++.
//REPLY: switched to calling the parent constructor
template <typename T, size_t N>
Fixed_Array<T, N>::Fixed_Array(const Fixed_Array<T, N> &arr)
    : Array_Base<T>(arr)
{
}

//
// Fixed_Array (T)
//
//COMMENT: Learn/Lookup how to call the parent constructor in C++.
//REPLY: switched to calling the parent constructor
template <typename T, size_t N>
Fixed_Array<T, N>::Fixed_Array(T fill)
    : Array_Base<T>(N, fill)
{
}

//
// ~Fixed_Array
//
template <typename T, size_t N>
Fixed_Array<T, N>::~Fixed_Array(void)
{
  if (this->data_ != nullptr)
  {
    delete[] this->data_;
    this->data_ = nullptr;
  }
}

//
// operator =
//
template <typename T, size_t N>
const Fixed_Array<T, N> &Fixed_Array<T, N>::operator=(const Fixed_Array<T, N> &rhs)
{
  delete[] this->data_;
  this->data_ = nullptr;

  this->data_ = new T[N];
  this->cur_size_ = rhs.size();

  for (int i = 0; i < rhs.size(); i++)
  {
    this->data_[i] = rhs.get(i);
  }
}
