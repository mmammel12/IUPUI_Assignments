// -*- C++ -*-
// $Id: Stack.h 380 2010-02-08 05:10:33Z hillj $

//==============================================================================
/**
 * Honor Pledge:
 *
 * I pledge that I have neither given nor received any help
 * on this assignment.
 */
//==============================================================================

#ifndef _STACK_H_
#define _STACK_H_

#include <cstring> // for size_t definition
#include "Array.h"
#include "empty_exception.h"

/**
 * @class Stack
 *
 * Basic stack for abitrary elements.
 */
template <typename T>
class Stack
{
public:
  /// Default constructor.
  Stack(void);

  /// Copy constructor.
  Stack(const Stack &stack);

  /// Destructor.
  ~Stack(void);

  /**
   * Assignment operator
   *
   * @param[in]      rhs           Right-hand side of operator
   * @return         Reference to self
   */
  const Stack &operator=(const Stack &rhs);

  /**
   * Push a new element onto the stack. The element is inserted
   * before all the other elements in the list.
   *
   * @param[in]      element       Element to add to the list
   */
  void push(T element);

  /**
   * Remove the top-most element from the stack.
   *
   * @exception      empty_exception    The stack is empty.
   */
  void pop(void);

  /**
   * Get the top-most element on the stack. If there are no element 
   * on the stack, then the stack_is_empty exception is thrown.
   *
   * @return         Element on top of the stack.
   * @exception      empty_exception    The stack is empty
   */
  T top(void) const;

  /**
   * Test if the stack is empty
   *
   * @retval         true          The stack is empty
   * @retval         false         The stack is not empty
   */
  bool is_empty(void) const;

  /**
   * Number of element on the stack.
   *
   * @return         Size of the stack.
   */
  size_t size(void) const;

  /// Remove all elements from the stack.
  void clear(void);

private:
  // increase the size of the stack if max_size_ is reached
  void expand(void);

  //COMMENT: The array does not need to be on the heap as it is redundant since the data_ is already on the heap.
  //Also, You're making the assignment more difficult for yourself!
  // REPLY: elements_ is no longer a pointers
  // Array to store the elements in the stack
  Array<T> elements_;
  // maximum size of the current elements_
  size_t max_size_;
  // one above current top of the stack
  size_t top_;
};

// include the inline files
#include "Stack.inl"

// include the source file since template class
#include "Stack.cpp"

#endif // !defined _CS507_STACK_H_
