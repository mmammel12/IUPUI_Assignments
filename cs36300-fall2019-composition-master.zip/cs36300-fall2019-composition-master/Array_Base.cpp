// Author: Marty Mammel
// Last Modification: 9/29/2019
// Array_Base template class without the use of the std library

// Honor Pledge:
//
// I pledge that I have neither given nor receieved any help
// on this assignment.

#include <stdexcept> // for std::out_of_bounds exception

#define DEFAULT_SIZE 10000

//
// Array
//
template <typename T>
Array_Base<T>::Array_Base(void)
    : cur_size_(0),
      max_size_(DEFAULT_SIZE),
      data_(new T[DEFAULT_SIZE])
{
}

//
// Array (size_t)
//
template <typename T>
Array_Base<T>::Array_Base(size_t length)
    : cur_size_(0),
      max_size_(length),
      data_(new T[length])
{
}

//
// Array (size_t, T)
//
template <typename T>
Array_Base<T>::Array_Base(size_t length, T fill)
    : cur_size_(length),
      max_size_(length),
      data_(new T[length])
{
  for (int i = 0; i < length; i++)
  {
    this->data_[i] = fill;
  }
}

//
// Array (const Array &)
//
template <typename T>
Array_Base<T>::Array_Base(const Array_Base &array)
    : cur_size_(array.cur_size_),
      max_size_(array.max_size_),
      data_(new T[array.max_size_])
{
  for (int i = 0; i < array.cur_size_; i++)
  {
    this->data_[i] = array.data_[i];
  }
}

//
// ~Array
//
template <typename T>
Array_Base<T>::~Array_Base(void)
{
  if (this->data_ != nullptr)
  {
    delete[] this->data_;
    this->data_ = nullptr;
  }
}

//
// operator =
//
template <typename T>
const Array_Base<T> &Array_Base<T>::operator=(const Array_Base &rhs)
{
  delete[] this->data_;
  this->data_ = nullptr;
  this->data_ = new T[rhs.max_size_];
  for (int i = 0; i < rhs.cur_size_; i++)
  {
    this->data_[i] = rhs.data_[i];
  }
  this->cur_size_ = rhs.cur_size_;
  this->max_size_ = rhs.max_size_;
}

//
// operator []
//
template <typename T>
T &Array_Base<T>::operator[](size_t index)
{
  if (index >= this->cur_size_ || index < 0)
  {
    throw std::out_of_range("Invalid index");
  }
  return this->data_[index];
}

//
// operator []
//
template <typename T>
const T &Array_Base<T>::operator[](size_t index) const
{
  if (index >= this->cur_size_ || index < 0)
  {
    throw std::out_of_range("Invalid index");
  }
  return this->data_[index];
}

//
// get
//
template <typename T>
T Array_Base<T>::get(size_t index) const
{
  if (index >= this->cur_size_ || index < 0)
  {
    throw std::out_of_range("Invalid index");
  }
  return this->data_[index];
}

//
// set
//
template <typename T>
void Array_Base<T>::set(size_t index, T value)
{
  if (index >= this->max_size_ || index < 0)
  {
    throw std::out_of_range("Invalid index");
  }
  else if (index >= this->cur_size_)
  {
    this->cur_size_ = index + 1;
  }
  this->data_[index] = value;
}

//
// find (T)
//
template <typename T>
int Array_Base<T>::find(T value) const
{
  // loop through array to find character
  for (int i = 0; i < this->cur_size_; i++)
  {
    if (this->data_[i] == value)
    {
      return i;
    }
  }
  return -1;
}

//
// find (T, size_t)
//
template <typename T>
int Array_Base<T>::find(T val, size_t start) const
{
  int index = -1;
  // if start is within the bounds of the array
  if (start >= 0 && start < this->cur_size_)
  {
    // loop through array to find character
    for (int i = start; i < this->cur_size_; i++)
    {
      if (this->data_[i] == val)
      {
        index = i;
      }
    }
  }
  else
  {
    throw std::out_of_range("start must be within the bounds of the array");
  }

  return index;
}

//
// operator ==
//
template <typename T>
bool Array_Base<T>::operator==(const Array_Base &rhs) const
{
  bool equal = true;
  // check lengths first
  if (this->cur_size_ != rhs.cur_size_)
  {
    equal = false;
  }
  else
  {
    // loop through arrays to compare values
    for (int i = 0; i < this->cur_size_; i++)
    {
      if (this->data_[i] != rhs.data_[i])
      {
        equal = false;
        break;
      }
    }
    return equal;
  }
}

//
// operator !=
//
template <typename T>
bool Array_Base<T>::operator!=(const Array_Base &rhs) const
{
  return !(*this == rhs);
}

//
// fill
//
template <typename T>
void Array_Base<T>::fill(T value)
{
  // update cur_size_ to max_size_ and fill with value argument
  this->cur_size_ = this->max_size_;
  for (int i = 0; i < this->cur_size_; i++)
  {
    this->data_[i] = value;
  }
}

//
// reverse
//
template <typename T>
void Array_Base<T>::reverse(void)
{
  // loop through first half of the array
  for (int i = 0; i < (this->cur_size_ / 2); i++)
  {
    char temp = this->data_[i];
    this->data_[i] = this->data_[this->cur_size_ - (i + 1)];
    this->data_[this->cur_size_ - (i + 1)] = temp;
  }
}
