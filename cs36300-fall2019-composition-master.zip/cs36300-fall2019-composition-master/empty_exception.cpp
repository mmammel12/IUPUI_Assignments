#include "empty_exception.h"

empty_exception::empty_exception(const char *msg)
    : std::runtime_error(msg)
{
}
