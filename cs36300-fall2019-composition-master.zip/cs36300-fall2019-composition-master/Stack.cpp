// $Id: Stack.cpp 827 2011-02-07 14:20:53Z hillj $

// Honor Pledge:
//
// I pledge that I have neither given nor received any help
// on this assignment.

#define BOTTOM 0

//
// Stack
//
template <typename T>
Stack<T>::Stack(void)
    : elements_(Array<T>(DEFAULT_SIZE)),
      max_size_(DEFAULT_SIZE),
      top_(BOTTOM)
{
}

//
// Stack
//
template <typename T>
Stack<T>::Stack(const Stack &stack)
    : elements_(Array<T>(stack.max_size_)),
      max_size_(stack.max_size_),
      top_(stack.top_)
{
  if (stack.top_ > BOTTOM)
  {
    for (size_t i = 0; i < stack.top_; i++)
    {
      this->elements_.set(i, stack.elements_.get(i));
    }
  }
}

//
// ~Stack
//
template <typename T>
Stack<T>::~Stack(void)
{
}

//
// operator =
//
template <typename T>
const Stack<T> &Stack<T>::operator=(const Stack &rhs)
{
  this->elements_ = Array<T>(rhs.elements_);
  this->top_ = rhs.top_;
  this->max_size_ = rhs.max_size_;
}

//
// push
//
template <typename T>
void Stack<T>::push(T element)
{
  if (this->top_ >= this->max_size_)
  {
    this->expand();
  }
  this->elements_.set(this->top_, element);
  this->top_++;
}

//
// pop
//
template <typename T>
void Stack<T>::pop(void)
{
  if (this->top_ > BOTTOM)
  {
    this->top_--;
  }
  else
  {
    throw empty_exception("Error: Stack is currently empty");
  }
}

//
// clear
//
template <typename T>
void Stack<T>::clear(void)
{
  this->elements_ = Array<T>(DEFAULT_SIZE);
  this->top_ = BOTTOM;
  this->max_size_ = DEFAULT_SIZE;
}

//
// expand
//
template <typename T>
void Stack<T>::expand(void)
{
  this->max_size_ += DEFAULT_SIZE;
  Array<T> temp(this->max_size_);
  for (size_t i = 0; i < this->top_; i++)
  {
    temp.set(i, this->elements_.get(i));
  }

  this->elements_ = Array<T>(temp);
}
