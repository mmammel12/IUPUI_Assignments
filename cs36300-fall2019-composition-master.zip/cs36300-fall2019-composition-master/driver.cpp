#include "Array_Base.h"
#include "Array.h"
#include "Fixed_Array.h"
#include "Stack.h"
#include "Queue.h"
#include <iostream>
#define LENGTH 5

void correct(bool value, const char *msg)
{
  if (!value)
  {
    throw std::logic_error(msg);
  }
}

void testArray_Base()
{
  std::cout << "\n\nTESTING Array_Base\n";
  //
  // Array_Base Testing
  //
  Array_Base<char> arrBase1;
  correct(arrBase1.size() >= 0, "default constructor failed");

  Array_Base<char> arrBase2(LENGTH);
  correct(arrBase2.max_size() == LENGTH, "length constructor failed");

  Array_Base<char> arrBase3(LENGTH, 'n');
  correct(arrBase3.size() == LENGTH, "fill constructor failed");

  Array_Base<char> arrBase4(LENGTH);
  Array_Base<char> copy(arrBase4);
  correct(copy.max_size() == LENGTH, "copy constructor failed");

  // assignment, size and max_size
  Array_Base<char> arrBase5;
  Array_Base<char> copy2 = arrBase5;
  correct(copy2.size() >= 0, "assignment operator failed");
  correct(copy2.max_size() > 0, "max_size() failed");

  // subscript operator, get, set
  Array_Base<char> arrBase6(LENGTH, 'n');

  size_t len = arrBase6.size();
  for (size_t i = 0; i < len; ++i)
  {
    char msg[128];
    sprintf(msg, "subscript on %zd failed", i);
    correct(arrBase6[i] == 'n', msg);
  }

  arrBase6.set(3, '1');
  correct(arrBase6.get(3) == '1', "set() failed");

  // subscript exception
  try
  {
    arrBase6[LENGTH + 1];
    correct(false, "subscript out of range failed");
  }
  catch (const std::out_of_range &e)
  {
    std::cerr << e.what() << '\n';
    correct(true, "subscript out of range success");
  }

  // find and reverse
  Array_Base<char> arrBase7(LENGTH);
  arrBase7.set(0, 'm');
  arrBase7.set(1, 'a');
  arrBase7.set(2, 'r');
  arrBase7.set(3, 't');
  arrBase7.set(4, 'y');

  correct(arrBase7.find('a') == 1, "find('a') failed");
  correct(arrBase7.find('x') == -1, "find('x') DNE failed");

  // find exception
  try
  {
    arrBase7.find('a', LENGTH + 1);
    correct(false, "find() out of range failed");
  }
  catch (const std::out_of_range &e)
  {
    std::cerr << e.what() << '\n';
    correct(true, "find() out of range success");
  }

  arrBase7.reverse();
  correct(arrBase7[0] == 'y', "reverse on 0 failed");
  correct(arrBase7[1] == 't', "reverse on 1 failed");
  correct(arrBase7[2] == 'r', "reverse on 2 failed");
  correct(arrBase7[3] == 'a', "reverse on 3 failed");
  correct(arrBase7[4] == 'm', "reverse on 4 failed");

  // ==, !=
  Array_Base<char> arrBase8(LENGTH, 'a');
  Array_Base<char> arrBase9(LENGTH, 'a');
  correct(arrBase8 == arrBase9, "equality operator failed");

  Array_Base<char> arrBase10(LENGTH, 'a');
  Array_Base<char> arrBase11(LENGTH, 'b');
  correct(arrBase10 != arrBase11, "in-equality operator failed");

  // fill
  Array_Base<char> arrBase12(LENGTH);
  arrBase12.fill('n');

  for (size_t i = 0; i < LENGTH; ++i)
  {
    char msg[128];
    sprintf(msg, "fill('n') on %zd failed", i);
    correct(arrBase12[i] == 'n', msg);
  }
}

void testArray()
{
  std::cout << "\n\nTESTING Array\n";
  //
  // Array Testing
  //
  Array<char> array1;
  correct(array1.size() >= 0, "default constructor failed");

  Array<char> array2(LENGTH);
  correct(array2.max_size() == LENGTH, "length constructor failed");

  Array<char> array3(LENGTH, 'n');
  correct(array3.size() == LENGTH, "fill constructor failed");

  Array<char> array4(LENGTH);
  Array<char> copy(array4);
  correct(copy.max_size() == LENGTH, "copy constructor failed");

  // assignment, size and max_size
  Array<char> array5;
  Array<char> copy2 = array5;
  correct(copy2.size() >= 0, "assignment operator failed");
  correct(copy2.max_size() > 0, "max_size() failed");

  // subscript operator, get, set
  Array<char> array6(LENGTH, 'n');

  size_t len = array6.size();
  for (size_t i = 0; i < len; ++i)
  {
    char msg[128];
    sprintf(msg, "subscript on %zd failed", i);
    correct(array6[i] == 'n', msg);
  }

  array6.set(3, '1');
  correct(array6.get(3) == '1', "set() failed");

  // subscript exception
  try
  {
    array6[LENGTH + 1];
    correct(false, "subscript out of range failed");
  }
  catch (const std::out_of_range &e)
  {
    std::cerr << e.what() << '\n';
    correct(true, "subscript out of range success");
  }

  // find and reverse
  Array<char> array7(LENGTH);
  array7.set(0, 'm');
  array7.set(1, 'a');
  array7.set(2, 'r');
  array7.set(3, 't');
  array7.set(4, 'y');

  correct(array7.find('a') == 1, "find('a') failed");
  correct(array7.find('x') == -1, "find('x') DNE failed");

  // find exception
  try
  {
    array7.find('a', LENGTH + 1);
    correct(false, "find() out of range failed");
  }
  catch (const std::out_of_range &e)
  {
    std::cerr << e.what() << '\n';
    correct(true, "find() out of range success");
  }

  array7.reverse();
  correct(array7[0] == 'y', "reverse on 0 failed");
  correct(array7[1] == 't', "reverse on 1 failed");
  correct(array7[2] == 'r', "reverse on 2 failed");
  correct(array7[3] == 'a', "reverse on 3 failed");
  correct(array7[4] == 'm', "reverse on 4 failed");

  // slice
  Array<char> sliced1 = array7.slice(3);
  correct(sliced1[0] == 'a', "slice(3) on 0 failed");
  correct(sliced1[1] == 'm', "slice(3) on 1 failed");

  Array<char> sliced2 = array7.slice(0, 3);
  correct(sliced2[0] == 'y', "slice(3) on 0 failed");
  correct(sliced2[1] == 't', "slice(3) on 1 failed");
  correct(sliced2[2] == 'r', "slice(3) on 2 failed");

  // ==, !=
  Array<char> array8(LENGTH, 'a');
  Array<char> array9(LENGTH, 'a');
  correct(array8 == array9, "equality operator failed");

  Array<char> array10(LENGTH, 'a');
  Array<char> array11(LENGTH, 'b');
  correct(array10 != array11, "in-equality operator failed");

  // fill
  Array<char> array12(LENGTH);
  array12.fill('n');

  for (size_t i = 0; i < LENGTH; ++i)
  {
    char msg[128];
    sprintf(msg, "fill('n') on %zd failed", i);
    correct(array12[i] == 'n', msg);
  }

  // resize and shrink
  Array<char> array13(LENGTH, 'n');
  size_t m = array13.max_size();
  array13.resize(m + 2);
  correct(array13.max_size() >= (m + 2), "resize larger failed");

  Array<char> array14(LENGTH, 'n');
  size_t c = array14.size();
  array14.resize(c - 2);
  correct(array14.size() == (c - 2), "resize smaller failed");

  Array<char> array15(LENGTH, 'n');
  size_t n = array15.max_size();
  array15.resize(n + 2);
  array15.shrink();
  correct(array15.size() == array15.max_size(), "shrink to reclaim unused space failed");
}

void testFixed_Array()
{
  std::cout << "\n\nTESTING Fixed_Array\n";
  //
  // Fixed Testing
  //
  Fixed_Array<char, LENGTH> fixedArr1;
  correct(fixedArr1.size() >= 0, "default constructor failed");

  Fixed_Array<char, LENGTH> fixedArr2('n');
  correct(fixedArr2.size() == LENGTH, "fill constructor failed");

  Fixed_Array<char, LENGTH> fixedArr3('n');
  Fixed_Array<char, LENGTH> copy(fixedArr3);
  correct(copy.size() == LENGTH, "copy constructor failed");

  // assignment, size and max_size
  Fixed_Array<char, LENGTH> fixedArr4('n');
  Fixed_Array<char, LENGTH> copy4 = fixedArr4;
  correct(copy4.size() >= 0, "assignment operator failed");
  correct(copy4.max_size() > 0, "max_size() failed");

  // subscript operator, get, set
  Fixed_Array<char, LENGTH> fixedArr9('n');

  size_t len = fixedArr9.size();
  for (size_t i = 0; i < len; ++i)
  {
    char msg[128];
    sprintf(msg, "subscript on %zd failed", i);
    correct(fixedArr9[i] == 'n', msg);
  }

  fixedArr9.set(3, '1');
  correct(fixedArr9.get(3) == '1', "set() failed");

  // subscript exception
  try
  {
    fixedArr9[LENGTH + 1];
    correct(false, "subscript out of range failed");
  }
  catch (const std::out_of_range &e)
  {
    std::cerr << e.what() << '\n';
    correct(true, "subscript out of range success");
  }

  // find and reverse
  Fixed_Array<char, LENGTH> fixedArr10;
  fixedArr10.set(0, 'm');
  fixedArr10.set(1, 'a');
  fixedArr10.set(2, 'r');
  fixedArr10.set(3, 't');
  fixedArr10.set(4, 'y');

  correct(fixedArr10.find('a') == 1, "find('a') failed");
  correct(fixedArr10.find('x') == -1, "find('x') DNE failed");

  // find exception
  try
  {
    fixedArr10.find(LENGTH + 1, 'a');
    correct(false, "find() out of range failed");
  }
  catch (const std::out_of_range &e)
  {
    std::cerr << e.what() << '\n';
    correct(true, "find() out of range success");
  }

  fixedArr10.reverse();
  correct(fixedArr10[0] == 'y', "reverse on 0 failed");
  correct(fixedArr10[1] == 't', "reverse on 1 failed");
  correct(fixedArr10[2] == 'r', "reverse on 2 failed");
  correct(fixedArr10[3] == 'a', "reverse on 3 failed");
  correct(fixedArr10[4] == 'm', "reverse on 4 failed");

  // ==, !=
  Fixed_Array<char, LENGTH> fixedArr11('a');
  Fixed_Array<char, LENGTH> fixedArr12('a');
  correct(fixedArr11 == fixedArr12, "equality operator failed");

  Fixed_Array<char, LENGTH> fixedArr13('a');
  Fixed_Array<char, LENGTH> fixedArr14('b');
  correct(fixedArr13 != fixedArr14, "in-equality operator failed");

  // fill
  Fixed_Array<char, LENGTH> fixedArr15;
  fixedArr15.fill('n');

  for (size_t i = 0; i < LENGTH; ++i)
  {
    char msg[128];
    sprintf(msg, "fill('n') on %zd failed", i);
    correct(fixedArr15[i] == 'n', msg);
  }
}

void testQueue()
{
  std::cout << "\n\nTESTING Queue\n";

  Queue<char> q;
  correct(q.size() == 0, "default constructor failed");

  correct(q.is_empty(), "is_empty failed");

  q.enqueue('m');
  q.enqueue('a');
  q.enqueue('r');
  q.enqueue('t');
  q.enqueue('y');

  correct(q.size() == 5, "enqueue failed");
  correct(q.dequeue() == 'm', "dequeue failed");

  Queue<char> copy(q);
  correct(copy.size() == q.size(), "copy constructor failed");

  q = copy;
  correct(q.size() == 4, "assignment operator failed");
  correct(q.dequeue() == 'a', "assignment operator failed");

  q.clear();
  correct(q.is_empty(), "clear failed");
}

void testStack()
{
  std::cout << "\n\nTESTING Stack\n";

  Stack<char> s;
  correct(s.is_empty(), "default constructor failed");

  s.push('m');
  s.push('a');
  s.push('r');
  s.push('t');
  s.push('y');
  correct(!s.is_empty(), "is_empty failed");
  correct(s.size() == 5, "push failed");

  Stack<char> copy(s);
  correct(copy.size() == 5, "copy constructor failed");

  correct(copy.top() == 'y', "top failed");

  copy.pop();
  correct(copy.top() == 't', "pop failed");

  copy = s;
  correct(copy.size() == s.size(), "assignment operator failed");

  copy.clear();
  correct(copy.is_empty(), "clear failed");
}

int main(int argc, char const *argv[])
{
  testArray_Base();
  testArray();
  testFixed_Array();
  testQueue();
  testStack();

  return 0;
}
