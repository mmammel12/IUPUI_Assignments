public class Admin extends User {
  private static final long serialVersionUID = 1L;
  private String username;
  private String password;

  public Admin(String username, String password) {
    this.username = username;
    this.password = password;
  }

  @Override
  public String getUsername() {
    return this.username;
  }

  @Override
  public void setPassword(String password) {
    this.password = password;
  }

  @Override
  public boolean validatePassword(String password) {
    return this.password.equals(password);
  }

}
