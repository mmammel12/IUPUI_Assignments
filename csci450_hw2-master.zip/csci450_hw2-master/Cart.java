import java.io.Serializable;
import java.util.HashMap;

public class Cart implements Serializable {
  private static final long serialVersionUID = 1L;
  private String cartID;
  private HashMap<String, Integer> items;

  public Cart(String cartID) {
    this.cartID = cartID;
    this.items = new HashMap<>();
  }

  public Cart(String cartID, HashMap<String, Integer> items) {
    this.cartID = cartID;
    this.items = items;
  }

  public String getCartID() {
    return this.cartID;
  }

  public HashMap<String, Integer> getItems() {
    return this.items;
  }

  public void updateCart(String itemName, int quantity) {
    items.put(itemName, quantity);
  }

  public void removeFromCart(String itemName) {
    items.remove(itemName);
  }

  public void clear() {
    this.items.clear();
  }
}
