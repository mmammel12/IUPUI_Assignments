import java.io.Serializable;

public class Item implements Serializable {
  private static final long serialVersionUID = 1L;
  private String itemName;
  private String description;
  private float price;
  private int quantity;

  public Item(String itemName, String description, float price, int quantity) {
    this.itemName = itemName;
    this.description = description;
    this.price = price;
    this.quantity = quantity;
  }

  public String getItemInfo() {
    return String.format("Item Name: %s%nDescription: %s%nPrice: %.2f%nQuantity: %d%n", this.itemName, this.description,
        this.price, this.quantity);
  }

  public String getItemName() {
    return this.itemName;
  }

  public String getDescription() {
    return this.description;
  }

  public float getPrice() {
    return this.price;
  }

  public int getQuantity() {
    return this.quantity;
  }

  public void setItemName(String itemName) {
    this.itemName = itemName;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setPrice(float price) {
    if (price > 0) {
      this.price = price;
    } else {
      System.out.println("Error: Price cannot be $0");
    }
  }

  public void setQuantity(int quantity) {
    if (quantity >= 0) {
      this.quantity = quantity;
    } else {
      System.out.println("Error: Quantity cannot be below 0");
    }
  }
}
