import java.io.Serializable;

public abstract class User implements Serializable {
  private static final long serialVersionUID = 1L;

  abstract String getUsername();

  abstract void setPassword(String password);

  abstract boolean validatePassword(String password);
}
