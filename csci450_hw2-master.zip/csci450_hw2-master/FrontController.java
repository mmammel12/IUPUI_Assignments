import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;

public class FrontController implements Serializable {
  private static final long serialVersionUID = 1L;
  private User currentUser = null;
  private Cart currentCart = null;
  private boolean isAdmin = false;
  // HashMaps are set up as <ID, Object>
  private HashMap<String, Item> items;
  private HashMap<String, User> users;
  private HashMap<String, Cart> carts;

  public FrontController(HashMap<String, Item> items, HashMap<String, User> users, HashMap<String, Cart> carts) {
    this.items = items;
    this.users = users;
    this.carts = carts;
  }

  public void registerCustomer(String username, String password) {
    if (users.get(username) == null) {
      User newUser = new Customer(username, password);
      this.currentUser = newUser;
      Cart newCart = new Cart(username);
      this.currentCart = newCart;
      carts.put(username, newCart);
      users.put(username, newUser);
      System.out.println("Customer: " + username + " successfully created");
    } else {
      System.out.println("Error: Duplicate username");
    }
  }

  public void registerAdmin(String username, String password) {
    if (this.isAdmin) {
      if (users.get(username) == null) {
        Admin newAdmin = new Admin(username, password);
        users.put(username, newAdmin);
        System.out.println("Admin: " + username + " successfully created.");
      } else {
        System.out.println("Error: Duplicate username");
      }
    }
  }

  public void removeUser(String username) {
    if (users.get(username) instanceof Customer) {
      this.users.remove(username);
    } else {
      System.out.println("Error: Admins cannot be removed at this time");
    }
  }

  public boolean login(String username, String password) {
    User user = users.get(username);
    boolean valid = false;
    if (user != null) {
      if (user.validatePassword(password)) {
        this.currentUser = user;
        if (user instanceof Admin) {
          this.isAdmin = true;
        }
        valid = true;
      }
    }

    return valid;
  }

  public void logout() {
    this.currentUser = null;
    this.currentCart = null;
    this.isAdmin = false;
  }

  public boolean checkAdmin() {
    return this.isAdmin;
  }

  public void changePassword(String currentPassword, String newPassword) {
    if (this.currentUser.validatePassword(currentPassword)) {
      this.currentUser.setPassword(newPassword);
    } else {
      System.out.println("Error: Incorrect current password");
    }
  }

  public boolean checkUsername(String username) {
    // returns true if username exists
    return this.users.get(username) != null;
  }

  public ArrayList<Item> search() {
    ArrayList<Item> itemsList = new ArrayList<>();
    this.items.forEach((k, v) -> itemsList.add(v));
    return itemsList;
  }

  public void updateCart(String itemName, int quantity) {
    if (quantity > 0) {
      this.currentCart.updateCart(itemName, quantity);
    } else if (quantity == 0) {
      this.currentCart.removeFromCart(itemName);
    } else {
      System.out.println("Error: Cannot have negative quantity");
    }
  }

  public String viewCart() {
    HashMap<String, Integer> cartMap = this.currentCart.getItems();
    StringBuilder output = new StringBuilder("Cart:");
    ArrayList<String> cartItems = new ArrayList<>();
    cartMap.forEach((k, v) -> cartItems.add(String.format("%s -- %d", k, v)));
    for (int i = 0; i < cartItems.size(); i++) {
      output.append(String.format("%n%d) %s", i, cartItems.get(i)));
    }

    return output.toString();
  }

  public void purchase() {
    System.out.println("Purchased:");
    for (Map.Entry<String, Integer> entry : this.currentCart.getItems().entrySet()) {
      String cartItemName = entry.getKey();
      int cartItemQuantity = entry.getValue();
      int availableQuantity = this.items.get(cartItemName).getQuantity();
      System.out.println(String.format("Item: %s - Quantity: %d", cartItemName, cartItemQuantity));
      this.changeQuantity(this.items.get(cartItemName), availableQuantity - cartItemQuantity);
    }
    this.currentCart.clear();
  }

  public void addItem(String itemName, String description, float price, int quantity) {
    if (this.items.get(itemName) == null) {
      Item newItem = new Item(itemName, description, price, quantity);
      this.items.put(itemName, newItem);
    } else {
      System.out.println("Error: Duplicate item. Try updating the item.");
    }
  }

  public void changeItemName(Item item, String itemName) {
    this.items.remove(item.getItemName());
    item.setItemName(itemName);
    this.items.put(itemName, item);
  }

  public void changeQuantity(Item item, int quantity) {
    item.setQuantity(quantity);
  }

  public void changeDescription(Item item, String description) {
    item.setDescription(description);
  }

  public void changePrice(Item item, float price) {
    if (price > 0) {
      item.setPrice(price);
    } else {
      System.out.println("Error: Price cannot be $0");
    }
  }

  public String getItemInfo(Item item) {
    return item.getItemInfo();
  }

  public void removeItem(Item item) {
    this.items.remove(item.getItemName());
  }

  public void writeData() {
    try (FileOutputStream itemsFile = new FileOutputStream("items.ser");
        ObjectOutputStream itemsOut = new ObjectOutputStream(itemsFile);) {
      itemsOut.writeObject(this.items);
    } catch (Exception e) {
      System.out.println("Error when writing item data");
      System.out.println(e.getMessage());
    }

    try (FileOutputStream userFile = new FileOutputStream("users.ser");
        ObjectOutputStream userOut = new ObjectOutputStream(userFile);) {
      userOut.writeObject(this.users);
    } catch (Exception e) {
      System.out.println("Error when writing user data");
      System.out.println(e.getMessage());
    }

    try (FileOutputStream cartFile = new FileOutputStream("carts.ser");
        ObjectOutputStream cartOut = new ObjectOutputStream(cartFile);) {
      cartOut.writeObject(this.users);
    } catch (Exception e) {
      System.out.println("Error when writing cart data");
      System.out.println(e.getMessage());
    }
  }
}
