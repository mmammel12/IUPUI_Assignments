import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Menu {
  private Scanner scanner;
  private FrontController fc;
  private static final String INVALID_STR = "Error: Invalid selection";
  private static final String SELECTION = "\nEnter Selection:";

  public static void main(String[] args) {
    HashMap<String, Item> items;
    HashMap<String, User> users;
    HashMap<String, Cart> carts;

    try (FileInputStream file = new FileInputStream("items.ser");
        ObjectInputStream obj = new ObjectInputStream(file);) {
      items = (HashMap<String, Item>) obj.readObject();
    } catch (Exception e) {
      items = new HashMap<>();
    }

    try (FileInputStream file = new FileInputStream("users.ser");
        ObjectInputStream obj = new ObjectInputStream(file);) {
      users = (HashMap<String, User>) obj.readObject();
    } catch (Exception e) {
      users = new HashMap<>();
    }

    try (FileInputStream file = new FileInputStream("carts.ser");
        ObjectInputStream obj = new ObjectInputStream(file);) {
      carts = (HashMap<String, Cart>) obj.readObject();
    } catch (Exception e) {
      carts = new HashMap<>();
    }

    FrontController fc = new FrontController(items, users, carts);
    Menu menu = new Menu(fc);

    if (users.size() == 0) {
      System.out.println("No users - register first admin");
      String[] newAdmin = menu.registerAdmin();
      fc.registerAdmin(newAdmin[0], newAdmin[1]);
      System.out.println("\nRegister first customer");
      String[] newCustomer = menu.registerCustomer();
      fc.registerCustomer(newCustomer[0], newCustomer[1]);
    }

    menu.mainMenu();
  }

  public void mainMenu() {
    while (true) {
      this.loginMenu();

      if (this.checkAdmin()) {
        this.adminMenu();
      } else {
        this.customerMenu();
      }
    }
  }

  public void adminMenu() {
    boolean keepgoing = true;
    while (keepgoing) {
      this.printAdminMenu();
      String response = this.getMenuResponse();
      boolean valid = this.validateMenuResponse(response, 4);
      if (valid) {
        switch (response) {
          case "1":
            this.itemMenu();
            break;
          case "2":
            this.customerMenu();
            break;
          case "3":
            String[] adminInfo = this.registerAdmin();
            this.fc.registerAdmin(adminInfo[0], adminInfo[1]);
            break;
          case "4":
            this.changePassword();
            break;
          case "0":
            this.fc.logout();
            break;
          default:
            break;
        }
      }
      keepgoing = false;
    }
  }

  public void customerMenu() {
    boolean keepgoing = true;
    while (keepgoing) {
      this.printCustomerMenu();
      String response = this.getMenuResponse();
      boolean valid = this.validateMenuResponse(response, 3);
      if (valid) {
        switch (response) {
          case "1":
            this.customerSelectItem();
            break;
          case "2":
            this.viewCart();
            break;
          case "3":
            this.changePassword();
            break;
          case "0":
            this.fc.logout();
            break;
          default:
            break;
        }
      }
      keepgoing = false;
    }
  }

  public void loginMenu() {
    boolean isSignedIn = false;
    while (!isSignedIn) {
      this.printLoginMenu();
      String response = this.getMenuResponse();
      boolean valid = this.validateMenuResponse(response, 2);

      if (valid) {
        switch (response) {
          case "1":
            isSignedIn = this.login();
            break;
          case "2":
            this.registerCustomer();
            break;
          case "0":
            this.exit();
            break;
          default:
            break;
        }
      }
    }
  }

  public void itemMenu() {
    boolean keepgoing = true;
    while (keepgoing) {
      this.printItemMenu();
      String response = this.getMenuResponse();
      boolean valid = this.validateMenuResponse(response, 3);
      if (valid) {
        switch (response) {
          case "1":
            System.out.println(this.viewItems());
            break;
          case "2":
            Item item = this.adminSelectItem();
            this.updateItem(item);
            break;
          case "3":
            Item selectedItem = this.adminSelectItem();
            this.removeItem(selectedItem);
            break;
          case "0":
            keepgoing = false;
            break;
          default:
            break;
        }
      }
    }
  }

  public String getMenuResponse() {
    return this.scanner.nextLine();
  }

  public boolean validateMenuResponse(String response, int max) {
    boolean valid = false;
    try {
      int selection = Integer.parseInt(response);
      if (selection >= 0 && selection <= max) {
        valid = true;
      } else {
        System.out.println(INVALID_STR);
      }
    } catch (Exception e) {
      System.out.println(INVALID_STR);
    }

    return valid;
  }

  public Menu(FrontController fc) {
    this.fc = fc;
    this.scanner = new Scanner(System.in);
  }

  public void printLoginMenu() {
    System.out.println("Menu:");
    System.out.println("1) Login");
    System.out.println("2) Register");
    System.out.println("0) Exit");
    System.out.println(SELECTION);
  }

  public void printCustomerMenu() {
    System.out.println("Menu:");
    System.out.println("1) Select Items");
    System.out.println("2) View Cart");
    System.out.println("3) Change Password");
    System.out.println("0) Logout");
    System.out.println(SELECTION);
  }

  public void printAdminMenu() {
    System.out.println("Admin Menu:");
    System.out.println("1) View/Update/Remove Items");
    System.out.println("2) Add/Remove Customer");
    System.out.println("3) Add Admin");
    System.out.println("4) Change Password");
    System.out.println("0) Logout");
    System.out.println(SELECTION);
  }

  public void printItemMenu() {
    System.out.println("Item Menu:");
    System.out.println("1) View Items");
    System.out.println("2) Update Item");
    System.out.println("3) Remove Item");
    System.out.println("0) Exit");
    System.out.println(SELECTION);
  }

  public String[] registerCustomer() {
    boolean keepgoing = true;
    System.out.println("Enter username for new customer:");
    String username = this.scanner.nextLine();
    while (keepgoing) {
      if (this.fc.checkUsername(username)) {
        System.out.println("Error: duplicate username");
      } else {
        keepgoing = false;
      }

      if (keepgoing) {
        System.out.println("Enter username for new customer:");
        username = this.scanner.nextLine();
      }
    }
    keepgoing = true;
    System.out.println("Enter password for new customer:");
    String password = this.scanner.nextLine();
    System.out.println("Verify password for new customer:");
    String passwordConfirm = this.scanner.nextLine();
    while (keepgoing) {
      if (password.equals(passwordConfirm)) {
        keepgoing = false;
      } else {
        System.out.println("Error: Passwords do not match");
      }

      if (keepgoing) {
        System.out.println("Enter password for new customer:");
        password = this.scanner.nextLine();
        System.out.println("Verify password for new customer:");
        passwordConfirm = this.scanner.nextLine();
      }
    }

    return new String[] { username, password };
  }

  public String[] registerAdmin() {
    boolean keepgoing = true;
    System.out.println("Enter username for new admin:");
    String username = this.scanner.nextLine();
    while (keepgoing) {
      if (this.fc.checkUsername(username)) {
        System.out.println("Error: duplicate username");
      } else {
        keepgoing = false;
      }

      if (keepgoing) {
        System.out.println("Enter username for new admin:");
        username = this.scanner.nextLine();
      }
    }
    keepgoing = true;
    System.out.println("Enter password for new admin:");
    String password = this.scanner.nextLine();
    System.out.println("Verify password for new admin:");
    String passwordConfirm = this.scanner.nextLine();
    while (keepgoing) {
      if (password.equals(passwordConfirm)) {
        keepgoing = false;
      } else {
        System.out.println("Error: Passwords do not match");
      }

      if (keepgoing) {
        System.out.println("Enter password for new admin:");
        password = this.scanner.nextLine();
        System.out.println("Verify password for new admin:");
        passwordConfirm = this.scanner.nextLine();
      }
    }

    return new String[] { username, password };
  }

  public boolean login() {
    System.out.println("Enter username:");
    String username = this.scanner.nextLine();
    System.out.println("Enter password:");
    String password = this.scanner.nextLine();

    return this.fc.login(username, password);
  }

  public void changePassword() {
    System.out.println("Enter current password:");
    String currentPassword = this.scanner.nextLine();
    System.out.println("Enter new password:");
    String newPassword = this.scanner.nextLine();

    this.fc.changePassword(currentPassword, newPassword);
  }

  public boolean checkAdmin() {
    return this.fc.checkAdmin();
  }

  public void removeCustomer() {
    System.out.println("Enter Customer's username you want to delete");
    String username = this.scanner.nextLine();

    if (this.fc.checkUsername(username)) {
      System.out.println("Warning: You are about to delete the account: " + username
          + "\nThis cannot be undone. To continue please type \"DELETE\"");

      String response = this.scanner.nextLine();

      if (response.equalsIgnoreCase("DELETE")) {
        this.fc.removeUser(username);
        System.out.println("Account " + username + " successfully deleted");
      }
    }
  }

  public void updateItem(Item item) {
    String itemName;
    String description;
    float price;
    int quantity;

    boolean keepgoing = true;

    while (keepgoing) {
      itemName = item.getItemName();
      description = item.getDescription();
      price = item.getPrice();
      quantity = item.getQuantity();

      String currentItemInfo = String.format(
          "Current Item Information:%n1) Item name: %s%n2) Description: %s%n3) Price: %.2f%n4) Quantity: %d", itemName,
          description, price, quantity);

      System.out.println(currentItemInfo + "\n0) Exit");
      System.out.println("\nWhat would you like to update?");

      String response = this.scanner.nextLine();

      switch (response) {
        case "1":
          this.changeItemName(item);
          break;
        case "2":
          this.changeItemDescription(item);
          break;
        case "3":
          this.changeItemPrice(item);
          break;
        case "4":
          this.changeItemQuantity(item);
          break;
        case "0":
          keepgoing = false;
          break;
        default:
          System.out.println(INVALID_STR);
          break;
      }
    }
  }

  public void changeItemName(Item item) {
    String itemName = item.getItemName();

    System.out.println("Current Item Name: " + itemName + "\nEnter new name or \"exit\"");
    String response = scanner.nextLine();
    if (!response.equalsIgnoreCase("exit")) {
      item.setItemName(response);
    }
  }

  public void changeItemDescription(Item item) {
    String description = item.getDescription();

    System.out.println("Current Item Description: " + description + "\nEnter new description or \"exit\"");
    String response = scanner.nextLine();
    if (!response.equalsIgnoreCase("exit")) {
      item.setDescription(response);
    }
  }

  public void changeItemPrice(Item item) {
    float price = item.getPrice();

    System.out.println(String.format("Current Item Price: %.2f%nEnter new price or \"exit\"", price));
    String response = scanner.nextLine();
    if (!response.equalsIgnoreCase("exit")) {
      try {
        float newPrice = Float.parseFloat(response);
        item.setPrice(newPrice);
      } catch (Exception e) {
        System.out.println("Error: Price must be a float");
      }
    }
  }

  public void changeItemQuantity(Item item) {
    int quantity = item.getQuantity();

    System.out.println(String.format("Current Item Quantity: %d%nEnter new quantity or \"exit\"", quantity));
    String response = scanner.nextLine();
    if (!response.equalsIgnoreCase("exit")) {
      try {
        int newPrice = Integer.parseInt(response);
        if (newPrice >= 0) {
          item.setQuantity(newPrice);
        } else {
          System.out.println("Error: Quantity must be 0 or greater");
        }
      } catch (Exception e) {
        System.out.println("Error: Quantity must be an integer");
      }
    }
  }

  public String viewItems() {
    ArrayList<Item> itemsList = this.fc.search();
    StringBuilder output = new StringBuilder("Items:\n");
    for (int i = 0; i < itemsList.size(); i++) {
      Item currentItem = itemsList.get(i);
      output.append(String.format("%d) %s - Price: %.2f - Quantity: %d%n", i, currentItem.getItemName(),
          currentItem.getPrice(), currentItem.getQuantity()));
    }

    return output.toString();
  }

  public void addItemsToCart() {
    String output = this.viewItems();

    System.out.println(output);
    while (this.customerSelectItem()) {
      System.out.println(output);
    }
  }

  public void removeItem(Item item) {
    System.out.println("You are about to delete the following Item:");
    System.out.println(this.fc.getItemInfo(item));
    System.out.println("\nThis action cannot be undone. Continue? (y/n)");

    String reponse = this.scanner.nextLine();
    if (reponse.equalsIgnoreCase("y")) {
      this.fc.removeItem(item);
    }
  }

  private Item adminSelectItem() {
    ArrayList<Item> itemsList = this.fc.search();
    boolean keepgoing = true;
    Item item = null;
    while (keepgoing) {
      System.out.println(this.viewItems());
      System.out.println(SELECTION);
      String response = this.scanner.nextLine();

      try {
        int itemNum = Integer.parseInt(response);
        if (itemNum < itemsList.size() && itemNum >= 0) {
          item = itemsList.get(itemNum);
          keepgoing = false;
        }
      } catch (Exception e) {
        System.out.println(INVALID_STR);
      }
    }

    return item;
  }

  private boolean customerSelectItem() {
    ArrayList<Item> itemsList = this.fc.search();
    boolean keepgoing = true;
    Item selectedItem;
    System.out.println("Enter the item number you would like to view: (\"exit\" to exit)");
    String response = this.scanner.nextLine();
    if (response.equalsIgnoreCase("exit")) {
      keepgoing = false;
    } else {
      try {
        int itemNum = Integer.parseInt(response);
        if (itemNum < itemsList.size() && itemNum >= 0) {
          selectedItem = itemsList.get(itemNum);
          System.out.println(this.fc.getItemInfo(selectedItem));
          int itemQuantity = selectedItem.getQuantity();
          System.out.println("Add to cart? (y/n");
          String addToCartResponse = this.scanner.nextLine();
          if (addToCartResponse.equalsIgnoreCase("y")) {
            int quantity = determineQuantity(itemQuantity);
            this.fc.updateCart(selectedItem.getItemName(), quantity);
          }
        } else {
          System.out.println(INVALID_STR);
        }
      } catch (Exception e) {
        System.out.println(INVALID_STR);
      }
    }
    return keepgoing;
  }

  private int determineQuantity(int itemQuantity) {
    boolean keepgoing = true;
    int quantity = 0;
    System.out.println("How many would you like to add? max: " + Integer.toString(itemQuantity));
    String quantityResponse = this.scanner.nextLine();
    while (keepgoing) {
      try {
        quantity = Integer.parseInt(quantityResponse);
        if (quantity <= itemQuantity && quantity >= 0) {
          keepgoing = false;
        } else {
          System.out.println("Error: quantity must be between [0, " + Integer.toString(itemQuantity) + "]");
        }
      } catch (Exception e) {
        System.out.println(INVALID_STR);
      }

      if (keepgoing) {
        System.out.println("How many would you like to add? max: " + Integer.toString(itemQuantity));
        quantityResponse = this.scanner.nextLine();
      }
    }

    return quantity;
  }

  public void viewCart() {
    String userCart = this.fc.viewCart();
    System.out.println(userCart);
    System.out.println("Purchase? (y/n)");
    String response = this.scanner.nextLine();
    if (response.equalsIgnoreCase("y")) {
      this.fc.purchase();
    }
  }

  private void exit() {
    this.fc.writeData();
    System.exit(0);
  }
}
