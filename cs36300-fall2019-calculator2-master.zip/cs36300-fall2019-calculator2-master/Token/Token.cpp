#include "Token.h"

#define MULT_DIV_MOD 2
#define ADD_SUB 1
#define PARENTHESIS 0
#define NUMBER -1

Token::Token()
    : token_(""),
      priority_(NUMBER)
{
}

Token::Token(std::string token)
    : token_(token)
{
  setPriority();
}

std::string Token::getToken()
{
  return token_;
}

int Token::getPriority()
{
  return priority_;
}

void Token::setToken(std::string token)
{
  token_ = token;
  setPriority();
}

bool Token::operator==(const Token &rhs) const
{
  return this->token_ == rhs.token_;
}

void Token::setPriority()
{
  if (token_ == "(" || token_ == ")")
  {
    priority_ = PARENTHESIS;
  }
  else if (token_ == "*" || token_ == "/" || token_ == "%")
  {
    priority_ = MULT_DIV_MOD;
  }
  else if (token_ == "+" || token_ == "-")
  {
    priority_ = ADD_SUB;
  }
  else
  {
    priority_ = NUMBER;
  }
}
