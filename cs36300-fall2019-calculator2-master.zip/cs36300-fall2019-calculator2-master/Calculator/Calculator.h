#ifndef CALCULATOR_EXISTS
#define CALCULATOR_EXISTS

#include <string>

class Calculator
{
public:
  Calculator() = default;

  ~Calculator() = default;

  bool run();

private:
  bool _is_number(const std::string &token);

  void _lstrip(std::string &str);

  void _rstrip(std::string &str);

  void _strip(std::string &str);
};

#endif