#include "Calculator.h"
#include "../Parser/Parser.h"
#include "../Assignment2/Array.h"
#include "../Assignment2/Queue.h"
#include "../Token/Token.h"
#include "../Builder/Tree_Builder.h"
#include "../Visitor/Tree_Visitor.h"
#include <iostream>
#include <sstream>
#include <algorithm>

#define NUMBER -1

bool Calculator::run()
{
  std::string infix;
  bool empty;

  while (true)
  {
    empty = false;
    // get infix from user
    std::getline(std::cin, infix);

    _strip(infix);

    if (infix == "QUIT")
    {
      break;
    }

    Parser parser;
    Tree_Builder builder;
    Array<std::shared_ptr<Node>> variable_nodes(infix.length());
    Array<Token> variable_tokens(infix.length());

    // parse infix to postfix
    Queue<Token> tokens = parser.infix_to_postfix(infix);

    // build tree
    while (!tokens.is_empty())
    {
      Token current = tokens.dequeue();

      if (current.getToken() == "")
      {
        empty = true;
        break;
      }
      // if current is of number priority, determine if number or variable
      else if (current.getPriority() == NUMBER)
      {
        if (_is_number(current.getToken()))
        {
          std::stringstream ss(current.getToken());

          int num;
          ss >> num;

          builder.build_number(num);
        }
        else
        {
          // if no variables have been added, build a variable normally
          if (variable_nodes.size() == 0)
          {
            std::shared_ptr<Node> var = builder.build_variable(current.getToken());
            variable_nodes.set(variable_nodes.size(), var);
            variable_tokens.set(variable_tokens.size(), current);
          }
          // else, check if the variable already exists
          else
          {
            int index = variable_tokens.find(current.getToken());
            // if the variable exists, add pointer to the same variable
            if (index != -1)
            {
              builder.add_variable_node(variable_nodes.get(index));
            }
            // else variable is new, build a variable normally
            else
            {
              std::shared_ptr<Node> var = builder.build_variable(current.getToken());
              variable_nodes.set(variable_nodes.size(), var);
              variable_tokens.set(variable_tokens.size(), current);
            }
          }
        }
      }
      // else current is an operator
      else
      {
        if (current.getToken() == "+")
        {
          builder.build_addition();
        }
        else if (current.getToken() == "-")
        {
          builder.build_subtraction();
        }
        else if (current.getToken() == "*")
        {
          builder.build_multiplication();
        }
        else if (current.getToken() == "/")
        {
          builder.build_division();
        }
        else if (current.getToken() == "%")
        {
          builder.build_modulus();
        }
        else
        {
          throw std::invalid_argument("Error: Unrecognized Character");
        }
      }
    }

    if (!empty)
    {
      Tree expression_tree = builder.get_tree();

      // evaluate tree with visitor
      Tree_Visitor visitor;
      int result = expression_tree.getRoot()->accept(&visitor);

      std::cout << result << std::endl;
    }
  }

  return false;
}

bool Calculator::_is_number(const std::string &token)
{
  bool is_num = true;

  const char *cToken = token.c_str();

  for (int i = 0; i < token.length(); i++)
  {
    // if char is not a digit, check if it is negative sign
    if (!isdigit(cToken[i]))
    {
      // if char is a negative sign, check it is element 0
      if (cToken[i] == '-')
      {
        // if negative sign is not element 0, set is_num to false
        if (i != 0)
        {
          is_num = false;
          break;
        }
      }
      // else char is not a number
      else
      {
        is_num = false;
        break;
      }
    }
  }

  return is_num;
}

void Calculator::_lstrip(std::string &str)
{
  str.erase(std::find_if(str.rbegin(), str.rend(), [](int ch) {
              return !std::isspace(ch);
            }).base(), str.end());
}

void Calculator::_rstrip(std::string &str)
{
  str.erase(str.begin(), std::find_if(str.begin(), str.end(), [](int ch) {
              return !std::isspace(ch);
            }));
}

void Calculator::_strip(std::string &str)
{
  _lstrip(str);
  _rstrip(str);
}