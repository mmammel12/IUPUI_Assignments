#include "Parser.h"
#include "../Assignment2/empty_exception.h"
#include <sstream>
#include <iostream>
#include <stdexcept>

#define NUMBER -1
#define PARENTHESIS 0
#define ADD_SUB 1
#define MULT_DIV_MOD 2

Queue<Token> Parser::infix_to_postfix(const std::string &infix)
{
  bool firstToken = true;
  std::istringstream input(infix);
  std::string token;
  Queue<Token> postfix;
  Stack<Token> operators;
  Token prevToken;

  while (!input.eof())
  {
    input >> token;
    Token newToken(token);

    // validate first token
    if (firstToken)
    {
      _validate_first_token(newToken);

      prevToken.setToken(token);

      firstToken = false;
    }
    // else not first token, check for repeating operator/operand
    else
    {
      _check_for_repeat(newToken, prevToken);

      prevToken.setToken(token);
    }

    // if token is a number/variable
    if (newToken.getPriority() == NUMBER)
    {
      postfix.enqueue(newToken);
    }
    // else token is an operator
    else
    {
      // if operators is not empty
      if (!operators.is_empty())
      {
        // if token is not a parenthesis
        if (newToken.getPriority() > PARENTHESIS)
        {
          // if token priority is greater than priority of operators.top()
          // push token to operators
          if (newToken.getPriority() > operators.top().getPriority())
          {
            operators.push(Token(token));
          }
          // else if token priority is <= to priority of operators.top()
          // loop and push token from operators to postfix until not true
          else if (newToken.getPriority() <= operators.top().getPriority())
          {
            while (!operators.is_empty() && newToken.getPriority() <= operators.top().getPriority())
            {
              postfix.enqueue(operators.top());
              operators.pop();
            }
            operators.push(Token(token));
          }
        }
        // if the token is a parenthesis, determine open or close
        else if (newToken.getPriority() == PARENTHESIS)
        {
          // if it is open, push to operators
          if (newToken.getToken() == "(")
          {
            operators.push(Token(token));
          }
          // else if it is close, pop operators and push token to
          // postfix until open is found
          else
          {
            while (operators.top().getToken() != "(")
            {
              postfix.enqueue(operators.top());
              operators.pop();

              if (operators.is_empty())
              {
                throw std::invalid_argument("Error: Parenthesis missing");
              }
            }
            operators.pop();
          }
        }
      }
      // else operators is empty, push operator Token onto operators stack
      else
      {
        operators.push(Token(token));
      }
    }
  }

  while (!operators.is_empty())
  {
    if (operators.top().getPriority() == PARENTHESIS)
    {
      throw std::invalid_argument("Error: Parenthesis missing");
    }
    else
    {
      postfix.enqueue(operators.top());
      operators.pop();
    }
  }

  return postfix;
}

void Parser::_validate_first_token(Token token)
{
  if (token.getPriority() == ADD_SUB || token.getPriority() == MULT_DIV_MOD)
  {
    throw std::invalid_argument("Error: Expression cannot start with an operator.");
  }
  else if (token.getToken() == ")")
  {
    throw std::invalid_argument("Error: Expression cannot start with ')'");
  }
}

void Parser::_check_for_repeat(Token newToken, Token prevToken)
{
  if (newToken.getPriority() == ADD_SUB || newToken.getPriority() == MULT_DIV_MOD)
  {
    if (prevToken.getPriority() == ADD_SUB || prevToken.getPriority() == MULT_DIV_MOD)
    {
      throw std::invalid_argument("Error: Cannot have multiple operators in a row.");
    }
  }
  else if (newToken.getPriority() == NUMBER)
  {
    if (prevToken.getPriority() == NUMBER)
    {
      throw std::invalid_argument("Error: Cannot have multiple numbers in a row.");
    }
  }
}