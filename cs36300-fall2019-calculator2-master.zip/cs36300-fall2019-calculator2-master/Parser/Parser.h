#ifndef PARSER_EXISTS
#define PARSER_EXISTS

#include <string>
#include <memory>
#include "../Assignment2/Queue.h"
#include "../Assignment2/Stack.h"
#include "../Token/Token.h"

class Parser
{
public:
  Parser() = default;

  ~Parser() = default;

  Queue<Token> infix_to_postfix(const std::string &infix);

private:
  void _validate_first_token(Token token);

  void _check_for_repeat(Token newToken, Token prevToken);
};

#endif