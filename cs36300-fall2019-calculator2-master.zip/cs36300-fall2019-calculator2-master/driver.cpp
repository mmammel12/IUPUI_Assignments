#include "Calculator/Calculator.h"
#include <iostream>

int main(int argc, char const *argv[])
{
  Calculator calc;

  bool keepGoing;

  do
  {
    try
    {
      keepGoing = calc.run();
    }
    catch (const std::exception &e)
    {
      std::cerr << e.what() << '\n';
    }

  } while (keepGoing);

  return 0;
}
