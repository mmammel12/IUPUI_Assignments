// Author: Marty Mammel
// Last Modification: 9/29/2019
// Queue template class without the use of the std library

// Honor Pledge:
//
// I pledge that I have neither given nor receieved any help
// on this assignment.

#define EMPTY -1

template <typename T>
Queue<T>::Queue()
    : elements_(Array<T>()),
      first_(EMPTY),
      last_(EMPTY)
{
}

template <typename T>
Queue<T>::Queue(const Queue &q)
    : elements_(Array<T>(q.elements_)),
      first_(q.first_),
      last_(q.last_)
{
}

template <typename T>
Queue<T>::~Queue()
{
}

template <typename T>
const Queue<T> &Queue<T>::operator=(const Queue<T> &rhs)
{
  this->elements_ = Array<T>(rhs.elements_);
  this->first_ = rhs.first_;
  this->last_ = rhs.last_;
}

template <typename T>
void Queue<T>::enqueue(T element)
{
  // queue is empty
  if (this->first_ == EMPTY)
  {
    this->elements_.set(0, element);
    this->first_ = 0;
    this->last_ = 0;
  }
  // element can be place at the back of the array
  else if (this->last_ < this->elements_.max_size() - 1)
  {
    this->elements_.set(this->last_ + 1, element);
    this->last_++;
  }
  // element cannot be placed at the back, room at front of array
  else if (this->first_ > 0)
  {
    this->elements_.set(0, element);
    this->last_ = 0;
  }
  // else no room left, need to expand
  else
  {
    this->expand();
    this->elements_.set(this->size(), element);
    this->last_++;
  }
}

template <typename T>
T Queue<T>::dequeue(void)
{
  T value;
  // queue contains elements
  if (this->size() > 0)
  {
    int prevFirst = first_;

    value = this->elements_.get(this->first_);
    // first is not at the end of the queue
    if (this->first_ < this->elements_.max_size() - 1)
    {
      this->first_++;
    }
    // else first is at the end of the queue, loop to front
    else
    {
      this->first_ = 0;
    }

    if (prevFirst == this->last_)
    {
      this->first_ = EMPTY;
      this->last_ = EMPTY;
    }
  }
  else
  {
    throw empty_exception("Error: Cannot dequeue from empty queue");
  }

  return value;
}

template <typename T>
bool Queue<T>::is_empty(void) const
{
  return this->size() == 0;
}

//
// size
//
template <typename T>
size_t Queue<T>::size(void) const
{
  size_t size;
  // queue is empty
  if (this->first_ == EMPTY)
  {
    size = 0;
  }
  // queue contains one element
  else if (this->first_ == this->last_)
  {
    size = 1;
  }
  // queue does not loop back to beginning
  else if (this->last_ > this->first_)
  {
    size = this->last_ - this->first_ + 1;
  }
  // queue loops back to beginning
  else if (this->first_ > this->last_)
  {
    size = this->elements_.max_size() - this->first_ + this->last_ + 1;
  }

  return size;
}

//
// clear
//
template <typename T>
void Queue<T>::clear(void)
{
  this->elements_ = Array<T>();
  this->first_ = EMPTY;
  this->last_ = EMPTY;
}

//
// expand
//
template <typename T>
void Queue<T>::expand()
{
  int size = this->size() + DEFAULT_SIZE;
  Array<T> temp(size);
  for (int i = 0; i < this->size(); i++)
  {
    temp.set(i, this->dequeue());
  }
  this->elements_ = Array<T>(temp);
  this->first_ = 0;
  this->last_ = this->size() - 1;
}
