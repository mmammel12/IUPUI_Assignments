#ifndef _EMPTY_EXCEPTION_
#define _EMPTY_EXCEPTION_

#include <stdexcept>

class empty_exception : public std::runtime_error
{
public:
  /**
   * Initializing constructor.
   *
   * @param[in]      msg         Error message.
   */
  empty_exception(const char *msg);

private:
  /// Default constructor.
  empty_exception(void) = delete;
};

#endif