// -*- C++ -*-

// Honor Pledge:
//
// I pledge that I have neither given nor received any help
// on this assignment.

#ifndef _QUEUE_H_
#define _QUEUE_H_

#include <cstring> // for size_t definition
#include "Array.h"
#include "empty_exception.h"

//COMMENT: There is no need to re-define the empty exception class here.
//You can access the empty_exception class in Stack using the :: operator, Stack::empty_exception
//REPLY: moved empty_exception to it's own class
template <typename T>
class Queue
{
public:
  // Default constructor.
  Queue(void);

  // Copy constructor
  Queue(const Queue &q);

  // Destructor
  ~Queue();

  /**
   * Assignment operator
   *
   * @param[in]      rhs           Right-hand side of operator
   * @return         Reference to self
   */
  const Queue &operator=(const Queue &rhs);

  /**
   * Enqueue a new element onto the queue. 
   *
   * @param[in]      element       Element to add to the queue
   */
  void enqueue(T element);

  /**
   * Get the first element in the queue. If there are no element 
   * on the queue, then the queue_is_empty exception is thrown.
   *
   * @return         First element of the queue.
   * @exception      empty_exception    The queue is empty
   */
  T dequeue(void);

  /**
   * Test if the queue is empty
   *
   * @retval         true          The queue is empty
   * @retval         false         The queue is not empty
   */
  bool is_empty(void) const;

  /**
   * Number of element on the queue.
   *
   * @return         Size of the queue.
   */
  size_t size(void) const;

  /// Remove all elements from the queue.
  void clear(void);

private:
  // increase the size of the queue is max_size_ is reached
  void expand(void);

  //COMMENT: The array does not need to be on the heap as it is redundant since the data_ is already on the heap.
  //Also, You're making the assignment more difficult for yourself!
  //REPLY: elements_ is no longer a pointers
  // Array to store the elements in the queue
  Array<T> elements_;
  // index of the first element
  int first_;
  // index of the last element
  int last_;

  //COMMENT: You do not need seperate variables to calculate the size of the Queue.
  //Try accomplishing this without this variable
  //REPLY: size_ removed
};

// include the source file since template class
#include "Queue.cpp"

#endif