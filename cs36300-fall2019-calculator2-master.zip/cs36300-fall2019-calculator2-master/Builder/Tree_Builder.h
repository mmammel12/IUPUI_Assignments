#ifndef TREE_BUILDER_EXISTS
#define TREE_BUILDER_EXISTS

#include "Builder.h"
#include "../Assignment2/Stack.h"

class Tree_Builder : public Builder
{
public:
  Tree_Builder();

  ~Tree_Builder() = default;

  void build_number(int num);

  std::shared_ptr<Node> build_variable(std::string var);

  void add_variable_node(std::shared_ptr<Node> var);

  void build_addition();

  void build_subtraction();

  void build_multiplication();

  void build_division();

  void build_modulus();

  Tree get_tree();

private:
  Stack<std::shared_ptr<Node>> nodes_;

  std::shared_ptr<Node> _get_right_node();

  std::shared_ptr<Node> _get_left_node();
};

#endif