#include "Tree_Builder.h"
#include <sstream>

#define NUMBER -1
#define ADD_SUB 1
#define MULT_DIV_MOD 2

Tree_Builder::Tree_Builder()
    : nodes_(Stack<std::shared_ptr<Node>>())
{
}

void Tree_Builder::build_number(int num)
{
  nodes_.push(std::shared_ptr<Node>(new Number(num)));
}

std::shared_ptr<Node> Tree_Builder::build_variable(std::string var)
{
  nodes_.push(std::shared_ptr<Node>(new Variable(var)));

  return nodes_.top();
}

void Tree_Builder::add_variable_node(std::shared_ptr<Node> var)
{
  nodes_.push(var);
}

void Tree_Builder::build_addition()
{
  std::shared_ptr<Node> right = _get_right_node();

  std::shared_ptr<Node> left = _get_left_node();

  nodes_.push(std::shared_ptr<Node>(new Addition(left, right)));
}

void Tree_Builder::build_subtraction()
{
  std::shared_ptr<Node> right = _get_right_node();

  std::shared_ptr<Node> left = _get_left_node();

  nodes_.push(std::shared_ptr<Node>(new Subtraction(left, right)));
}

void Tree_Builder::build_multiplication()
{
  std::shared_ptr<Node> right = _get_right_node();

  std::shared_ptr<Node> left = _get_left_node();

  nodes_.push(std::shared_ptr<Node>(new Multiplication(left, right)));
}

void Tree_Builder::build_division()
{
  std::shared_ptr<Node> right = _get_right_node();

  std::shared_ptr<Node> left = _get_left_node();

  nodes_.push(std::shared_ptr<Node>(new Division(left, right)));
}

void Tree_Builder::build_modulus()
{
  std::shared_ptr<Node> right = _get_right_node();

  std::shared_ptr<Node> left = _get_left_node();

  nodes_.push(std::shared_ptr<Node>(new Modulus(left, right)));
}

Tree Tree_Builder::get_tree()
{
  if (nodes_.size() == 1)
  {
    return Tree(nodes_.top());
  }
  else
  {
    throw std::invalid_argument("Error: Invalid expression");
  }
}

std::shared_ptr<Node> Tree_Builder::_get_right_node()
{
  std::shared_ptr<Node> right;

  if (!nodes_.is_empty())
  {
    right = nodes_.top();
    nodes_.pop();
  }
  else
  {
    throw std::invalid_argument("Error: Invalid expression");
  }

  return right;
}

std::shared_ptr<Node> Tree_Builder::_get_left_node()
{
  std::shared_ptr<Node> left;

  if (!nodes_.is_empty())
  {
    left = nodes_.top();
    nodes_.pop();
  }
  else
  {
    throw std::invalid_argument("Error: Invalid expression");
  }

  return left;
}