#ifndef BUILDER_EXISTS
#define BUILDER_EXISTS

#include <memory>
#include <string>
#include "../Tree/Node/Node.h"
#include "../Tree/Node/Number/Number.h"
#include "../Tree/Node/Number/Variable.h"
#include "../Tree/Node/Operators/Addition.h"
#include "../Tree/Node/Operators/Subtraction.h"
#include "../Tree/Node/Operators/Multiplication.h"
#include "../Tree/Node/Operators/Division.h"
#include "../Tree/Node/Operators/Modulus.h"
#include "../Tree/Tree.h"

class Builder
{
public:
  virtual void build_number(int num) = 0;

  virtual std::shared_ptr<Node> build_variable(std::string var) = 0;

  virtual void add_variable_node(std::shared_ptr<Node> var) = 0;

  virtual void build_addition() = 0;

  virtual void build_subtraction() = 0;

  virtual void build_multiplication() = 0;

  virtual void build_division() = 0;

  virtual void build_modulus() = 0;

  virtual Tree get_tree() = 0;
};

#endif