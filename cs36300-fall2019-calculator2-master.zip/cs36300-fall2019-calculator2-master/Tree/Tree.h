#ifndef TREE_EXISTS
#define TREE_EXISTS

#include <memory>
#include "Node/Node.h"

class Tree
{
public:
  Tree();

  Tree(std::shared_ptr<Node> root);

  ~Tree() = default;

  const Tree &operator=(const Tree &rhs);

  void setRoot(std::shared_ptr<Node> root);

  std::shared_ptr<Node> getRoot();

private:
  std::shared_ptr<Node> root_;
};

#endif