#include "Tree.h"

Tree::Tree()
    : root_(nullptr)
{
}

Tree::Tree(std::shared_ptr<Node> root)
    : root_(root)
{
}

const Tree &Tree::operator=(const Tree &rhs)
{
  root_ = rhs.root_;
}

void Tree::setRoot(std::shared_ptr<Node> root)
{
  root_ = root;
}

std::shared_ptr<Node> Tree::getRoot()
{
  return root_;
}