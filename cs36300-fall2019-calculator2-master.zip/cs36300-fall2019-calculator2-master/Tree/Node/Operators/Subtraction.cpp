#include "Subtraction.h"

Subtraction::Subtraction()
    : Operator()
{
}

Subtraction::Subtraction(std::shared_ptr<Node> &left, std::shared_ptr<Node> &right)
    : Operator(left, right)
{
}

int Subtraction::accept(Tree_Visitor *visitor)
{
  return visitor->visit_subtraction(*this);
}

void Subtraction::setLeft(std::shared_ptr<Node> left)
{
  Operator::setLeft(left);
}

void Subtraction::setRight(std::shared_ptr<Node> right)
{
  Operator::setRight(right);
}

std::shared_ptr<Node> Subtraction::getLeft()
{
  return Operator::getLeft();
}

std::shared_ptr<Node> Subtraction::getRight()
{
  return Operator::getRight();
}