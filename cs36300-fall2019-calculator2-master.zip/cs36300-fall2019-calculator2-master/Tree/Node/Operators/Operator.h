#ifndef OPERATOR_EXISTS
#define OPERATOR_EXISTS

#include "../Node.h"
#include "../../../Visitor/Tree_Visitor.h"
#include <memory>

class Operator : public Node
{
public:
  Operator();

  Operator(std::shared_ptr<Node> &left, std::shared_ptr<Node> &right);

  ~Operator() = default;

  virtual int accept(Tree_Visitor *visitor) = 0;

  virtual void setLeft(std::shared_ptr<Node> left);

  virtual void setRight(std::shared_ptr<Node> right);

  virtual std::shared_ptr<Node> getLeft();

  virtual std::shared_ptr<Node> getRight();

  //COMMENT: These variables do not need to be protected. Please use private instead.
  //REPLY: done.
private:
  std::shared_ptr<Node> left_;
  std::shared_ptr<Node> right_;
};

#endif