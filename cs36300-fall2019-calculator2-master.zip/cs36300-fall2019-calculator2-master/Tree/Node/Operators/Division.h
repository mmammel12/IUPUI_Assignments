#ifndef DIVISION_EXISTS
#define DIVISION_EXISTS

#include "Operator.h"

class Division : public Operator
{
public:
  Division();

  Division(std::shared_ptr<Node> &left, std::shared_ptr<Node> &right);

  ~Division() = default;

  int accept(Tree_Visitor *visitor);

  void setLeft(std::shared_ptr<Node> left);

  void setRight(std::shared_ptr<Node> right);

  std::shared_ptr<Node> getLeft();

  std::shared_ptr<Node> getRight();
};

#endif