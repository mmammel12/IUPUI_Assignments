#include "Modulus.h"

Modulus::Modulus()
    : Operator()
{
}

Modulus::Modulus(std::shared_ptr<Node> &left, std::shared_ptr<Node> &right)
    : Operator(left, right)
{
}

int Modulus::accept(Tree_Visitor *visitor)
{
  return visitor->visit_modulus(*this);
}

void Modulus::setLeft(std::shared_ptr<Node> left)
{
  Operator::setLeft(left);
}

void Modulus::setRight(std::shared_ptr<Node> right)
{
  Operator::setRight(right);
}

std::shared_ptr<Node> Modulus::getLeft()
{
  return Operator::getLeft();
}

std::shared_ptr<Node> Modulus::getRight()
{
  return Operator::getRight();
}