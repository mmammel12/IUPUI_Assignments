#include "Multiplication.h"

Multiplication::Multiplication()
    : Operator()
{
}

Multiplication::Multiplication(std::shared_ptr<Node> &left, std::shared_ptr<Node> &right)
    : Operator(left, right)
{
}

int Multiplication::accept(Tree_Visitor *visitor)
{
  return visitor->visit_multiplication(*this);
}

void Multiplication::setLeft(std::shared_ptr<Node> left)
{
  Operator::setLeft(left);
}

void Multiplication::setRight(std::shared_ptr<Node> right)
{
  Operator::setRight(right);
}

std::shared_ptr<Node> Multiplication::getLeft()
{
  return Operator::getLeft();
}

std::shared_ptr<Node> Multiplication::getRight()
{
  return Operator::getRight();
}