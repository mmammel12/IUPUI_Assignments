#ifndef ADDITION_EXISTS
#define ADDITION_EXISTS

#include "Operator.h"

class Addition : public Operator
{
public:
  Addition();

  Addition(std::shared_ptr<Node> &left, std::shared_ptr<Node> &right);

  ~Addition() = default;

  int accept(Tree_Visitor *visitor);

  void setLeft(std::shared_ptr<Node> left);

  void setRight(std::shared_ptr<Node> right);

  std::shared_ptr<Node> getLeft();

  std::shared_ptr<Node> getRight();
};

#endif