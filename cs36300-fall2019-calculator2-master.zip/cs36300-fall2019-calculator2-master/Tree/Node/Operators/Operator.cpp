#include "Operator.h"

Operator::Operator()
    : left_(nullptr),
      right_(nullptr)
{
}

Operator::Operator(std::shared_ptr<Node> &left, std::shared_ptr<Node> &right)
    : left_(left),
      right_(right)
{
}

void Operator::setLeft(std::shared_ptr<Node> left)
{
  left_ = left;
}

void Operator::setRight(std::shared_ptr<Node> right)
{
  right_ = right;
}

std::shared_ptr<Node> Operator::getLeft()
{
  return left_;
}

std::shared_ptr<Node> Operator::getRight()
{
  return right_;
}