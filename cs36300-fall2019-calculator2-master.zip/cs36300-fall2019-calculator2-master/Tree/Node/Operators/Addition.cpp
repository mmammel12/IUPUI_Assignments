#include "Addition.h"

Addition::Addition()
    : Operator()
{
}

Addition::Addition(std::shared_ptr<Node> &left, std::shared_ptr<Node> &right)
    : Operator(left, right)
{
}

int Addition::accept(Tree_Visitor *visitor)
{
  return visitor->visit_addition(*this);
}

void Addition::setLeft(std::shared_ptr<Node> left)
{
  Operator::setLeft(left);
}

void Addition::setRight(std::shared_ptr<Node> right)
{
  Operator::setRight(right);
}

std::shared_ptr<Node> Addition::getLeft()
{
  return Operator::getLeft();
}

std::shared_ptr<Node> Addition::getRight()
{
  return Operator::getRight();
}