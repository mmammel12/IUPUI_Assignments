#ifndef MULTIPLICATION_EXISTS
#define MULTIPLICATION_EXISTS

#include "Operator.h"

class Multiplication : public Operator
{
public:
  Multiplication();

  Multiplication(std::shared_ptr<Node> &left, std::shared_ptr<Node> &right);

  ~Multiplication() = default;

  int accept(Tree_Visitor *visitor);

  void setLeft(std::shared_ptr<Node> left);

  void setRight(std::shared_ptr<Node> right);

  std::shared_ptr<Node> getLeft();

  std::shared_ptr<Node> getRight();
};

#endif