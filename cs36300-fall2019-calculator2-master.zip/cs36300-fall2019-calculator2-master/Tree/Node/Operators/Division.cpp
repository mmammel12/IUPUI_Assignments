#include "Division.h"

Division::Division()
    : Operator()
{
}

Division::Division(std::shared_ptr<Node> &left, std::shared_ptr<Node> &right)
    : Operator(left, right)
{
}

int Division::accept(Tree_Visitor *visitor)
{
  return visitor->visit_division(*this);
}

void Division::setLeft(std::shared_ptr<Node> left)
{
  Operator::setLeft(left);
}

void Division::setRight(std::shared_ptr<Node> right)
{
  Operator::setRight(right);
}

std::shared_ptr<Node> Division::getLeft()
{
  return Operator::getLeft();
}

std::shared_ptr<Node> Division::getRight()
{
  return Operator::getRight();
}