#ifndef NODE_EXISTS
#define NODE_EXISTS

class Tree_Visitor;

class Node
{
public:
  virtual int accept(Tree_Visitor *visitor) = 0;
};

#endif