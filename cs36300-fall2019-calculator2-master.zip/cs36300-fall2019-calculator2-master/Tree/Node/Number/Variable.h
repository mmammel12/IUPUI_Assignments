#ifndef VARIABLE_EXISTS
#define VARIABLE_EXISTS

#include "../Node.h"
#include "../../../Visitor/Tree_Visitor.h"
#include <string>

class Variable : public Node
{
public:
  Variable(std::string var);

  ~Variable() = default;

  int accept(Tree_Visitor *visitor);

  std::string getVariable();

  int getValue();

private:
  Variable() = delete;

  bool _is_number(const std::string &token);

  std::string var_;

  int value_;

  bool value_set_;
};

#endif
