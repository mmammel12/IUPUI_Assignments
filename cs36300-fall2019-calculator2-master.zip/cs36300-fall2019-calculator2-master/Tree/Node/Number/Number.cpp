#include "Number.h"

Number::Number(int num)
    : value_(num)
{
}

int Number::accept(Tree_Visitor *visitor)
{
  return visitor->visit_number(*this);
}

int Number::getValue()
{
  return value_;
}