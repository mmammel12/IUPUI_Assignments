#include "Variable.h"
#include <iostream>
#include <sstream>
#include <stdexcept>

Variable::Variable(std::string var)
    : var_(var),
      value_(1),
      value_set_(false)
{
}

int Variable::accept(Tree_Visitor *visitor)
{
  return visitor->visit_variable(*this);
}

std::string Variable::getVariable()
{
  return var_;
}

int Variable::getValue()
{
  if (!value_set_)
  {
    std::string str_num;

    std::cout << var_ << " = ";
    std::cin >> str_num;

    if (_is_number(str_num))
    {
      std::stringstream ss(str_num);

      int num;
      ss >> num;

      value_ = num;
    }
    else
    {
      throw std::invalid_argument("Error: Variable must be a number.");
    }

    value_set_ = true;
  }

  return value_;
}

bool Variable::_is_number(const std::string &token)
{
  bool is_num = true;

  const char *cToken = token.c_str();

  for (int i = 0; i < token.length(); i++)
  {
    // if char is not a digit, check if it is negative sign
    if (!isdigit(cToken[i]))
    {
      // if char is a negative sign, check it is element 0
      if (cToken[i] == '-')
      {
        // if negative sign is not element 0, set is_num to false
        if (i != 0)
        {
          is_num = false;
          break;
        }
      }
      // else char is not a number
      else
      {
        is_num = false;
        break;
      }
    }
  }

  return is_num;
}