#ifndef NUMBER_EXISTS
#define NUMBER_EXISTS

#include "../Node.h"
#include "../../../Visitor/Tree_Visitor.h"

class Number : public Node
{
public:
  Number(int num);

  ~Number() = default;

  int accept(Tree_Visitor *visitor);

  int getValue();

private:
  Number() = delete;

  int value_;
};

#endif
