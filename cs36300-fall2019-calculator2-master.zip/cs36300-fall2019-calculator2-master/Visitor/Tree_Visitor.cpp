#include "Tree_Visitor.h"
#include <stdexcept>

#include "../Tree/Node/Number/Number.h"
#include "../Tree/Node/Number/Variable.h"
#include "../Tree/Node/Operators/Addition.h"
#include "../Tree/Node/Operators/Subtraction.h"
#include "../Tree/Node/Operators/Multiplication.h"
#include "../Tree/Node/Operators/Division.h"
#include "../Tree/Node/Operators/Modulus.h"

int Tree_Visitor::visit_number(Number &num)
{
  return num.getValue();
}

int Tree_Visitor::visit_variable(Variable &var)
{
  //COMMENT: Since you ask for user input within your getValue() method.
  //I believe this makes the system prompt for user input in PEMDAS order rather than
  //the order they are written in the input expression.
  //REPLY: The tree is built so an inorder traversal gives the original infix
  //expression which makes this evaluate the variables in the order given, not PEMDAS.
  return var.getValue();
}

int Tree_Visitor::visit_addition(Addition &op)
{
  return op.getLeft()->accept(this) + op.getRight()->accept(this);
}

int Tree_Visitor::visit_subtraction(Subtraction &op)
{
  return op.getLeft()->accept(this) - op.getRight()->accept(this);
}

int Tree_Visitor::visit_multiplication(Multiplication &op)
{
  return op.getLeft()->accept(this) * op.getRight()->accept(this);
}

int Tree_Visitor::visit_division(Division &op)
{
  int num1 = op.getLeft()->accept(this);

  int num2 = op.getRight()->accept(this);

  if (num2 == 0)
  {
    throw std::invalid_argument("Error: Division by 0");
  }

  return num1 / num2;
}

int Tree_Visitor::visit_modulus(Modulus &op)
{

  int num1 = op.getLeft()->accept(this);

  int num2 = op.getRight()->accept(this);

  if (num2 == 0)
  {
    throw std::invalid_argument("Error: Modulus by 0");
  }

  return num1 % num2;
}