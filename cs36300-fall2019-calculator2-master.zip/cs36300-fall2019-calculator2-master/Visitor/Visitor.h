#ifndef VISITOR_EXISTS
#define VISITOR_EXISTS

class Node;
class Operator;
class Number;
class Variable;
class Addition;
class Subtraction;
class Multiplication;
class Division;
class Modulus;

class Visitor
{
public:
  virtual int visit_number(Number &num) = 0;

  virtual int visit_variable(Variable &var) = 0;

  virtual int visit_addition(Addition &op) = 0;

  virtual int visit_subtraction(Subtraction &op) = 0;

  virtual int visit_multiplication(Multiplication &op) = 0;

  virtual int visit_division(Division &op) = 0;

  virtual int visit_modulus(Modulus &op) = 0;
};

#endif