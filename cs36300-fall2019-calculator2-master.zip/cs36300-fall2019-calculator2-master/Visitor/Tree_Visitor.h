#ifndef TREE_VISITOR_EXISTS
#define TREE_VISITOR_EXISTS

#include "Visitor.h"

class Tree_Visitor : public Visitor
{
public:
  Tree_Visitor() = default;

  ~Tree_Visitor() = default;

  int visit_number(Number &num);

  int visit_variable(Variable &var);

  int visit_addition(Addition &op);

  int visit_subtraction(Subtraction &op);

  int visit_multiplication(Multiplication &op);

  int visit_division(Division &op);

  int visit_modulus(Modulus &op);

private:
  int result_;
};

#endif