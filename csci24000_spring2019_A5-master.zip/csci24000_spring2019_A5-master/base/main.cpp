#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <string.h>

void parseInputFile(std::ifstream &, std::ofstream &);
int splitIntsFromStringAndAddThem(std::string);
std::string createOutputString(std::string, int);
void writeOutputFile(std::ofstream &, std::string);

int main()
{
  // create output.txt
  std::ofstream outputFile("output.txt");

  // open input.txt
  std::ifstream inputFile;
  inputFile.open("input.txt");

  // parse input.txt and write to output.txt
  parseInputFile(inputFile, outputFile);

  // close files
  outputFile.close();
  inputFile.close();

  return (0);
}

void parseInputFile(std::ifstream &inputFile, std::ofstream &outputFile)
{
  // current line of the file
  std::string line;
  // line containing ints, needs to be separated and added
  std::string intLine;
  // line containing string to be repeated
  std::string stringLine;
  // vuilt from intLine and stringLine, used to write to output.txt
  std::string outputLine;

  // current line number
  int lineNum = 0;
  // total after splitting intLine and summing
  int total;

  while (std::getline(inputFile, line))
  {
    if (lineNum % 2 == 0)
    {
      // line containing integers
      intLine = line;

      //split ints from the string
      total = splitIntsFromStringAndAddThem(intLine);
    }
    else
    {
      // line containing the string to be repeated
      stringLine = line;

      // create the string to be written to output.txt
      outputLine = createOutputString(stringLine, total);

      // write to output.txt
      writeOutputFile(outputFile, outputLine);
    }

    // iterate lineNum to keep track of what line we are on
    lineNum++;
  }
}

int splitIntsFromStringAndAddThem(std::string line)
{
  // return int, summed value of 3 ints from string
  int total = 0;

  std::string temp;

  std::stringstream ss;
  ss << line;

  // loop through, convert to int and sum
  while (std::getline(ss, temp, ','))
  {
    // convert c_temp to int
    total += stoi(temp);
  }

  return total;
}

std::string createOutputString(std::string word, int total)
{
  // return string, will be word concatinated total times
  std::string outputString = "";

  // loop total times to concatinate word
  for (int i = 0; i < total; i++)
  {
    // concatinate word into outputString
    outputString += word;

    if (i != total - 1)
    {
      // not final iteration, add a comma
      outputString += ",";
    }
  }

  return outputString;
}

void writeOutputFile(std::ofstream &outputFile, std::string line)
{
  outputFile << line << std::endl;
}