# Parsing File I/O

## Marty Mammel

## Algorithm

Goals:

> Your job is to write a program that takes an expected input file named "input.txt" of exact format:
>
> (int),(int),(int)
> (string)
> (int),(int),(int)
> (string)
> (int),(int),(int)
> (string)
> (int),(int),(int)
> (string)
> (int),(int),(int)
> (string)
>
> Your program should then sum the ints of each line and output the immediately following line's string that many times seperated by commas such that:
>
> 1,2,3
> ham
>
> becomes:
>
> ham,ham,ham,ham,ham,ham

Input:

> file named "input.txt"

Output:

> file named "output.txt"

main()

> Goals:
>
> - create output file
> - start the program
>
> Input:
>
> - none
>
> Output:
>
> - none
>
> Steps:
>
> - create output.txt
> - open input.txt
> - call parseInputFile()
> - close input.txt and output.txt

parseInputFile()

> Goals:
>
> - read from input.txt
>
> Input:
>
> - input.txt
> - output.txt
>
> Output:
>
> - no return value, sends string to be written to output.txt to writeOutputFile()
>
> Steps:
>
> - for each line in the file:
>   - pull in the line and assign it to a string variable intLine
>   - pull in the next line and assign it to a string variable stringLine
>   - call splitIntsFromStringAndAddThem() passing in intLine, assign return to int total
>   - call createOutputString() passing in stringLine and total, assign return to outputLine
>   - call writeOutputFile() passing in outputLine

splitIntsFromStringAndAddThem()

> Goals:
>
> - break string of ints into separate ints
>
> Input:
>
> - string containing three ints separated by commas
>
> Output:
>
> - int value of the three ints added together
>
> Steps:
>
> - initialize int total variable at 0 to store return value
> - iterate through the string concatinating each character to a temp string as long as the character != ","
> - if the character is "," then convert the previous string to int and add it to total
> - return total

createOutputString()

> Goals:
>
> - concatinate string together based on the summed total passed in
>
> Input:
>
> - string phrase containing the string to be concatinated separated by commas
>
> - int total for how many times to concatinate the string
>
> Output:
>
> - string with the final concatinated line
>
> Steps:
>
> - loop from 0 to (total-1)
>   - concatinate phrase into string variable outputString
>   - if not the final iteration, concatinate a comma
> - return outputString

writeOutputFile()

> Goals:
>
> - create and write to the output file
>
> Input:
>
> - output.txt
> - string to be written to the file
>
> Output:
>
> - no return value, writes to output.txt
>
> Steps:
>
> - write passed in string to end of output.txt followed by a newline
